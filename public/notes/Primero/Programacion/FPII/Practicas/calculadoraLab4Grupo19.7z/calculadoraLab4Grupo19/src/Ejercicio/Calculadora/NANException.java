package Ejercicio.Calculadora;

public class NANException extends Exception{

}