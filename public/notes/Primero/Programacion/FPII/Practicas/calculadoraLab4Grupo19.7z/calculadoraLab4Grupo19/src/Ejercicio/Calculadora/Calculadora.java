package Ejercicio.Calculadora;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Calculadora implements ActionListener {

    private JFrame ventana;
    private JTextField t;
    private JButton bdel, bclr;
    private JButton[] botones;

    private JCheckBox cientifica;
    private JButton bPI, bCos;
    //EXTRA
    private int operacion; //addding, multiplying, division...
    private double resultado ,a, b;
    private JComboBox<String> cb;
    private JButton bSerie;

    public Calculadora(){
        instantiate();
        configure();
        eventos();
    }

    private void instantiate(){
        ventana = new JFrame("Calculator");
        t = new JTextField();
        botones = new JButton[]{new JButton("1"), new JButton("2"), new JButton("3"), new JButton("4"),
                new JButton("5"), new JButton("6"), new JButton("7"), new JButton("8"),
                new JButton("9"), new JButton("0"), new JButton("."), new JButton("+"),
                new JButton("-"), new JButton("*"), new JButton("/"), new JButton("=")};
        bdel = new JButton("Delete");
        bclr = new JButton("Clear");
        cientifica = new JCheckBox("Scientific");
        bPI = new JButton("PI");
        bCos = new JButton("Coseno");
        cb = new JComboBox(new String[]{"Normal", "Advanced"});
        bSerie = new JButton("Serie");

    }
    private void configure(){
        ventana.setLayout(null);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setLocationRelativeTo(null);
        ventana.setSize(350, 500);
        ventana.setResizable(false);
        t.setBounds(30, 40, 280, 40);
        t.setFocusable(true);
        t.requestFocus();
        ventana.add(t);

        int i = 0;
        for (int x = 40; x <= 250; x+= 70) {
            for (int y = 100; y <= 310; y+= 70) {
                botones[i].setBounds(x, y, 50, 40);
                ventana.add(botones[i]);
                i++;
            }
        }

        bdel.setBounds(60, 380, 100, 40);
        ventana.add(bdel);

        bclr.setBounds(180, 380, 100, 40);
        ventana.add(bclr);

        cientifica.setBounds(30, 0, 100, 40);
        ventana.add(cientifica);

        bPI.setBounds(60, 440, 100, 40);
        ventana.add(bPI);
        bPI.setVisible(false);

        bCos.setBounds(180, 440, 100, 40);
        ventana.add(bCos);
        bCos.setVisible(false);

        cb.setBounds(130, 10, 100, 20);
        ventana.add(cb);
        bSerie.setBounds(60,500,100,40);

        ventana.add(bSerie);
        //AL FINAL SIEMPRE
        ventana.setVisible(true);
    }

    private void eventos(){
        bclr.addActionListener(this);
        bdel.addActionListener(this);
        for(JButton  x : botones){
            x.addActionListener(this);
        }
        cientifica.addChangeListener(new Listener());
        bPI.addActionListener(this);
        bSerie.addActionListener(new Listener());
        cb.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                if(cb.getSelectedIndex() == 0) ventana.setSize(350,500);
                else ventana.setSize(350, 600);
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == bclr) { //Delete text
            t.setText("");
        }
        if (e.getSource() == bdel) { //Deletes char
            try{
                StringBuilder s = new StringBuilder(t.getText());
                s.deleteCharAt(s.length() -1);
                t.setText(s.toString());
            }
            catch(StringIndexOutOfBoundsException ex){ //Excepcion if null

            }

        }
        for (int i = 0; i < 11; i++) { //10 numbers + point
            if (e.getSource() == botones[i]) {
                t.setText(t.getText().concat(botones[i].getText()));
            }

        }

        try{
            if (e.getSource() == botones[11]){ //sum
                operacion = 1;
                a = Double.parseDouble(t.getText());
                t.setText("");

            }
            if (e.getSource() == botones[12]){ //subs
                operacion = 2;
                a = Double.parseDouble(t.getText());
                t.setText("");

            }
            if (e.getSource() == botones[13]){ //mult
                operacion = 3;
                a = Double.parseDouble(t.getText());
                t.setText("");

            }
            if (e.getSource() == botones[14]){ //div
                operacion = 4;
                a = Double.parseDouble(t.getText());
                t.setText("");

            }
            if (e.getSource() == botones[15]) { //equal
                try{
                    operar();
                }catch(NANException ex){
                    t.setText("Undefined result");
                }catch(ArithmeticException ex){
                    t.setText("Div by zero");
                }
            }

        }catch(NumberFormatException ex){

        }
        if (e.getSource() == bPI) {
            t.setText(Double.toString(Math.PI));
        }
        t.requestFocus();
    }

    private void operar() throws NANException{
        b = Double.parseDouble(t.getText());
        switch(operacion){
            case 1:
                resultado = a+b;
                break;
            case 2:
                resultado = a-b;
                break;
            case 3:
                resultado = a*b;
                break;
            case 4:
                resultado = a/b;
                if(Double.isNaN(resultado)){
                    throw new NANException();
                }
                if(Double.isInfinite(resultado)){
                    throw new ArithmeticException();
                }
                break;
        }
        t.setText(Double.toString(resultado));
    }

    private class Listener implements ChangeListener, ActionListener {

        @Override
        public void stateChanged(ChangeEvent e) {
            if (cientifica.isSelected()) {
                ventana.setSize(350, 550);
                bPI.setVisible(true);
                bCos.setVisible(true);
            } else {
                ventana.setSize(350, 500);
                bPI.setVisible(false);
                bCos.setVisible(false);
            }
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == bSerie) {
                t.setText("Waiting");
            }
        }
    }
}