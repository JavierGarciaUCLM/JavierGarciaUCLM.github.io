/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkServer;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author usuario
 */
public class GroupServer extends UnicastRemoteObject implements GroupServerInterface{
    private LinkedList<Group> grupos;
    private Lock lock;
    
    // Clase para grupos
    private class Group {
        String nombre;
        String propietario;
        LinkedList<GroupMember> miembros;
        boolean bloqueoAltasBajas;
        Condition condition;

        Group(String nombre, String propietario) {
            this.nombre = nombre;
            this.propietario = propietario;
            this.miembros = new LinkedList<>();
            this.bloqueoAltasBajas = false;
        }
    }
    
    public GroupServer() throws RemoteException {
        super();
        this.grupos = new LinkedList<>();
        this.lock = new ReentrantLock();
    }
    
    @Override // Creación de grupo
     public boolean createGroup(String galias, String oalias, String ohostname) throws RemoteException {
        lock.lock();
        try {
            for (Group g : grupos) {
                if (g.nombre.equals(galias)) {
                    return false; 
                }
            }
            Group nuevoGrupo = new Group(galias, oalias);
            nuevoGrupo.miembros.add(new GroupMember(oalias, ohostname));
            grupos.add(nuevoGrupo);
            return true;
        } finally {
            lock.unlock();
        }
    }
    
    @Override // Comprobar grupo
    public boolean isGroup(String galias) throws RemoteException {
        lock.lock();
        try {
            for (Group g : grupos) {
                if (g.nombre.equals(galias)) {
                    return true;
                }
            }
            return false;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean removeGroup(String galias, String oalias) throws RemoteException {
        lock.lock();
        try {
            for (Group g : grupos) {
                if (g.nombre.equals(galias) && g.propietario.equals(oalias)) {
                    grupos.remove(g);
                    return true;
                }
            }
            return false;
        } finally {
            lock.unlock();
        }
    }

    @Override // Añadir miembro
    public boolean addMember(String galias, String alias, String hostname) throws RemoteException {
        lock.lock();
        try {
            for (Group g : grupos) {
                if (g.nombre.equals(galias)) {
                    if (g.bloqueoAltasBajas) {
                        g.condition.await(); // Esperar si las altas/bajas están bloqueadas
                    }
                    for (GroupMember miembro : g.miembros) {
                        if (miembro.getNombre().equals(alias)) {
                            return false; // El miembro ya existe
                        }
                    }
                    g.miembros.add(new GroupMember(alias, hostname));
                    return true;
                }
            }
            return false;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RemoteException("Error durante la espera", e);
        } finally {
            lock.unlock();
        }
    }

    @Override // Eliminar miembro
    public boolean removeMember(String galias, String alias) throws RemoteException {
        lock.lock();
        try {
            for (Group g : grupos) {
                if (g.nombre.equals(galias)) {
                    if (g.bloqueoAltasBajas) {
                        g.condition.await(); // Esperar si las altas/bajas están bloqueadas
                    }
                    if (g.propietario.equals(alias)) {
                        return false; // No se puede eliminar al propietario del grupo
                    }
                    return g.miembros.removeIf(miembro -> miembro.getNombre().equals(alias));
                }
            }
            return false;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RemoteException("Error durante la espera", e);
        } finally {
            lock.unlock();
        }
    }

    @Override // Comprobar miembros grupo
    public boolean isMember(String galias, String alias) throws RemoteException {
        lock.lock();
        try {
            for (Group g : grupos) {
                if (g.nombre.equals(galias)) {
                    for (GroupMember miembro : g.miembros) {
                        if (miembro.getNombre().equals(alias)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        } finally {
            lock.unlock();
        }
    }

    @Override // Dueño
    public String Owner(String galias) throws RemoteException {
        lock.lock();
        try {
            for (Group g : grupos) {
                if (g.nombre.equals(galias)) {
                    return g.propietario;
                }
            }
            return null;
        } finally {
            lock.unlock();
        }
    }

    @Override // Echar miembro
    public boolean StopMembers(String galias) throws RemoteException {
        lock.lock();
        try {
            for (Group g : grupos) {
                if (g.nombre.equals(galias)) {
                    g.bloqueoAltasBajas = true;
                    return true;
                }
            }
            return false;
        } finally {
            lock.unlock();
        }
    }

    @Override // Permitir miembro
    public boolean AllowMembers(String galias) throws RemoteException {
        lock.lock();
        try {
            for (Group g : grupos) {
                if (g.nombre.equals(galias)) {
                    g.bloqueoAltasBajas = false;
                    g.condition.signalAll(); // Desbloquear todos los hilos esperando
                    return true;
                }
            }
            return false;
        } finally {
            lock.unlock();
        }
    }

    @Override // Listado de miembros
    public LinkedList<String> ListMembers(String galias) throws RemoteException {
        lock.lock();
        try {
            for (Group g : grupos) {
                if (g.nombre.equals(galias)) {
                    LinkedList<String> nombres = new LinkedList<>();
                    for (GroupMember miembro : g.miembros) {
                        nombres.add(miembro.getNombre());
                    }
                    return nombres;
                }
            }
            return null;
        } finally {
            lock.unlock();
        }
    }

    @Override // Listado de grupos
    public LinkedList<String> ListGroups() throws RemoteException {
        lock.lock();
        try {
            LinkedList<String> nombresGrupos = new LinkedList<>();
            for (Group g : grupos) {
                nombresGrupos.add(g.nombre);
            }
            return nombresGrupos;
        } finally {
            lock.unlock();
        }
    }
}
