package pkServer;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class GroupServerMain {
    public static void main(String[] args) throws MalformedURLException {
        
        System.setProperty("java.rmi.server.hostname", "172.20.10.13");
        System.setProperty("java.rmi.server.port", "1099");
        try {
            System.setProperty("java.security.policy", "/home/usuario/NetBeansProjects/security.policy");
            if (System.getSecurityManager() == null) {
                System.setSecurityManager(new SecurityManager());
            }
            
            Registry registry;
            try {
                registry = LocateRegistry.createRegistry(1099);
                System.out.println("El registro RMI ha sido creado en el puerto 1099");
            } catch (RemoteException e) {
                registry = LocateRegistry.getRegistry(1099);
                System.out.println("EL registro RMI ya estaba en ejecución, se usará el existente");
            }

            GroupServer server = new GroupServer();
            Naming.rebind("rmi://172.20.10.13:1099/GroupServer", server);
            System.out.println("Servidor RMI iniciado y registrado");
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
