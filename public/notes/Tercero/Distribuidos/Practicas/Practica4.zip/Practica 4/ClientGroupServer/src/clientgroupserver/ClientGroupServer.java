import pkServer.GroupServerInterface;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;


public class ClientGroupServer {
    public static void main(String[] args) {
        try {
            System.setProperty("java.security.policy", "/home/usuario/NetBeansProjects/security.policy");
            System.setSecurityManager(new SecurityManager());

            
            Registry registry = LocateRegistry.getRegistry("IPaConectar", 1099);
            GroupServerInterface server = (GroupServerInterface) registry.lookup("GroupServer");

            Scanner scanner = new Scanner(System.in);
        
            System.out.print("Introduce tu alias: ");
            String alias = scanner.nextLine();
            String hostname = java.net.InetAddress.getLocalHost().getHostName();

            boolean running = true;
            while (running) {
            System.out.println("Opción 1: Crear grupo");
            System.out.println("Opción 2: Eliminar grupo");
            System.out.println("Opción 3: Añadir como miembro de un grupo");
            System.out.println("Opción 4: Eliminar como miembro de un grupo");
            System.out.println("Opción 5: Bloquear altas y bajas de un grupo");
            System.out.println("Opción 6: Desbloquear altas y bajas de un grupo");
            System.out.println("Opción 7: Mostrar miembros del grupo");
            System.out.println("Opción 8: Mostrar grupos actuales");
            System.out.println("Opción 9: Comprobar si un grupo existe");
            System.out.println("Opción 10: Mostrar propietario de un grupo");
            System.out.println("Opción 11: Comprobar si soy propietario de un grupo");
            System.out.println("Opción 12: Terminar ejecución");

            int option = scanner.nextInt();
            scanner.nextLine();
            switch(option){
            case(1):
                System.out.print("Introduce el nombre del grupo a crear: ");
                String nombreGrupo = scanner.nextLine();
                boolean creado = server.createGroup(nombreGrupo, alias, hostname);
                if (creado) {
                    System.out.println("Grupo creado exitosamente.");
                } else {
                    System.out.println("El grupo ya existe.");
                }
                break;
                
            case(2):
                System.out.print("Introduce el nombre del grupo a eliminar: ");
                String grupoEliminar = scanner.nextLine();
                boolean eliminado = server.removeGroup(grupoEliminar, alias);
                if (eliminado) {
                    System.out.println("Grupo eliminado exitosamente.");
                } else {
                    System.out.println("No se pudo eliminar el grupo. Verifica si eres el propietario.");
                }
                break;
                
            case(3):
                System.out.println("Introduce el nombre del grupo al que deseas unirte: ");
                String grupoAUnirse = scanner.nextLine();
                boolean añadido = server.addMember(grupoAUnirse, alias, hostname);
                if(añadido){
                    System.out.println("Te has añadido correctamente al grupo");
                } else {
                    System.out.println("No se pudo añadir al grupo. Verifica si existe o si las altas están bloqueadas");
                }
                
                break;
                
            case(4):
                System.out.println("Introduce el nombre del grupo del que deseas eliminarte");
                String grupoAEliminarse = scanner.nextLine();
                boolean eliminadode = server.removeMember(grupoAEliminarse, alias);
                if(eliminadode){
                    System.out.println("Te has eliminado del grupo exitosamente");
                } else {
                    System.out.println("No se pudo eliminar del grupo. Verifica si el grupo existe");
                }
                break;
                
            case(5):
                System.out.println("Introduce el nombre del grupo del que bloquear las altas y bajas");
                String grupoABloquear = scanner.nextLine();
                boolean bloquear = server.StopMembers(grupoABloquear);
                if(bloquear){
                    System.out.println("Se han bloqueado las altas y las bajas de este grupo exitosamente");
                }
                else {
                    System.out.println("No se han podido bloquear las altas y bajas de este grupo. Verifica si el grupo existe");
                }
                break;
                
            case(6):
                System.out.println("INtroduce el nombre del grupo del que desbloquear las altas y bajas");
                String grupoADesbloquear = scanner.nextLine();
                boolean desbloquear = server.AllowMembers(grupoADesbloquear);
                if(desbloquear){
                    System.out.println("Las altas y bajas de este grupo han sido desbloqueadas exitosamente");
                } else{
                    System.out.println("Las altas y bajas de este grupo no han podido desbloquearse. Verifica si el grupo existe");
                }
                break;
                
            case(7):
                System.out.println("Introduce el nombre del grupo del que mostrar los miembros");
                String grupoMostrarMembros = scanner.nextLine();
                System.out.println("Miembros del grupo "+grupoMostrarMembros+": "+ server.ListMembers(grupoMostrarMembros));
                break;
                
            case(8):
                System.out.println("Grupos actuales "+ server.ListGroups());
                break;
                
            case(9):
                System.out.println("Introduce el nombre del grupo a comprobar");
                String comprobar = scanner.nextLine();
                if(server.isGroup(comprobar)){
                    System.out.println("El grupo existe");
                   
                }
                else{
                    System.out.println("EL grupo no existe");
                }
                break;
                
            case(10):
                System.out.print("Introduce el nombre del grupo para mostrar el propietario: ");
                String grupoPropietario = scanner.nextLine();
                System.out.println("Propietario del grupo " + grupoPropietario + ": " + server.Owner(grupoPropietario));
                break;
                
            case(11):
                System.out.print("Introduce el nombre del grupo para comprobar si eres miembro: ");
                String grupoMiembro = scanner.nextLine();
                if (server.isMember(grupoMiembro, alias)) {
                    System.out.println("Eres miembro del grupo.");
                } else {
                    System.out.println("No eres miembro del grupo.");
                }
                break;
                
            case(12):
                System.out.println("Terminando la ejecución del cliente.");
                running = false;
                break;
                
            default:
                System.out.println("Opción no valida");
                }      
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}