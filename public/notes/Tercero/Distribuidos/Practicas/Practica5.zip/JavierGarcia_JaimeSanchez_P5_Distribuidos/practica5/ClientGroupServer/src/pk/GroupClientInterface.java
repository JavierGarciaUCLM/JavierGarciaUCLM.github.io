/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.LinkedList;

/**
 *
 * @author usuario
 */
public interface GroupClientInterface extends Remote {
    void DepositMessage(GroupMessage msg) throws RemoteException;
    byte[] receiveGroupMessage(String alias) throws RemoteException;
}
