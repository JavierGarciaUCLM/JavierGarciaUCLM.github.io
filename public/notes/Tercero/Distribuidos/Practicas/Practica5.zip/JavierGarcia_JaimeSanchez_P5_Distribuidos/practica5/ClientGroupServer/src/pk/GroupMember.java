/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk;

import java.io.Serializable;

/**
 *
 * @author usuario
 */
public class GroupMember implements Serializable{
    String nombre;
    String hostname;
    int port;

    public GroupMember(String nombre, String hostname, int port) {
        this.nombre = nombre;
        this.hostname = hostname;
        this.port= port;
    }
    
}
