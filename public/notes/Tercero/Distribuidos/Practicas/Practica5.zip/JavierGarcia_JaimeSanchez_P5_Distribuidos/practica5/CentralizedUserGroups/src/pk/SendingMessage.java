/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk;

import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.util.Callback;

/**
 *
 * @author usuario
 *
 */
public class SendingMessage extends Thread{

    public SendingMessage(String sender, String galias,GroupMessage msg) {
        this.sender = sender;
        this.galias = galias;
        this.msg=msg;
    }
    String sender;
    String galias;
    GroupMessage msg;
    
    @Override
    public void run(){
        try {
            Registry registry = LocateRegistry.getRegistry(1099);
            GroupClientInterface client = (GroupClientInterface) registry.lookup("GroupClientServer");
            try {
                Thread.sleep(30000);
                client.DepositMessage(msg);
            } catch (InterruptedException ex) {
                Logger.getLogger(SendingMessage.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (RemoteException ex) {
            Logger.getLogger(SendingMessage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NotBoundException ex) {
            Logger.getLogger(SendingMessage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
