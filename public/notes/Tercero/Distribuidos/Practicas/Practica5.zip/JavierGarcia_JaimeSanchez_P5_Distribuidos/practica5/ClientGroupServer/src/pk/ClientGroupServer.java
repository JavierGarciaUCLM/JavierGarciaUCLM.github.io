/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author usuario
 */
public class ClientGroupServer implements GroupClientInterface{

    /**
     * @param args the command line arguments
     */
    private ReentrantLock lock = new ReentrantLock(true);
    private Queue messageQueue= new LinkedList<GroupMessage>();
    private final Condition waitMessage= lock.newCondition();

    public ClientGroupServer() throws RemoteException{
        super();
        if (System.getSecurityManager()==null){
            System.setProperty("java.security.policy","/home/usuario/NetBeansProjects/client-policy");
            System.setSecurityManager(new SecurityManager());
        }
    }
    
    

    
    public static void main(String[] args) throws UnknownHostException, RemoteException, NotBoundException, InterruptedException {
        Scanner scanner = new Scanner(System.in);
        String alias;
        String hostname;
        ClientGroupServer client= new ClientGroupServer();
        Registry registry = LocateRegistry.getRegistry(1099);
        GroupServerInterface server = (GroupServerInterface) registry.lookup("GroupServer");
        
        System.out.print("Introduce tu Alias >> "); // Pedir el Alias del Miembro
        alias = scanner.nextLine();
        hostname = InetAddress.getLocalHost().getHostName();
        System.out.println("introduce tu puerto");
        int port= scanner.nextInt();
        
        int opt = 0;
        String aux;
        String groupName;
        boolean result;
        LinkedList<String> list_result;
        

        
        while (opt != 14) {
            System.out.print("\n1.- Crear grupo\n2.- Eliminar grupo\n3.- Añadir miembro (self)\n4.- Eliminar miembro (self)\n5.- Bloquear grupo\n6.- Desbloquear grupo\n7.- Mostrar miembros de grupo\n8.- Mostrar grupos\n9.- Comprobar existencia de grupo\n10.- Mostrar propietario de grupo\n11.- Mostrar membresía de grupo\n12.- Mandar Mensaje\n 13 leer mensaje\n 14 TERMINAR EJECUCIÓN\n  - Introduce una opción >> ");
            opt = scanner.nextInt();
            scanner.nextLine();

            switch(opt) {
                case 1:
                    System.out.print("Introduce el Alias del grupo para crear >> ");
                    aux = scanner.nextLine();
                    result = server.createGroup(aux, alias, hostname,port);
                    System.out.print(result? "Grupo creado exitosamente" : "Ya existe un grupo con ese Alias");
                    break;
                case 2:
                    System.out.print("Introduce el Alias del grupo para eliminar >> ");
                    aux = scanner.nextLine();
                    result = server.removeGroup(aux, alias);
                    System.out.print(result? "Grupo eliminado exitosamente" : "El grupo no existe o no eres el propietario");
                    break;
                case 3:
                    System.out.print("Introduce el Alias del grupo al que quieres unirte >> ");
                    aux = scanner.nextLine();
                    result = server.addMember(aux, alias, hostname,port);
                    System.out.print(result? "Membresía otorgada exitosamente" : "El grupo no existe o ya eres miembro");
                    break;
                case 4:
                    System.out.print("Introduce el Alias del grupo que quieres abandonar >> ");
                    aux = scanner.nextLine();
                    result = server.removeMember(aux, alias);
                    System.out.print(result? "Membresía revocada exitosamente" : "El grupo no existe o no eres miembro o eres el propietario");
                    break;
                case 5:
                    System.out.print("Introduce el Alias del grupo del que quieres bloquear altas y bajas >> ");
                    aux = scanner.nextLine();
                    result = server.StopMembers(aux);
                    System.out.print(result? "Grupo bloqueado exitosamente" : "El grupo no existe");
                    break;
                case 6:
                    System.out.print("Introduce el Alias del grupo del que quieres habilitar altas y bajas >> ");
                    aux = scanner.nextLine();
                    result = server.AllowMembers(aux);
                    System.out.print(result? "Grupo habilitado exitosamente" : "El grupo no existe");
                    break;
                case 7:
                    System.out.print("Introduce el Alias del grupo del que quieres mostrar sus miembros >> ");
                    aux = scanner.nextLine();
                    list_result = server.ListMembers(aux);
                    System.out.print("Lista de miembros: " + list_result);
                    break;
                case 8:
                    list_result = server.ListGroups();
                    System.out.print("Lista de grupos: " + list_result);
                    break;
                case 9:
                    System.out.print("Introduce el Alias del grupo del que quieres comprobar su existencia >> ");
                    aux = scanner.nextLine();
                    result = server.isGroup(aux);
                    System.out.print(result? "El grupo existe" : "El grupo no existe");
                    break;
                case 10:
                    System.out.print("Introduce el Alias del grupo del que quieres conocer su propietario >> ");
                    aux = scanner.nextLine();
                    aux = server.Owner(aux);
                    System.out.print(aux != null? "El propietario de ese grupo es: " + aux : "El grupo no existe");
                    break;
                case 11:
                    System.out.print("Introduce el Alias del grupo del que quieres comprobar tu membresía >> ");
                    aux = scanner.nextLine();
                    result = server.isMember(aux, alias);
                    System.out.print(result? "Eres miembro de ese grupo" : "No eres miembro o el grupo no existe");
                    break;
                case 12:
                    System.out.println("Introduce el nombre del grupo al que quieras mandar el mensaje");
                    groupName=scanner.nextLine();
                    System.out.println("Introduce tu mensaje");
                    aux=scanner.nextLine();
                    GroupMember gm= new GroupMember(alias, hostname,1099);
                    server.sendGroupMessage(groupName,alias, aux.getBytes());
                    GroupMessage msg= new GroupMessage(groupName,aux.getBytes(),gm);
                    break;
                case 13:
                    System.out.println("Lee el mensaje");
                    aux=client.receiveGroupMessage(alias).toString();
                    System.out.println(aux);
                default:
                    System.out.println("Selecciona una opción válida >:c");
            }
            Thread.sleep(2000);
        }

    }
    
    @Override
    public void DepositMessage(GroupMessage m)throws RemoteException{
        //callback await and signal()
        lock.lock();
        try{
            messageQueue.add(m);
            waitMessage.signalAll();
            
        }finally{
            lock.unlock();
        }
    }
    @Override
    public byte[] receiveGroupMessage(String alias) throws RemoteException{
     try{
        lock.lock();
        Registry registry= LocateRegistry.getRegistry(1099);
        GroupServerInterface server= (GroupServerInterface) registry.lookup("groupServer");
        GroupMessage message;
        Iterator it;
        while(true){
           if (server.isGroup(alias)){
                lock.unlock();
                return null;
              }
            it=messageQueue.iterator();
               while(it.hasNext()){
                   message=(GroupMessage)it.next();
                   if (message.groupName.equals(alias)){
                       messageQueue.remove(message);
                       lock.unlock();
                       return message.Message;
                   }
            }
               waitMessage.await();
        }
     }  catch (InterruptedException ex) {
            Logger.getLogger(ClientGroupServer.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            lock.unlock();
            return null;
        }
    }
    
}
