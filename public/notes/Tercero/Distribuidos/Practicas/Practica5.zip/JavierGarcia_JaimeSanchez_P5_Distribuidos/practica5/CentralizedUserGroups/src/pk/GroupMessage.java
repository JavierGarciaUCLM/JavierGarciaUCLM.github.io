/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk;

import java.io.Serializable;

/**
 *
 * @author usuario
 */
public class GroupMessage implements Serializable{
    byte[] Message;
    GroupMember sender;
    String groupName;
    public GroupMessage(String groupName, byte[] Message, GroupMember sender) {
        this.groupName = groupName;
        this.Message = Message;
        this.sender = sender;
    }
    
}
