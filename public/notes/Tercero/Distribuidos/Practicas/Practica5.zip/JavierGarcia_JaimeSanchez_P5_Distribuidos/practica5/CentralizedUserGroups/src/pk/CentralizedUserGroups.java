/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author usuario
 */
public class CentralizedUserGroups {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            LocateRegistry.createRegistry(1099); //Creando registro en puerto 1099
            
            GroupServer server = new GroupServer();
            Naming.rebind("//localhost/GroupServer", server); //Aportando nombre al registro
            
        } catch (RemoteException ex) {
            System.out.println("El puerto introducido ya está en uso.");
        } catch (MalformedURLException ex) {
            Logger.getLogger(GroupServer.class.getName()).log(Level.SEVERE, null,ex);
        }
    }
    
}
