package pk;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GroupServer extends UnicastRemoteObject implements GroupServerInterface {
    
    public GroupServer() throws RemoteException {
        super();
        if (System.getSecurityManager() == null) {
            System.setProperty("java.security.policy", "/home/usuario/NetBeansProjects/server-policy");
            System.setSecurityManager(new SecurityManager());
        }
    }
    
    private LinkedList<Group> grupos = new LinkedList<>();
    private ReentrantLock lock = new ReentrantLock(true);

    @Override
    public boolean createGroup(String galias, String oalias, String ohostname, int port) throws RemoteException {
        lock.lock();
        try {
            // Verificamos si el grupo ya está creado
            if (isGroup(galias)) return false;
            
            // Creamos un nuevo miembro que será el propietario
            GroupMember miembro = new GroupMember(oalias, ohostname, port);
            
            // Añadimos el nuevo grupo a la lista de grupos
            grupos.add(new Group(galias, miembro));
            return true;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean isGroup(String galias) throws RemoteException {
        lock.lock();
        try {
            // Se recorre la lista en busca del grupo
            for (Group grupo : grupos) {
                if (grupo.nombre.equals(galias)) return true;
            }
            return false;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean removeGroup(String galias, String oalias) throws RemoteException {
        lock.lock();
        try {
            // Eliminamos el grupo sólo si coincide el alias del propietario
            int index = 0;
            for (Group grupo : grupos) {
                if (grupo.nombre.equals(galias) && grupo.propietario.nombre.equals(oalias)) {
                    grupos.remove(index);
                    return true; // Grupo borrado con éxito
                }
                index++;
            }
            return false; // No coincide o no existe
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean addMember(String galias, String alias, String hostname, int port) throws RemoteException {
        lock.lock();
        try {
            //Verificamos si el grupo existe y el usuario no está dentro
            if (!isGroup(galias) || isMember(galias, alias)) return false;
            
            //Se crea un nuevo miembro
            GroupMember miembro = new GroupMember(alias, hostname, port);
            
            //Buscamos el grupo para insertar el miembro
            for (Group grupo : grupos) {
                if (grupo.nombre.equals(galias)) {
                    try {
                        // Esperamos si el grupo está temporalmente bloqueado
                        while (grupo.isBlocked) grupo.condition.await();
                        grupo.miembros.add(miembro);
                        grupo.totalNumber += 1;
                        return true;
                    } catch (InterruptedException ex) {
                        Logger.getLogger(GroupServer.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
            return false;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean removeMember(String galias, String alias) throws RemoteException {
        lock.lock();
        try {
            // Revisamos si el grupo está registrado y el usuario es miembro
            if (!isGroup(galias) || !isMember(galias, alias)) return false;
            
            for (Group grupo : grupos) {
                if (grupo.nombre.equals(galias)) {
                    // Si es el propietario, no se le puede eliminar
                    if (grupo.propietario.nombre.equals(alias)) return false;
                    
                    int index = 0;
                    for (GroupMember miembro : grupo.miembros) {
                        index++;
                        if (miembro.nombre.equals(alias)) {
                            try {
                                // Bloqueo en caso de que el grupo esté inactivo
                                while (grupo.isBlocked) grupo.condition.await();
                                grupo.miembros.remove(index - 1);
                                grupo.totalNumber -= 1;
                                return true;
                            } catch (InterruptedException ex) {
                                Logger.getLogger(GroupServer.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                }
            }
            return false;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean isMember(String galias, String alias) throws RemoteException {
        lock.lock();
        try {
            // Recorremos cada grupo para verificar si alias coincide (equals)
            for (Group grupo : grupos) {
                if (grupo.nombre.equals(galias)) {
                    for (GroupMember miembro : grupo.miembros) {
                        if (miembro.nombre.equals(alias)) return true;
                    }
                }
            }
            return false;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public String Owner(String galias) throws RemoteException {
        lock.lock();
        try {
            // Devolvemos el alias del dueño del grupo
            for (Group grupo : grupos) {
                if (grupo.nombre.equals(galias)) return grupo.propietario.nombre;
            }
            return null;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean StopMembers(String galias) throws RemoteException {
        lock.lock();
        try {
            //Se marca el grupo como block
            if (!isGroup(galias)) return false;
            
            for (Group grupo : grupos) {
                if (grupo.nombre.equals(galias)) {
                    grupo.isBlocked = true;
                    return true;
                }
            }
            return true;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean AllowMembers(String galias) throws RemoteException {
        lock.lock();
        try {
            // Quitamos el bloqueo y notificamos a los que están esperando.
            if (!isGroup(galias)) return false;
            
            for (Group grupo : grupos) {
                if (grupo.nombre.equals(galias)) {
                    grupo.isBlocked = false;
                    grupo.condition.signalAll();
                    return true;
                }
            }
            return true;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public LinkedList<String> ListMembers(String galias) throws RemoteException {
        lock.lock();
        try {
            // Devolvemos un listado con los nombres de los miembros
            for (Group grupo : grupos) {
                if (grupo.nombre.equals(galias)) {
                    LinkedList<String> miembros = new LinkedList<>();
                    for (GroupMember miembro : grupo.miembros) {
                        miembros.add(miembro.nombre);
                    }
                    return miembros;
                }
            }
            return null;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public LinkedList<String> ListGroups() throws RemoteException {
        lock.lock();
        try {
            // Retornamos la lista de todos los grupos que existen
            LinkedList<String> listaGrupos = new LinkedList<>();
            for (Group grupo : this.grupos) {
                listaGrupos.add(grupo.nombre);
            }
            if (listaGrupos.size() != 0) return listaGrupos;
            else return null;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean sendGroupMessage(String galias, String alias, byte[] msg) throws RemoteException {
        lock.lock();
        try {
            // Para enviar el mensaje, primero bloqueamos el grupo
            StopMembers(galias);

            for (Group grupo : this.grupos) {
                //Si el grupo tiene un único miembro, no se envía.
                if (grupo.totalNumber == 1) return false;

                // Enviamos el mensaje a cada integrante
                for (GroupMember member : grupo.miembros) {
                    GroupMessage gm = new GroupMessage(galias, msg, member);
                    SendingMessage smsg = new SendingMessage(alias, galias, gm);
                    smsg.start();
                }
                
                // Aumentamos el contador de mensajes en ese grupo
                if (grupo.nombre.equals(galias)) {
                    grupo.numberOfMsg += 1;
                    return true;
                }
            }
            return false;
        } finally {
            lock.unlock();
        }
    }
    
    public boolean receiveGroupMessage(String galias, String alias, byte[] msg) throws RemoteException {
        lock.lock();
        try {
            //Al recibir el mensaje, decrementamos el contador y en caso de que todos hayan recibido, el grupo se desbloquea
            for (Group grupo : this.grupos) {
                if (grupo.numberOfMsg == 0) {
                    AllowMembers(galias);
                }
                if (grupo.nombre.equals(galias)) {
                    grupo.numberOfMsg -= 1;
                    return true;
                }
            }
            return false;
        } finally {
            lock.unlock();
        }
    }
    
    // Clase interna que representa la estructura básica de un grupo
    public class Group {
        private String nombre;
        private GroupMember propietario;
        private LinkedList<GroupMember> miembros = new LinkedList<>();
        
        private boolean isBlocked = false;
        private Condition condition = lock.newCondition();
        
        private int totalNumber;
        private int numberOfMsg;
        
        protected Group(String nombre, GroupMember propietario) {
            this.nombre = nombre;
            this.propietario = propietario;
            this.miembros.add(propietario);
            this.totalNumber = 1;
            this.numberOfMsg = 0;
        }
    }
}