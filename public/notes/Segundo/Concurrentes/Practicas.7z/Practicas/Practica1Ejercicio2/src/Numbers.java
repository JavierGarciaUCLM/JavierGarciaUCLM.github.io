
public class Numbers {
	public static void main(String args[]){
		for(int i=0;i<=5;i++){
			new T_PrintID(i,3).start();
		}
		System.out.println("Fin");
	}
}
