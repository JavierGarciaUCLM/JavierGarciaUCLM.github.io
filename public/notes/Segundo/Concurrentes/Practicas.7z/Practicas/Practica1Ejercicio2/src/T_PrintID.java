
public class T_PrintID extends Thread{
	private int id;
	private int n;
	
	public T_PrintID(int id,int n){
		this.id=id;
		this.n=n;
	}
	
	public void run(){
		for(int i=1;i<=n;i++){
			System.out.println(this.id);
		}
	}

}
