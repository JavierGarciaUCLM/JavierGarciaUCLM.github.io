
public class main {
	public static void main(String args[]){
		Thread h=Thread.currentThread();
		h.setName("P1");
		for(int i=0;i<=50;i++){
			if(i%2!=0){
				System.out.println(h.getName()+" "+i);
				try{
					Thread.sleep(2000);
				} catch (InterruptedException e){
					e.printStackTrace();
				}
			}
		}
	}

}
