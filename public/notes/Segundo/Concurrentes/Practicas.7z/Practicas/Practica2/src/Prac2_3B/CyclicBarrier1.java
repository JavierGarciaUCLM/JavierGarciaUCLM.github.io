package Prac2_3B;

import java.util.concurrent.Semaphore;

public class CyclicBarrier1 {
	private Semaphore barrier = new Semaphore(0);
    private Semaphore mutex   = new Semaphore(1);
    private int group_size;
    private int arrived = 0;

    public CyclicBarrier1(int group_size) {
	this.group_size = group_size;
    }

    public void await() throws InterruptedException {
    	mutex.acquire();
    	arrived=arrived+1;
    	if(arrived==group_size){
    		for(int i=0;i<=group_size;i++){
    			barrier.release();
    		}
    		arrived=0;
    	}
    	mutex.release();
    	
    	barrier.acquire();
    }

}
