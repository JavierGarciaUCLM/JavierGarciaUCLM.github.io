package Prac2_1A;

/**
 * You can park only if there is at least 1 free slot.
 * You can leave only if there is at least 1 parked car.
 * Create and use semaphores as appropriate.
 */
import java.util.concurrent.Semaphore;


class CarParkControl {

    protected int spaces;
    protected int capacity;
    NumberCanvas cont_;
    Counter counter;
    Semaphore libres;
    Semaphore ocupadas;
    Semaphore mutex;

    CarParkControl(int n) {
        capacity = spaces = n;
        libres=new Semaphore(capacity);
        ocupadas=new Semaphore(0);
        mutex=new Semaphore(1);
        
    }
    
    CarParkControl(int n,NumberCanvas cont) {
        cont_ = cont;
        capacity = spaces = n;
        counter = new Counter(cont_);
        counter.show(spaces);
        libres=new Semaphore(capacity);
        ocupadas=new Semaphore(0);
        mutex=new Semaphore(1);
    }

    void arrive() throws InterruptedException {
    	libres.acquire();
    	mutex.acquire();
        --spaces;
        counter.show(spaces);   
        mutex.release();
        ocupadas.release();
    }

    void leaves() throws InterruptedException{
    	ocupadas.acquire();
    	mutex.acquire();
        ++spaces;
        counter.show(spaces);
        mutex.release();
        libres.release();
     }
}


/********************LLEGADAS*******************************/
class Arriving implements Runnable {

    CarParkControl carpark;
    NumberCanvas display;

    Arriving(CarParkControl c) {
        carpark = c;
    }
    Arriving(CarParkControl c, NumberCanvas n) {
        carpark = c;
        display = n;
    }
    public void run() {
      try {
        while(true) {
          ThreadPanel.rotate(340); 
           carpark.arrive();
          ThreadPanel.rotate(20);           
        }
      } catch (InterruptedException e){}
    }
}

/********************SALIDAS*******************************/

class Leaving implements Runnable {

    CarParkControl carpark;
    NumberCanvas display;

    Leaving(CarParkControl c) {
        carpark = c;
    }
    
    public void run() {
      try {
        while(true) {
          ThreadPanel.rotate(20);
          carpark.leaves();
          ThreadPanel.rotate(340);        
        }
      } catch (InterruptedException e){}
    }
}
/********************COUNTER*******************************/

 class Counter {

    volatile int value=0;
    NumberCanvas display;

   
    Counter(NumberCanvas n) {
        display=n;
    }
    
    void show() {
       display.setvalue(value);   

    }
    
    void show(int n) {
        value = n;
        display.setvalue(value);   
    }
}