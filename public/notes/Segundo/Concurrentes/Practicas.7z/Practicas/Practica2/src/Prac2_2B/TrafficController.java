package Prac2_2B;

/**
 * Remember to move the 'cars_images' folder to the root directory
 * of your project,
 * or write the absolute path to the folder in lines 23,35,27
 * in CarWorld.java. 
 * 
 * Now, cars of the same color do not need to wait: they all move
 * in the same sense. So now the bridge will not only be safe but efficient.
 */

public class TrafficController {
	boolean rojo=false;
	boolean azul=false;
	int contR=0;
	int contA=0;

     
    
    synchronized public void redEnters() {
    	while(azul){
    		try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	rojo=true;
    	contR++;
    }

    synchronized public  void blueEnters() {
    	while(rojo){
    		try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	azul=true;
    	contA++;
    }

     synchronized public  void blueExits() {
    	 contA--;
    	 if(contA==0){
    	 azul=false;
     	notifyAll();
    	 }
    }

    synchronized public  void redExits() {
    	contR--;
    	if(contR==0){
    	rojo=false;
    	notifyAll();
    	}
    }

}