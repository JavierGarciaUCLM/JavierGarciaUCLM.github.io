package Prac2_2Ab;

/**
 * Remember to move the 'cars_images' folder to the root directory
 * of your project,
 * or write the absolute path to the folder in lines 23,35,27
 * in CarWorld.java. 
 */
public class TrafficController {
	boolean ocupado=false;

   synchronized public void redEnters() {
    	while(ocupado){
    		try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	ocupado=true;
    }

   synchronized public  void blueEnters() {
    	while(ocupado){
    		try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	ocupado=true;
	
    }

   synchronized public  void blueExits() {
    	ocupado=false;
    	notifyAll();
    	 
    }

   synchronized public  void redExits() {
    	ocupado=false;
    	notifyAll();
    }

}