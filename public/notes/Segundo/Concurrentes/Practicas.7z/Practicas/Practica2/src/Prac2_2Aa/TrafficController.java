package Prac2_2Aa;

import java.util.concurrent.Semaphore;

/**
 * Remember to move the 'cars_images' folder to the root directory
 * of your project,
 * or write the absolute path to the folder in lines 23,35,27
 * in CarWorld.java. 
 */

public class TrafficController {
	Semaphore mutex = new Semaphore(1);

    public void redEnters() {
    	try {
			mutex.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 
    }

    public  void blueEnters() {
    	try {
			mutex.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
    }

     public  void blueExits() {
    	mutex.release();
    	 
    }

    public  void redExits() {
    	mutex.release();

    }

}