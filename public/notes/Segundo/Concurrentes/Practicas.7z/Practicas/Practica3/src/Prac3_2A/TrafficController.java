package Prac3_2A;

/**
 * Remember to move the 'ass4_images' folder to the root directory
 * of your project,
 * or write the absolute path to the folder in lines 27,29,31
 * in CarWorld.java. 
 * */

public class TrafficController {

   int peatonPas=0,cochePas=0;

    public synchronized void carEnters() {
    	while(peatonPas!=0)
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			cochePas++;
	
    }
     public synchronized void carExits() {
    	cochePas--;
    	if(cochePas==0){
    	 notifyAll();
    	}
    }

    public synchronized void pedestrianEnters() {
    	while(cochePas!=0){
    		try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	peatonPas++;
    }

     public synchronized void pedestrianExits() {
    	 peatonPas--;
    	 if(peatonPas==0){
    	 notifyAll();
    	 }
    }

   

}