package Prac3_2B;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Remember to move the 'ass4_images' folder to the root directory
 * of your project,
 * or write the absolute path to the folder in lines 27,29,31
 * in CarWorld.java. 
 * */

public class TrafficController {
	
	private final ReentrantLock mylock= new ReentrantLock();
	final Condition peatones = mylock.newCondition();
	final Condition coches = mylock.newCondition();
	
	int contPasp=0, contPasc=0;

    public void carEnters() {
    	mylock.lock();
    	try{
    		while(contPasp!=0 || mylock.hasWaiters(peatones)){
    			try {
					coches.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    		contPasc++;
    	}finally{
    		mylock.unlock();
    	}
	
    }
     public void carExits() {
    	 mylock.lock();
     	try{
     		contPasc--;
     		if(contPasc==0){
     			peatones.signalAll();
     		}
     	}finally{
     		mylock.unlock();
     	}
    }

    public void pedestrianEnters() {
    	mylock.lock();
    	try{
    		while(contPasc!=0){
    			try {
					peatones.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    		contPasp++;
    	}finally{
    		mylock.unlock();
    	}
    }

     public void pedestrianExits() {
    	 mylock.lock();
     	try{
     		contPasp--;
     		if(contPasp==0){
     			coches.signalAll();
     		}
     	}finally{
     		mylock.unlock();
     	}
	 
    }

   

}