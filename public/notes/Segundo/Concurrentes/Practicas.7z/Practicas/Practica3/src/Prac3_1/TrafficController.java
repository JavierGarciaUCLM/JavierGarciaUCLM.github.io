package Prac3_1;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Remember to move the 'images' folder to the root directory
 * of your project,
 * or write the absolute path to the folder in lines 23,35,27
 * in CarWorld.java. 
 */

public class TrafficController {
	private final ReentrantLock mylock = new ReentrantLock();
	final Condition vCondRo = mylock.newCondition();
	final Condition vCondAz = mylock.newCondition();
    final static int MAX=3;
    int counterEsp=0,countPasRoj=0,countPasAz=0;
    boolean turn_red;
    
    private void CheckTurn(){
    	counterEsp++;
    	if(counterEsp==MAX){
    		counterEsp=0;
    		turn_red=!turn_red;
    	}
    }
    
    public void redEnters() {
    	mylock.lock();
    	try{
    		while((mylock.hasWaiters(vCondAz) && !turn_red) || countPasAz!=0){
				try {
					vCondRo.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    		countPasRoj++;
    		CheckTurn();
    	}finally{
    	mylock.unlock();
    	}
    }

    public  void blueEnters() {
    	mylock.lock();
    	try{
    		while((mylock.hasWaiters(vCondRo) && turn_red) || countPasRoj!=0){
				try {
					vCondAz.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
				countPasAz++;
				CheckTurn();
    	}finally{
    	mylock.unlock();
    	}
	
    }

     public  void blueExits() {
    	 mylock.lock();
     	try{
     		countPasAz--;
     		vCondRo.signal();
     	}finally{
    	mylock.unlock();
     	}	
    	 
    }

    public  void redExits() {
    	 mylock.lock();
      	try{
      		countPasRoj--;
      		vCondAz.signal();
      	}finally{
     	mylock.unlock();
      	}
	

    }

}