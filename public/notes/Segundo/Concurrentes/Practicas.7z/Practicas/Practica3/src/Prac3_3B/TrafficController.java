package Prac3_3B;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Remember to move the 'ass4_images' folder to the root directory
 * of your project,
 * or write the absolute path to the folder in lines 27,29,31
 * in CarWorld.java. 
 *
 * */

public class TrafficController {
	
	private final ReentrantLock mylock = new ReentrantLock();
	final Condition peatones = mylock.newCondition();
	final Condition coches = mylock.newCondition();
	
	int contPasp=0, contPasc=0, contPaspS=0, contPascS=0;

    public void carEnters() {
    	mylock.lock();
    	try{
    		while(contPasp!=0 || (mylock.hasWaiters(peatones) && contPascS>=5)){
    			try {
    				contPascS=0;
					coches.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    		contPasc++;
			contPascS++;
    	}finally{
    		mylock.unlock();
    	}
	
    }
     public void carExits() {
    	 mylock.lock();
     	try{
     		contPasc--;
     		peatones.signalAll();
     	}finally{
     		mylock.unlock();
     	}
    }

    public void pedestrianEnters() {
    	mylock.lock();
    	try{
    		while(contPasc!=0 || (mylock.hasWaiters(coches) && contPaspS>=10)){
    			try {
    				contPaspS=0;
					peatones.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    		contPasp++;
			contPaspS++;
    	}finally{
    		mylock.unlock();
    	}
    }

     public void pedestrianExits() {
    	 mylock.lock();
      	try{
      		contPasp--;
      		coches.signalAll();
      	}finally{
      		mylock.unlock();
      	}
	 
    }
}