
public class Numbers {
	public static void main(String args[]){
		R_PrintID [] threads = new R_PrintID[6];
		for(int i=0;i<=5;i++){
			threads[i]=new R_PrintID(i,3);
		}
		for(int i=0;i<=5;i++){
			(new Thread(threads[i])).start();
		}
		
	}
}