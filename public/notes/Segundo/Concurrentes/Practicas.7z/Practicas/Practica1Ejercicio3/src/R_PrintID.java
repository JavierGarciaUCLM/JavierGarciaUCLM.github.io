import java.util.Random;



public class R_PrintID implements Runnable{
	private int id;
	private int n;
	
	public R_PrintID(int id,int n){
		this.id=id;
		this.n=n;
	}
	
	public void run(){
		for(int i=1;i<=n;i++){
			System.out.println(this.id);
			
			Random r=new Random();
			
			try{
				Thread.sleep(r.nextInt(1000));
			}catch(InterruptedException e){
				e.printStackTrace();
			}
		}
	}

}
