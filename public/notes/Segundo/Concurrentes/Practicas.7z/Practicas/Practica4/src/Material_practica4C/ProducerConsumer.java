package Material_practica4C;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

class Buffer {
    static final int SIZE = 8;
	int insertIndex, removeIndex, empty, items;
	int[] data;

	private final ReentrantLock mylock = new ReentrantLock();
	final Condition productor = mylock.newCondition();
	final Condition consumir = mylock.newCondition();

	Buffer() {
	   data = new int[SIZE];
	   insertIndex = 0;
	   removeIndex = 0;
	   empty = SIZE;
	   items = 0;
	}

	 void insert(int item)	throws InterruptedException {
		mylock.lock();
		try{
			while (items==SIZE) {
				productor.await();
			}
			
			data[insertIndex] = item;
			System.out.println("[Producer] Insert " +item);
			insertIndex = (1+insertIndex)%SIZE;
			
			items++;
			empty--;
			
			consumir.signalAll();
		}finally{
			mylock.unlock();
		}
	  
	}
	
	 int remove() throws InterruptedException { 
		mylock.lock();
		try{
			while (items==0){
				consumir.await();
			}
			int x = data[removeIndex];
			System.out.println("[Consumer] Remove " +x);
       
			removeIndex = (1+removeIndex)%SIZE;
			
			items--;
			empty++;
			
			productor.signalAll();
			return x;
		}finally{
			mylock.unlock();
		}
   }
}


class Producer extends Thread {
	Buffer buffer;

	Producer(Buffer b) {
		buffer = b;
	}

	public void run() {
		java.util.Random r = new java.util.Random();
		while (true) {
		  try {
			 Thread.sleep(1000);
		     buffer.insert(r.nextInt(200));
		  } catch (InterruptedException e) {
		      e.printStackTrace(); } 
	   }
	} 
}

class Consumer extends Thread {
	Buffer buffer;
	Consumer(Buffer b) {
		buffer = b;
	}

	public void run() {
		while (true) {
		  try {
			  Thread.sleep(1000);
		      int x = buffer.remove();
		      System.out.println(x);
		  } catch (InterruptedException e) {
		      e.printStackTrace();} 
	    }	
	} 
 }

public class ProducerConsumer {

	public static void main(String args[]) {

	   Buffer buffer = new Buffer();
	   Producer[] vp = new Producer[4];
	   Consumer[] vc = new Consumer[3];
	   
	   for(int i=0;i<4;i++){
		   vp[i]=new Producer(buffer);
		   vp[i].start();
	   }
	   for(int i=0;i<3;i++){
		   vc[i]=new Consumer(buffer);
		   vc[i].start();
	   }
	}
}


