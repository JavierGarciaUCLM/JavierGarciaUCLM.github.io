
/* Sleeves = mangas, Bodies = cuerpos, Jumper = jersey */

class Bodybasket {
    static final int CAPBODIES = 8;
	int  bodies;
	
	Bodybasket() {   
	   bodies = 0;
	}

	synchronized void insertbody()	throws InterruptedException {
	   while (bodies == CAPBODIES){
        wait(); //WAIT hasta que tengamos espacio en el blanket
       }
       bodies ++;
	  /* System.out.println("One body more. Total: " +bodies);  */
	   System.out.println("Un cuerpo mas. Total: " +bodies);
       notifyAll(); // notifica a todos los que esten esperando
	}
	
	synchronized void removebody() throws InterruptedException {
        while (bodies == 0){
            wait(); //WAIT hasta que los bodies esten en el blanket
        }
       bodies--;
	   /*System.out.println("One body less. Total: " +bodies); */
	   System.out.println("Un cuerpo menos. Total: " +bodies);
       notifyAll(); // notifica a todos los que esten esperando
   }
}

class Sleevebasket {
    static final int CAPSLEEVES = 8;
	int  sleeves;
	
	Sleevebasket() {   
	   sleeves = 0;
	}

	synchronized void insertsleeve()	throws InterruptedException {
        while (sleeves == CAPSLEEVES){
            wait(); // ESPERO para poder rellenar 
        }
	   sleeves ++;
	  /* System.out.println("One sleeve more. Total: " +sleeves); */  
	   System.out.println("Una manga mas. Total: " +sleeves);
       notifyAll(); // notifico al resto
	}
	
	synchronized void removesleeve() throws InterruptedException {
        while (sleeves < 2){
            wait();
        }
       sleeves --;
	   /*System.out.println("One sleeve less. Total: " +sleeves);*/ 
	   System.out.println("Una manga menos. Total: " +sleeves);
       notifyAll();
   }
}


class Pjoin extends Thread {
	Bodybasket mybody; Sleevebasket mysleeve;

	Pjoin(Bodybasket bodybasket, Sleevebasket sleevebasket) {
		mybody= bodybasket;
		mysleeve = sleevebasket;
	}

	public void run() {
		java.util.Random r = new java.util.Random();
		while (true) {
		  try {
			 Thread.sleep(r.nextInt(50));
		     mybody.removebody();
		     mysleeve.removesleeve();
		     mysleeve.removesleeve();
		    /* System.out.println("One more jumper assembled"); */
		     System.out.println("Un jersey montado mas");
		  } catch (InterruptedException e) {
		      e.printStackTrace(); } 
	   }
	} 
}

class Psleeve extends Thread {
	 Sleevebasket sleeveb;

	Psleeve(Sleevebasket sleevebasket) {
			sleeveb = sleevebasket;
	}

	public void run() {
		java.util.Random r = new java.util.Random();
		while (true) {
		  try {
			 Thread.sleep(r.nextInt(50));
		      sleeveb.insertsleeve();
		  } catch (InterruptedException e) {
		      e.printStackTrace(); } 
	   }
	} 
}

class Pbodies extends Thread {
	 Bodybasket bodyb;

	Pbodies(Bodybasket bodybasket) {
			bodyb = bodybasket;
	}

	public void run() {
		java.util.Random r = new java.util.Random();
		while (true) {
		  try {
			 Thread.sleep(r.nextInt(50));
		      bodyb.insertbody();
		  } catch (InterruptedException e) {
		      e.printStackTrace(); } 
	   }
	} 
}

public class examen2023Synchronized {

    private static final int NUM_SLEEVES = 2;
    private static final int NUM_BODIES = 1;

	public static void main(String args[]) {

	   Bodybasket bodybasket = new Bodybasket();
	   Sleevebasket sleevebasket = new Sleevebasket();

        Pbodies bodyProducer = new Pbodies(bodybasket);
        Psleeve sleeveProducer = new Psleeve(sleevebasket);
        Pjoin jumperAssembler = new Pjoin(bodybasket, sleevebasket);
		
        bodyProducer.start();
        sleeveProducer.start();
        jumperAssembler.start();

	}
}


