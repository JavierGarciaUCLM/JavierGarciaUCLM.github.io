package Material_practica4;

import java.util.concurrent.Semaphore;

class Buffer {
    static final int SIZE = 8;
	int insertIndex, removeIndex, empty, items;
	int[] data;
	
	Semaphore sMutex,sItems,sVacio ;

	Buffer() {
	   data = new int[SIZE];
	   insertIndex = 0;
	   removeIndex = 0;
	   empty = SIZE;
	   items = 0;
	   sMutex=new Semaphore(1);
	   sItems=new Semaphore(0);
	   sVacio=new Semaphore(SIZE);
	}

	 void insert(int item)	throws InterruptedException {
	  
	   sVacio.acquire();
	   sMutex.acquire();
	   
	   data[insertIndex] = item;
	   System.out.println("[Producer] Insert " +item);
	   insertIndex = (1+insertIndex)%SIZE;
	   
	   sMutex.release();
	   sItems.release();

	  
	}
	
	 int remove() throws InterruptedException {
      
	   sItems.acquire();
	   sMutex.acquire();
		 
       int x = data[removeIndex];
       System.out.println("[Consumer] Remove " +x);
       
       removeIndex = (1+removeIndex)%SIZE;
       
       sMutex.release();
       sVacio.release();

       return x;
   }
}


class Producer extends Thread {
	Buffer buffer;

	Producer(Buffer b) {
		buffer = b;
	}

	public void run() {
		java.util.Random r = new java.util.Random();
		while (true) {
		  try {
			 Thread.sleep(1000);
		     buffer.insert(r.nextInt(200));
		  } catch (InterruptedException e) {
		      e.printStackTrace(); } 
	   }
	} 
}

class Consumer extends Thread {
	Buffer buffer;
	Consumer(Buffer b) {
		buffer = b;
	}

	public void run() {
		while (true) {
		  try {
			  Thread.sleep(1000);
		      int x = buffer.remove();
		      System.out.println(x);
		  } catch (InterruptedException e) {
		      e.printStackTrace();} 
	    }	
	} 
 }

public class ProducerConsumer {

	public static void main(String args[]) {

	   Buffer buffer = new Buffer();
	   Producer[] vp = new Producer[4];
	   Consumer[] vc = new Consumer[3];
	   
	   for(int i=0;i<4;i++){
		   vp[i]=new Producer(buffer);
		   vp[i].start();
	   }
	   for(int i=0;i<3;i++){
		   vc[i]=new Consumer(buffer);
		   vc[i].start();
	   }
	}
}


