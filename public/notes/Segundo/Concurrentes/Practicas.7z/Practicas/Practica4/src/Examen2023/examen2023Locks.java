import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;
/* Sleeves = mangas, Bodies = cuerpos, Jumper = jersey */

class Bodybasket {
    static final int CAPBODIES = 8;
	int  bodies;

	private final ReentrantLock mylock = new ReentrantLock();
	private Condition notFull = mylock.newCondition();
	private Condition notEmpty = mylock.newCondition();

	Bodybasket() {   
	   bodies = 0;
	}

	void insertbody()	throws InterruptedException {
		mylock.lock();
		try{
			while (bodies == CAPBODIES){
				notFull.await();	
			}
		bodies ++;
	  	/* System.out.println("One body more. Total: " +bodies);  */
	   	System.out.println("Un cuerpo mas. Total: " +bodies);
		notEmpty.signalAll();
		} finally {
			mylock.unlock();
		}

	}
	
	void removebody() throws InterruptedException {
       mylock.lock();
	   try{ 
		while (bodies == 0){
			notEmpty.await();
		}
       	bodies--;
	   	/*System.out.println("One body less. Total: " +bodies); */
	   	System.out.println("Un cuerpo menos. Total: " +bodies);
		notFull.signalAll();
	   	} finally {
		mylock.unlock();
	   }
   }
}

class Sleevebasket {
    static final int CAPSLEEVES = 8;
	int  sleeves;
	
	private final ReentrantLock mylock = new ReentrantLock();
	private Condition notFull = mylock.newCondition();
	private Condition notEmpty = mylock.newCondition();

	Sleevebasket() {   
	   sleeves = 0;
	}

	void insertsleeve()	throws InterruptedException {
		mylock.lock();
		try{
			while (sleeves == CAPSLEEVES){
				notFull.await();
			}
		
	   	sleeves ++;
	  	/* System.out.println("One sleeve more. Total: " +sleeves); */  
	   	System.out.println("Una manga mas. Total: " +sleeves);
		notEmpty.signal();
		} finally{
			mylock.unlock();
		}
	}
	
	void removesleeve() throws InterruptedException {
       	mylock.lock();
		try{
			while (sleeves < 2){
				notEmpty.await();
			}
			
		sleeves -= 2;
	   	/*System.out.println("One sleeve less. Total: " +sleeves);*/ 
	   	System.out.println("Una manga menos. Total: " +sleeves);
		notFull.signalAll();
		} finally {
			mylock.unlock();
		}
   }
}


class Pjoin extends Thread {
	Bodybasket mybody; Sleevebasket mysleeve;

	Pjoin(Bodybasket bodybasket, Sleevebasket sleevebasket) {
		mybody= bodybasket;
		mysleeve = sleevebasket;
	}

	public void run() {
		java.util.Random r = new java.util.Random();
		while (true) {
		  try {
			 Thread.sleep(r.nextInt(50));
		     mybody.removebody();
		     mysleeve.removesleeve();
		     mysleeve.removesleeve();
		    /* System.out.println("One more jumper assembled"); */
		     System.out.println("Un jersey montado mas");
		  } catch (InterruptedException e) {
		      e.printStackTrace(); } 
	   }
	} 
}

class Psleeve extends Thread {
	 Sleevebasket sleeveb;

	Psleeve(Sleevebasket sleevebasket) {
			sleeveb = sleevebasket;
	}

	public void run() {
		java.util.Random r = new java.util.Random();
		while (true) {
		  try {
			 Thread.sleep(r.nextInt(50));
		      sleeveb.insertsleeve();
		  } catch (InterruptedException e) {
		      e.printStackTrace(); } 
	   }
	} 
}

class Pbodies extends Thread {
	 Bodybasket bodyb;

	Pbodies(Bodybasket bodybasket) {
			bodyb = bodybasket;
	}

	public void run() {
		java.util.Random r = new java.util.Random();
		while (true) {
		  try {
			 Thread.sleep(r.nextInt(50));
		      bodyb.insertbody();
		  } catch (InterruptedException e) {
		      e.printStackTrace(); } 
	   }
	} 
}

public class examen2023Locks {

	public static void main(String args[]) {

	   Bodybasket bodybasket = new Bodybasket();
	   Sleevebasket sleevebasket = new Sleevebasket();

		Pbodies bodyProducer = new Pbodies(bodybasket);
		Psleeve sleeveProducer = new Psleeve(sleevebasket);
		Pjoin jumperAssembler = new Pjoin(bodybasket, sleevebasket);

		bodyProducer.start();
		sleeveProducer.start();
		jumperAssembler.start();


	}
}


