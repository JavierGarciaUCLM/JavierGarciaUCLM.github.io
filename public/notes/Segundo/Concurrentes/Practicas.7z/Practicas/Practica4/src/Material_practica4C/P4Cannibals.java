package Material_practica4C;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;


class Tribe {

	int cauldron;
	int capacity;
	
	private final ReentrantLock mylock = new ReentrantLock();
	final Condition canibal = mylock.newCondition();
	final Condition cocinero = mylock.newCondition();
	
	
	public Tribe(int cap){
		this.cauldron=cap;
		this.capacity=cap;
	}

	public void eat(int id){
		mylock.lock();
		try{
			while(cauldron==0){
				if(mylock.hasWaiters(cocinero)){
					cocinero.signal();
				}
				try {
					canibal.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			cauldron--;
			System.out.println(id+") Ya he comido y me voy");
		}finally{
			mylock.unlock();
		}
	}
	
	public void refill(){
		mylock.lock();
		try{
			try {
				cocinero.await();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			cauldron=capacity;
			System.out.println("Ya he rellenado el caldero");
			canibal.signalAll();
		}finally{
			mylock.unlock();
		}
	}
}

class Cannibal extends Thread{
	Tribe tribe;
	int ID;
	
	public Cannibal(Tribe tribu,int id){
		this.tribe=tribu;
		this.ID=id;
	}
	
	public void run(){
		tribe.eat(ID);
	}
	
}

class Cook extends Thread{
	Tribe tribe;
	int cook_times;
	
	public Cook(Tribe tribu,int cook_t){
		this.tribe=tribu;
		this.cook_times=cook_t;	
	}
	
	public void run(){
		for(int i=0; i<cook_times;i++){
			tribe.refill();
		}
		
	}
}

public class P4Cannibals {
	
	private static int NUM_CANNIBALS = 10;
	
	private static int CAPACITY = 3;
	
	public static void main(String args[]){
		Tribe tribe = new Tribe(CAPACITY);
		//precompute the number of times the cook will need to cook
		int cook_times= (NUM_CANNIBALS-CAPACITY)/CAPACITY;
		if((NUM_CANNIBALS-CAPACITY)%CAPACITY!=0) cook_times++;
		
		Cook cocinero = new Cook(tribe,cook_times);
		cocinero.start();
		Cannibal[] vcanibal=new Cannibal[NUM_CANNIBALS];
		for(int i=0;i<NUM_CANNIBALS;i++){
			vcanibal[i]=new Cannibal(tribe,i);
			vcanibal[i].start();
		}
		
				
	}
}
