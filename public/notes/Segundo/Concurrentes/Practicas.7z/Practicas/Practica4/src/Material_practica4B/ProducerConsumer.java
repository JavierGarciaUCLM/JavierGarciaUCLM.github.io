package Material_practica4B;

class Buffer {
    static final int SIZE = 8;
	int insertIndex, removeIndex, empty, items;
	int[] data;

	Buffer() {
	   data = new int[SIZE];
	   insertIndex = 0;
	   removeIndex = 0;
	   empty = SIZE;
	   items = 0;
	}

	 synchronized void insert(int item)	throws InterruptedException {
		 
	   while(empty==0) wait(); 
	   
	   data[insertIndex] = item;
	   System.out.println("[Producer] Insert " +item);
	   insertIndex = (1+insertIndex)%SIZE;
	   
	   empty--;
	   items++;
	   
	   notifyAll();
	  
	}
	
	 synchronized int remove() throws InterruptedException {
		 
	   while(items==0) wait();	 

		 
       int x = data[removeIndex];
       System.out.println("[Consumer] Remove " +x);
       
       removeIndex = (1+removeIndex)%SIZE;
       
       empty++;
       items--;

       notifyAll();

       return x;
   }
}


class Producer extends Thread {
	Buffer buffer;

	Producer(Buffer b) {
		buffer = b;
	}

	public void run() {
		java.util.Random r = new java.util.Random();
		while (true) {
		  try {
			 Thread.sleep(1000);
		     buffer.insert(r.nextInt(200));
		  } catch (InterruptedException e) {
		      e.printStackTrace(); } 
	   }
	} 
}

class Consumer extends Thread {
	Buffer buffer;
	Consumer(Buffer b) {
		buffer = b;
	}

	public void run() {
		while (true) {
		  try {
			  Thread.sleep(1000);
		      int x = buffer.remove();
		      System.out.println(x);
		  } catch (InterruptedException e) {
		      e.printStackTrace();} 
	    }	
	} 
 }

public class ProducerConsumer {

	public static void main(String args[]) {

	   Buffer buffer = new Buffer();
	   Producer[] vp = new Producer[4];
	   Consumer[] vc = new Consumer[3];
	   
	   for(int i=0;i<4;i++){
		   vp[i]=new Producer(buffer);
		   vp[i].start();
	   }
	   for(int i=0;i<3;i++){
		   vc[i]=new Consumer(buffer);
		   vc[i].start();
	   }
	}
}


