
package PaqConjunto;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

/**
 * Implementaci�n de conjuntos usando ArrayList de Java.
 * Para simplificar y evitar clones, los objetos son mutables (algunos m�todos
 * mofican el objeto, como uni�n, intersecci�n, resta, extrae, ...).
 *
 * @param <E>  Tipo de los elementos del conjunto.
 */

public class ConjuntoAL<E> implements Conjunto<E>, Cloneable {
    
    private ArrayList<E> elementos; // contiene los elementos del conjunto

    /** Constructores */

    /** Crea un conjunto vac�o
     * (equivale a la constructora Vacio de la especificaci�n del TAD)
     */
    public ConjuntoAL(){
        this.elementos = new ArrayList<E>();
    }

    /**
     * Crea un conjunto a partir de otro y un nuevo elemento.
     * (equivale a la constructora CNV de la especificaci�n del TAD)
     * Puede usarse el m�todo inserta() en su lugar.
     */
    public ConjuntoAL(E e, Conjunto<E> c)
    {
         c.inserta(e);  // modifica c!
         this.elementos = ((ConjuntoAL<E>)c).elementos;
         // casting: suponemos que c es de esta misma clase (*** CORREGIR ***)
    }

    /**
     * Crea un conjunto con los elementos de un vector (evitando repetidos)
    */
    public ConjuntoAL(E[] v) {
        this();
        int n = v.length;
        for (int i = 0; i < n; i++) {
            this.inserta(v[i]); // si ya est�, no se inserta
        }
    }

    public boolean vacio()
    {
       return this.elementos.isEmpty();
    }
    
    public void inserta(E e)
    {
       if (!this.elementos.contains(e)) this.elementos.add(e);
    }
	
    public boolean contiene(E e)
    {
      return this.elementos.contains(e);
    }
	
    public int cardinal()
    {
      return this.elementos.size();
    }

    public void union(Conjunto<E> c)
    {
      Iterator<E> it = ((ConjuntoAL<E>)c).elementos.iterator();
      // casting: suponemos c de la misma clase, pero podr�a ser de otra (*** CORREGIR ***)
      while (it.hasNext())
      {
        E e=it.next();
	    if (!this.elementos.contains(e))
        this.inserta(e);
      }
    }

    public void interseccion(Conjunto<E> c)
    {
     ConjuntoAL<E> d = (ConjuntoAL<E>)c;
     // casting: suponemos c de la misma clase, pero podr�a ser de otra (*** CORREGIR ***)
     int i=0;
     ArrayList<E> copia = (ArrayList<E>) this.elementos.clone();
     // copia para iterar (no deja borrar si se esta iterando)
     Iterator<E> it = copia.iterator();
     while (it.hasNext())
     {
	   E e=it.next();
	   if (!d.elementos.contains(e))
              this.elementos.remove(e);
     }
    }
   
    public void resta(Conjunto<E> c)
    {
      ConjuntoAL<E> d = (ConjuntoAL<E>)c;
     // casting: suponemos c de la misma clase, pero podr�a ser de otra (*** CORREGIR ***)
      Iterator<E> it = d.elementos.iterator();
      while (it.hasNext())
      {
       E e = it.next();
       if(this.elementos.contains(e))
       this.elementos.remove(e);
      }
    }
	
    public boolean extrae(E e)
    {
      if (this.elementos.contains(e)) {
          this.elementos.remove(e);
          return true;
      }
      return false;
    }
	
    public boolean incluido(Conjunto<E>  c)
    {
      ConjuntoAL<E> d = (ConjuntoAL<E>)c;
      // casting: suponemos c de la misma clase, pero podr�a ser de otra (*** CORREGIR ***)
      boolean incluido = true;
      int size = this.elementos.size();
      for (int i = 0; incluido && i < size; i++) {
          incluido = d.elementos.contains(this.elementos.get(i));
      }
      return incluido;
     }

    public E[] aVector(){
        return (E[]) this.elementos.toArray();
    }

    public boolean equals(Object x)
    {
     Conjunto<E> c = (Conjunto<E>)x;
     return (this.incluido(c) && c.incluido(this));
    }

    public Object clone()
    {
      ConjuntoAL<E> c=null;
      try
      {
        c=(ConjuntoAL<E>) super.clone();
        c.elementos = (ArrayList<E>) this.elementos.clone();
      }catch(CloneNotSupportedException e)
	    { System.out.println("No se pudo clonar"); }
      return c;
    }

    public String toString()
    {
        return Arrays.toString(this.aVector());
    }

}
