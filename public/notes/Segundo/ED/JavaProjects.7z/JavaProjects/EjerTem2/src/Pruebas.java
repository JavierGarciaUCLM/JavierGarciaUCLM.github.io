import PaqConjunto.*;

import java.util.Arrays;
import java.util.Iterator;

class Pruebas
{
   // Aqu�, otros m�todos (est�ticos) que no est�n las clases que implementan las interfaces

   public static void main(String args[])
   {
       // Pruebas de m�todos (externos o internos a las clases).
       // Por ejemplo, para conjuntos:
       
   	    Conjunto<Integer> c = new ConjuntoAL<Integer>();
        Conjunto<Character> d = new ConjuntoAL<Character>();
        ConjuntoAL<Integer> c2 = new ConjuntoAL<Integer>();
        ConjuntoAL<Character> d2 = new ConjuntoAL<Character>();

        for (int i=1;i<6;i++)
            c.inserta(i); // Forma breve de c.inserta(new Integer(i))
        
        for (char ca='a';ca<'h';ca++)
            d.inserta(ca); // Forma breve de c.inserta(new Character(ca))

        for (int i=1;i<8;i++)
            c2 = new ConjuntoAL<Integer>(i, c2);

        for (char ca='a';ca<'h';ca++)
            d2 = new ConjuntoAL(ca, d2);

        System.out.println(c);
        System.out.println(d);
        System.out.println(c2);
        System.out.println(d2);
   } // fin main
}