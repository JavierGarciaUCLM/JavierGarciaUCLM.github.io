
package PaqConjunto;

public interface Conjunto<E> {
   
    public boolean vacio() ;

    public int cardinal();

    /**
     * Inserta un nuevo elemento, en caso de que no est�.
     */
    public void inserta(E e);

    /**
     * Comprueba si un elemento pertenece al conjunto.
     */
    public boolean contiene(E e);

    /**
     * Uni�n de conjuntos: incluye en this los nuevos elementos de c.
     */
    public void union(Conjunto<E> c);

    /**
     * Intersecci�n de conjuntos: Elinina de this los elementos que no est�n en c.
     */
    public void interseccion(Conjunto<E> c);

    /**
     * Elimina de this los elementos que est�n en c.
    */
    public void resta(Conjunto<E> c);

    /**
     * Elimina de this el elemento e.
     * Devuelve cierto o falso seg�n est� el elemento en this o no.
     */
    public boolean extrae(E e);

    /**
     * Comprueba si c est� incluido en this.
    */
    public boolean incluido(Conjunto<E> e);

    /**
     * Devuelve un vector con todos los elementos de this.
     */
    public E[] aVector();

    /**
     * M�todos heredeados que deben reescibirse:
     */
//    public String toString();
//    public boolean equals(Object c);
    public Object clone();

}
