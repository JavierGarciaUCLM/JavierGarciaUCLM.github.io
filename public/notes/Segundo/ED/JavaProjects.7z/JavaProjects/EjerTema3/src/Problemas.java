
import PaqTADLineales.PaqLista.*;
import PaqTADLineales.PaqPila.*;
import PaqTADLineales.PaqCola.*;
import PaqTADVacioException.*;

import java.math.BigInteger;

import static PaqTADLineales.PaqPila.PD.op22;

class Ejercicios {
    // Aqu�, m�todos sobre lista, pilas y colas que deban implementarse
    // fuera de sus respectivas clases


    public static void main(String arg[]) {
    /*/ Prueba de m�todos de listas, pilas y colas. Por ejemplo:
      
    Lista<Integer>  l = new LD<Integer>();
    Pila<Character> p = new PD<Character>();
    Cola<Boolean>   c = new CD<Boolean>();
    
    for(int i=1; i<5; i++) 
        l.Añade(new Integer(i)); // o bien l.A�ade(i). Java transforma
                                 // int a Integer (y viceversa).
    for(char ca='a'; ca<'g'; ca++)
        p.APila(new Character(ca));   // o bien p.Apila(ca);
   
    boolean b = true;
    for( int j=1; j<4; j++)
    {
        c.EnCola(new Boolean(b)); // o bien, c.EnCola(b);
        b=!b;
    }

    System.out.println(l);
    System.out.println(p);
    System.out.println(c);
    */

        Cola<Integer> cola = new CD<Integer>();
        Pila<Integer> pila = new PD<Integer>();

        // Agregar elementos a la cola

        cola.EnCola(1);
        cola.EnCola(2);
        cola.EnCola(3);
        // Agregar elementos a la pila
        pila.APila(6);
        pila.APila(5);
        pila.APila(4);
        // Llamada a op22
        Pila<Integer> resultado = op22(cola, pila);

        // Imprimo
        while (!resultado.EsVacia()) {
                System.out.println(resultado.Tope());
                resultado = resultado.DesaPila();
        }
    }

}




