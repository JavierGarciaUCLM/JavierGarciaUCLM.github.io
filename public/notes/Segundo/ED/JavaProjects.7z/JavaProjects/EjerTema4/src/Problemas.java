import PaqTADArbol.*;
import PaqTADVacioException.*;
import PaqTADLineales.PaqLista.*;

class Ejercicios
{
  // M�todos sobre eedds 'fuera' de las clases 
  // que las implementan (o despu�s de main)
    
  public static void main(String arg[])
  {
    // Pruebas de m�todos sobre �rboles

     // creaci�n de �rboles con construdoras de la clase ABD:
    ArbolBinario<Integer>
            a = new ABD<Integer>(4),
            b = new ABD<Integer>(7),
            c = new ABD<Integer>(3,a,new ABD<Integer>()),
            d = new ABD<Integer>(1,b,c),
            abint = new ABD<Integer>(4,c,d);
    // creaci�n de �rboles con los m�todos axiliares:
    ArbolBinario<Character>
          abchar = toABchar("asdfasdfasdfasdrtt"),
          abcharord = toABchar("acfhjlmnxyz");

    System.out.println(abint);
    dibuja(abint);
    System.out.println(abchar);
    dibuja(abchar);
    System.out.println(abcharord);
    dibuja(abcharord);

  }


/* M�todos auxiliares para crear y visualizar �rboles: */

  // Arbol binario m�s equilibrado dado su inorden:
  public static ArbolBinario<Character> toABchar(String s) {
    int m = s.length() / 2;
    if (s.isEmpty()) {
      return new ABD<Character>();
    } else {
      return new ABD<Character>(s.charAt(m),
              toABchar(s.substring(0, m)),
              toABchar(s.substring(m + 1)));
    }
  }

  // Visualiza un �rbol binario:
  public static <E> void dibuja(ArbolBinario<E> a){
    System.out.println(toStr(a, " "));
  }

  public static <E> String toStr(ArbolBinario<E> a, String s)
  {
    try {
      return toStr(a.SubArbolDcho(), s+"     ")
              + "\n" + s + a.Raiz()
              + toStr(a.SubArbolIzqdo(), s+"     ");
    } catch (TADVacioException ex) {
       //    return "\n" + s + "|";   // muestra tambi�n vac�o
       return "";
    }
  }

// Crea un Arbol general de caracteres en forma de lista, sin
// elementos repetidos, a partir del preorden y el postorden
// Si no es posible, se lanza la exc. IllegalArgument
  public static Lista agc(String pre, String pos) throws IllegalArgumentException
  {
    Lista aginv = new LD(); // para guardar el resultado invertido
    String preh=new String(),
            posh=new String();
    int i=0,lenpre=pre.length(),
            lenpos=pos.length();
    char c;
    if (lenpre!=lenpos) throw new IllegalArgumentException();
    if (lenpre != 0)
    {
      aginv.A�ade(pre.charAt(0)); // raiz
      i=0; // posicion en posor
      while(i<lenpos-1){
        c=pre.charAt(i+1);
        preh="";
        posh="";
        do{
          if (i==lenpos) throw new IllegalArgumentException();
          preh+=pre.charAt(i+1);
          posh+=pos.charAt(i);
          i++;
        }while(pos.charAt(i-1)!=c);
        aginv.A�ade(agc(preh,posh)); // localizado un nuevo subarbol
      }
    }
    Lista ag = new LD();
    while(!aginv.EsVacia()){          // invertir la lista obtenida
      try {
        ag.A�ade(aginv.Cabeza());
        aginv = aginv.Cola();
      } catch (TADVacioException ex) {}
    }
    return ag;
  }

  // el anterior pero de la clase de �rboles generales
  public static ArbolG<Character> agc0(String pre, String pos) throws IllegalArgumentException {
    Lista<ArbolG<Character>> aginv = new LD<ArbolG<Character>>();
    //Lista aginv = new LD(); // para guardar el resultado invertido
    String preh = new String(),
            posh = new String();
    int i = 0, lenpre = pre.length(),
            lenpos = pos.length();
    char c, raiz = 0;
    if (lenpre != lenpos) throw new IllegalArgumentException();
    if (lenpre != 0) {
      raiz = pre.charAt(0);
      i = 0; // posicion en posor
      while (i < lenpos - 1) {
        c = pre.charAt(i + 1);
        preh = "";
        posh = "";
        do {
          if (i == lenpos) throw new IllegalArgumentException();
          preh += pre.charAt(i + 1);
          posh += pos.charAt(i);
          i++;
        } while (pos.charAt(i - 1) != c);
        aginv.A�ade(agc0(preh, posh));
      }
      Lista<ArbolG<Character>> ag = new LD<ArbolG<Character>>();
      while (!aginv.EsVacia()) {          // invertir la lista obtenida
        ag.A�ade(aginv.Cabeza());
        aginv = aginv.Cola();
      }
      return new ArbolG<Character>(raiz, ag);
    }
    return new ArbolG<Character>();
  }

}		
		
		
