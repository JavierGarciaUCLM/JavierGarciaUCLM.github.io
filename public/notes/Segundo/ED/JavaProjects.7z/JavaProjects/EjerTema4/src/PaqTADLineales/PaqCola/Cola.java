// Cola.java 

package PaqTADLineales.PaqCola;

import PaqTADVacioException.*;

/**  
 *   Interfaz general de Colas
 *   (el constructor  devuelve una Cola vac�a)
 */

public interface Cola<E>{
    
/**
*   Devuelve true si la cola es vac�a
*   @return	true si la cola es vac�a
*/
public boolean EsVacia();
    
	
/**
*   A�ade x a la cola por el final 
*   @param		x 	Elemento a encolar
*   @see		PaqElemento.Elemento  
*/
public void EnCola(E x);
   	 

/**
*   Devuelve el objeto en la cabeza de la cola
*   @return		el Elemento en la cabeza de la cola     
*   @exception		TADVacioException en caso de que 
*  			la cola no contenga elementos 
*   @see		PaqElemento.Elemento  
*/
public E Cabeza() throws TADVacioException;
	 
	 
/**
*   Devuelve la cola sin la cabeza
*   @exception	TADVacioException en caso de que
*  		la cola no contenga elementos
*/
public Cola<E> Resto() throws TADVacioException;

/**
*   Devuelve la longitud de la cola 
*   @return	longitud de la cola
*/	 
public int Longitud();

/**
*   Saca un duplicado de la cola 
*   Devuelve un objeto del tipo Cola 
*   concreto que se est� empleando.
*   Es necesario declararlo para hacerlo p�blico
*   @return	un clone de la cola 	   
*/
public Object clone();
 

/* Los siguientes m�todos no ser�a necesario declararlos
 * (se heredan de Object)
 * Se hace para recordar que deben reescribirse en las
 * implementaciones, pues el c�digo heredado no sirve
*/

/**
*   Pasa la cola a formato String
*   @return 	Devuelve un String mostrando los elementos 	   
*   @see 	String	   
*/
public String toString();
         
/**
*   Compara dos colas elemento a elemento
*   @return 	Devuelve cierto si ambas colas son iguales 	   
*   @see 	Object	   
*/
public boolean equals(Object c);

}


