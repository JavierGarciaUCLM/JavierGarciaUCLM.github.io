// ListaConArrays.java :  Versi�n de listas sobre arrays

package  PaqTADLineales.PaqLista;

import PaqTADVacioException.*;
import PaqTADNodo.*;
import java.util.Arrays;
import java.util.Comparator;

/**
 * Clase ListaConArrays para implementar la interface Lista<E> con arrays
 * 
 * @author Estructuras de Datos y de la Informaci�n 
 * @version Curso 2008-2009
*/

public class ListaConArrays<E> implements Lista<E>,Cloneable,Comparable<Lista<E>> {
	
   private final int tama�oInicial=4;//Cantidad reservada inicialmente
   private final int incremento=4; //Cantidad a incrementar si falta
   private int tama�o;    // Tama�o actual de la lista lista     
   private E elementos[]; // Array con los elementos de la lista
   private int libre;     // Primera posici�n libre
	 
   public ListaConArrays() 
     { 
         // Devuelve una lista vac�a de tama�o tama�oInicial
            tama�o=tama�oInicial;
            elementos =  (E[]) new Object[tama�o];
            libre=0;
     }
	 
   public boolean EsVacia()
	 {
	 	return libre==0;
	 }
	 	 
    private void Incrementa()
	 {
	 	tama�o+=incremento;
                elementos = Arrays.copyOf(elementos, tama�o);
                
//              o bien:
//		E copia[]=(E[]) new Object[tama�o];
//	 	System.arraycopy(elementos,0,copia,0,elementos.length);
//		elementos=copia;
	 }	

     public void A�ade(E e)
     {
	 if (libre==tama�o) Incrementa();
         elementos[libre] =e;
         libre++;
     }

     
	public E Cabeza()throws TADVacioException
	{
        if (libre==0) throw new TADVacioException();
        else return elementos[libre-1];
     }
	

      public Lista<E> Cola() throws TADVacioException
      {
         if (libre==0) throw new TADVacioException();
         else 
         {
           ListaConArrays<E> l = new ListaConArrays<E>();
           l.elementos = elementos;
           l.libre = libre-1; 
           return l;
         }
      }
	

     public boolean EstaContenido(E e)
     {
	 for (int i=0; i<libre; i++)
             if (e.equals(elementos[i])) return true;
         return false;
     }		


     public int Longitud()
     {   
         return libre;
     }


    public void Concatena(Lista<E> l)
    {  // suponemos l lista con arrays --supos demasiado fuerte-
         E[] copia;
         ListaConArrays<E> le=(ListaConArrays<E>) l.clone();
		
        //Nos aseguramos de que quepa la concatenacion con cierta holgura
        if ((le.libre)>(tama�o-libre))
           tama�o=le.libre+libre+incremento;    
        copia=(E[]) new Object[tama�o];
        System.arraycopy(le.elementos,0,copia,0,le.libre);
        System.arraycopy(elementos,0,copia,le.libre,libre);
        elementos=copia;
        libre +=le.libre;         
    } 
	 	 

     public Object clone() {
	  ListaConArrays<E> o=null;
	  try
	  {
	    o=(ListaConArrays<E>) super.clone();
            o.elementos=(E[])elementos.clone();

	  }catch(CloneNotSupportedException e)
	  {
	  	System.out.println("No se pudo clonar");
	  }
	  return  o;
     }

	
	public String toString()
{
        String s;
        int i;

        s=new String("(");
        for (i=libre-1; i>=0; i--) {
           s+=elementos[i];
           if (i>0) s+=", ";
        }
        s+=")";
        return s;
     }

   // M�TODOS AUN NO IMPLELENTADOS:
        
    public void A�ade(E e, int n) {
    }

    public boolean Elimina(E e) { return true;
    }

    public boolean EliminaAt(int n) { return true;
    }

    public E elemAt(int n) throws TADVacioException {return null;
    }

    public int Indice(E e) {return 0;
    }

    public Lista<E> Sublista(int i, int j) throws TADVacioException {return null;
    }

    
    public boolean equals(Lista<E> l) {return true;
    }

    public int compareTo(Lista<E> l) {return 0;
    }

    public void Ordenar(Comparator<E> c) {
    }

    public void Ordenar() throws IllegalArgumentException {
    }
}
