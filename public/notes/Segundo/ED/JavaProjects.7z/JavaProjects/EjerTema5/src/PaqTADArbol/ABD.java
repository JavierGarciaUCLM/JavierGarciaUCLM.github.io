package PaqTADArbol;

import PaqTADVacioException.*;
import PaqTADNodo.*;

/* IMPORTANTE. FALTA IMPLEMENTAR ALGUNOS M�TODOS. INCLUIR LOS QUE SE HICIERAN EN EL TEMA ANTERIOR  */

// clase ArbolBinarioDinamico, renombrado como ABD por comodidad

public class ABD<E> implements ArbolBinario<E>,Cloneable
{
   NodoArbol<E> raiz;     // Ra�z del �rbol binario

	/**
	 * Crea �rbol vac�o (constructora AV de la definici�n del TAD)
 	 */
   public ABD(){ // Crea un �rbol vac�o
		raiz=null;
   }

	/**
	 * Crea un �rbol binario a partir de un nuevo elemento y dos �rboles
	 * (constructora AB de la definici�n del TAD)
	 * @param x nuevo elemento
	 * @param i nuevo �rbol (din�mico) que queda como izquierdo
	 * @param d nuevo �rbol (din�mico) que queda como derecho
	 */
   public ABD(E x, ABD<E> i, ABD<E> d){
	 raiz=new NodoArbol<E>(x, i.raiz, d.raiz);
   }

	/**
	 * Generaliza el alterior para �rboles cualesquiera, no necesariamente din�micos (ABD)
	 * @param x nuevo elemento
	 * @param i nuevo �rbol que queda como izquierdo
	 * @param d nuevo �rbol que queda como derecho
	 */
	public ABD(E x, ArbolBinario<E> i, ArbolBinario<E> d){
		this.raiz = new ABD<E>(x, toABD(i), toABD(d)).raiz;
	}

	// crea un arbol binario din�mico a partir de otro binario cualquiera
	private ABD<E> toABD(ArbolBinario<E> a){
		try {
			return new ABD<E>(a.Raiz(), toABD(a.SubArbolIzqdo()), toABD(a.SubArbolDcho()));
		} catch (TADVacioException ex) {
			return new ABD<E>(); // si a es vac�o
		}
	}

	/**
	 * Crea un �rbol con un solo elemento
	 * @param e elemento
	 */
	public ABD(E e)
	{
		raiz=new NodoArbol<E>(e,null,null);
	}

	// para uso local
	ABD(NodoArbol<E> n)
	{
		this.raiz=n;
	}

	public boolean EsVacio()
   {
	return this.raiz==null;
   }

    public E Raiz() throws TADVacioException
    {
	if (this.raiz==null)
		throw new TADVacioException("�rbol vac�o");
	else
		return this.raiz.Info;
    }
	
    public ArbolBinario<E> SubArbolIzqdo() throws TADVacioException
    {
	if (raiz == null) throw new TADVacioException("�rbol vac�o");
	else return new ABD<E>(raiz.iz);
    }
	
    public ArbolBinario<E> SubArbolDcho() throws TADVacioException
    {
	if (raiz == null) throw new TADVacioException("�rbol vac�o");
	else return new ABD<E>(raiz.de);
    }
	
    @Override
    public Object clone()
    {
        ABD<E> a=null;
	try
	{
	   a=(ABD<E>)super.clone();
	}catch (CloneNotSupportedException e)
	{
	   System.out.println(e);
	}
	try
	{
	  if (!EsVacio())
	  {
		a.raiz=(NodoArbol<E>)raiz.clone();
		if (!SubArbolIzqdo().EsVacio())
			a.raiz.iz=((ABD<E>)SubArbolIzqdo().clone()).raiz;
		if (!SubArbolDcho().EsVacio())
				a.raiz.de=((ABD<E>)SubArbolDcho().clone()).raiz;
	}
	}catch(TADVacioException e)
	{	System.out.println(e);
	}	
	return a;
    }

    // mejorable; ver el m�todo que dibuja un �rbol
    public String toString()
    {
	String s;
	s=new String("( ");
	if (raiz != null)
	{
	  try
	  {
		s+=raiz.Info.toString() + " ";
		s+=SubArbolIzqdo().toString();
		s+=SubArbolDcho().toString();
	   }catch (TADVacioException e){ System.out.println(e);	}			
	}
	s+=" )";
	return s;
    }

    // toString, similar a dibuja:
	public String renombrar_como_toStrint()
	{
		return tstr("    ");
	}

	private String tstr(String s){
		try {
			return ((ABD<E>)this.SubArbolDcho()).tstr(s+"     ")
					+  "\n" + s + this.Raiz()
					+ ((ABD<E>)this.SubArbolIzqdo()).tstr(s+"     ");
		} catch (TADVacioException ex) {
//           return "\n" + s + "|";   // muestra tambi�n vac�o
			return "";
		}
	}

	@Override
   public boolean equals(Object o)
   {
       if(!(o instanceof ArbolBinario))
           throw new IllegalArgumentException();
       ArbolBinario<E> a = (ArbolBinario<E>)o;
       boolean iguales = raiz==null && a.EsVacio();
       
       if(raiz!=null && !a.EsVacio())
       {
           try {  
                iguales=this.Raiz().equals(a.Raiz())
                && this.SubArbolIzqdo().equals(a.SubArbolIzqdo())
                && this.SubArbolDcho().equals(a.SubArbolDcho());
            } catch (TADVacioException ex) {ex.printStackTrace(); }
       }
       
       return iguales;
   }
	
 // EJERCICIOS (m�todos para objetos de esta clase ABD)


} // fin de clase
