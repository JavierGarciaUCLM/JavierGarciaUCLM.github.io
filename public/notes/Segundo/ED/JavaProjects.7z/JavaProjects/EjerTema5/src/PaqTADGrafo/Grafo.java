package PaqTADGrafo;

import PaqTADLineales.PaqLista.Lista;

public interface Grafo<E>
{
	public boolean EsVacio ();

	/**
	 * @param e Nuevo nodo a incluir
	 * @throws IllegalArgumentException si el nodo ya existe
	 */
	public void InclNodo(E e) throws IllegalArgumentException;

	/**
	 * @param e1 extremo 1 (al ser no dirigido, el orden no importa)
	 * @param e2 extremo 2
	 * @throws IllegalArgumentException si alguno de los nodos no existe
	 */
	public void InclArco (E e1, E e2) throws IllegalArgumentException;
			
	public boolean EstaContenido (E e);

	/**
	 * @param e Nodo a borrar
	 * @throws IllegalArgumentException si el nodo no existe
	 */
	public void BorraNodo (E e) throws IllegalArgumentException;

	/**
	 * @param e1 extremo 1 (al ser no dirigido, el orden no importa)
	 * @param e2 extremo 2
	 * @throws IllegalArgumentException si alguno de los nodos no existe
	 */
	public void BorraArco(E e1, E e2) throws IllegalArgumentException;

	/**
	 * @param e1 extremo 1 (al ser no dirigido, el orden no importa)
	 * @param e2 extremo 2
	 * @return true si son adyacentes, false en caso contrario
	 * @throws IllegalArgumentException si alguno de los nodos no existe
	 */
	public boolean EsAdyacente(E e1, E e2) throws IllegalArgumentException;
        
    public Lista<E> Adyacentes(E x);
        
    public Lista<E> Nodos();
	
	public Object clone();
		 
	public String toString();
        
    public boolean equals(Object o);
	
}
