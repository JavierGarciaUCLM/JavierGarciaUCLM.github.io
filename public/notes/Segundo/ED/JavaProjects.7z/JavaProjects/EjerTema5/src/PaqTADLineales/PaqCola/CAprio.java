package PaqTADLineales.PaqCola;

import PaqTADVacioException.*;

import java.util.Arrays;
import java.util.Comparator;
import java.util.concurrent.Callable;

/**
 * Clase que implenta la interface Cola<E> con arrays y prioridades, para elementos comparables
 * (ser�a mejor usar un comparador, o dar las dos posibilidades)
 * Como Lista con arrays. Se desprecia la posici�n 0 del vector de elementos
 * (para facilitar c�lculos de �ndices)
 * @author Estructura de Datos
 * @version Curso 2023-2024
 */

public class CAprio<E> implements Cola<E>,Cloneable {

    private final int tamanoInicial = 4;//Cantidad reservada inicialmente
    private final int incremento = 4; //Cantidad a incrementar si falta
    private int tamano;    // Tama�o actual de la cola
    private E[] elementos; // Array con los elementos de la cola
    private int libre;     // Primera posici�n libre (donde se encola en siguiente)

    private int sentido = 0; // -1 de prioridades ascendentes o "de m�nimos", 1 prioridades descendentes o "de m�ximos"

    public CAprio(int sentido) {
        this.sentido = sentido;
        tamano = tamanoInicial;
        elementos = (E[]) new Object[tamano];
        libre = 1;
    }

    /**
     * Contruye una cola con prioridades a partir de otra con prioridades y un nuevo elemento
     * @param e nuevo elemento
     * @param c cola con prioridades
     */
    public CAprio(CAprio<E> c, E e) {
        if (e != null && e instanceof Comparable) {
            this.elementos = c.elementos.clone();
            this.sentido = c.sentido;
            this.tamano = c.tamano;
            this.libre = c.libre;
            this.EnCola(e);
        } else {
            throw new NullPointerException(e.getClass() + " no es comparable o nuevo elemento " + e + " no valido");
        }
    }

    /**
     * Crea una cola con prioridades a partir de otra cualquiera
     * @param c cola cualquiera de elementos comparables (se pierde el sentido de la cola)
     * @param sentido -1 de m�nimos (prioridades ascendentes), 1 de m�ximos (prioridades descendentes)
     */
     public CAprio(int sentido, Cola<E> c) {
         this(sentido);
         if (c == null || !(sentido == 1 || sentido == -1))
             throw new IllegalArgumentException("cola o sentido no v�lidos");
         while (!c.EsVacia()) {
             this.EnCola(c.Cabeza());
             c = c.Resto();
         }
     }

    /**
     * Crea una cola con prioridades con los elementos de un vector
     * @param v vector de elementos
     * @param sentido -1 de m�nimos (prioridades ascendentes), 1 de m�ximos (prioridades descendentes)
     */
    public CAprio(E[] v, int sentido) {
        this(sentido);
        if (v==null || !(sentido == 1 || sentido == -1))
            throw new IllegalArgumentException("vector o sentido no v�lidos");
        int n = v.length;
        for (int i = 0; i < n; i++) {
            this.EnCola(v[i]);
        }
    }

    @Override
    public boolean EsVacia() {
        return libre == 1;
    }

    @Override
    public void EnCola(E x) {
        if(x==null || !(x instanceof Comparable)) throw new IllegalArgumentException("elemento no valido (null o no comparable)");
        if(libre==tamano)
            this.elementos = Arrays.copyOf(elementos, tamano+=incremento);
        inserta(elementos, x, libre);
        libre++;
    }

    @Override
    public E Cabeza() throws TADVacioException {
        if (libre==1) throw new TADVacioException();
        else return elementos[1];
    }

    @Override
    public CAprio<E> Resto() throws TADVacioException {
        if (libre==1) throw new TADVacioException("cola vac�a");
        else{
            CAprio<E> c = (CAprio<E>) this.clone();
            reconstruye(c.elementos, c.libre);
            c.libre--;
            // c.Reconstruye();
            return c;
        }
    }

    @Override
    public int Longitud() {
        return libre-1;
    }

    public int Sentido() {
        return sentido;
    }

    @Override
    public Object clone() {
        CAprio<E> o=null;
        try
        {
            o=(CAprio<E>) super.clone();
            o.elementos=(E[])elementos.clone();
        }catch(CloneNotSupportedException e)
        {
            System.out.println("No se pudo clonar");
        }
        return  o;
    }

    @Override
    public boolean equals(Object o){
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String toString()
    {
        E[] v = (E[]) new Object[libre-1];
        System.arraycopy(this.elementos, 1, v, 0, libre-1);
        Comparator<E> comp = (o1, o2) -> ((Comparable)o1).compareTo(o2)*(-sentido);
//        Comparator<E> comp = new Comparator<E>() {
//            @Override
//            public int compare(E o1, E o2) {
//                return ((Comparable)o1).compareTo(o2)*(-sentido);
//            }
//        };
        Arrays.sort(v, comp);
        return Arrays.toString(v);
    }

    // M�TODOS PRIVADOS AUXILIARES

    // compara dos elementos comparables seg�n el sentido de la cola
    private boolean mejor(E x, E y){
        if(x==null || y==null || !(x instanceof Comparable))
                throw new IllegalArgumentException(x.getClass() + " no comparable o elementos no comparables");
        return ((Comparable)x).compareTo(y)*(-sentido)<0;
    }

    // inserta un elemento en un vector de prioridades en la posici�n libre, y lo recoloca
    private void inserta(E[] v, E x, int libre){
        v[libre] = x;
        int i = libre;
        E y;
        while(i>1 && mejor(v[i],v[i/2])){
            y = v[i/2];
            v[i/2] = v[i];
            v[i] = y;
            i = i/2;
        }
    }

    // elimina la primera posici�n del vector de prioridades y lo reconstruye hasta la posicion libre
    private void reconstruye(E[] v, int libre){
        v[1] = v[libre-1]; v[libre-1] = null;
        int i = 1;
        E y;
        while(2*i<libre-1 && mejor(v[2*i],v[i]) || 2*i+1<libre-1 && mejor(v[2*i+1],v[i])){
            if(2*i+1<libre-1 && mejor(v[2*i+1],v[2*i])){
                y = v[2*i+1];
                v[2*i+1] = v[i];
                v[i] = y;
                i = 2*i+1;
            }
            else{
                y = v[2*i];
                v[2*i] = v[i];
                v[i] = y;
                i = 2*i;
            }
        }
    }

} // Fin de la clase CAprio
