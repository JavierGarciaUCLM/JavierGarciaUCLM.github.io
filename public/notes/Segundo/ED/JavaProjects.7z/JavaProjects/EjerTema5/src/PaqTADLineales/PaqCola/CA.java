package  PaqTADLineales.PaqCola;

import PaqTADVacioException.*;

import java.util.Arrays;
import java.util.Comparator;

/**
 * Clase CA que implementa la interface Cola<E> con arrays
 * Similar a la implementaci�n de Lista con arrays.
 * @author Estructura de Datos y de la Informaci�n
 * @version Curso 2023-2024
 */

public class CA<E> implements Cola<E>,Cloneable {

    private final int tamanoInicial = 4;//Cantidad reservada inicialmente
    private final int incremento = 4; //Cantidad a incrementar si falta
    private int tamano;    // Tama�o actual de la cola
    private E elementos[]; // Array con los elementos de la cola
    private int libre;     // Primera posici�n libre (donde se encola en siguiente)

    public CA() {
        tamano = tamanoInicial;
        elementos = (E[]) new Object[tamano];
        libre = 0;
    }

    /**
     * Contruye una cola a partir de otra y un nuevo elemento
     *
     * @param e nuevo elemento
     * @param c lista cualquiera
     */
    public CA(Cola<E> c, E e) {
        this();
        if (e != null) {
                while (!c.EsVacia()) {
                  this.EnCola(c.Cabeza());
                  c = c.Resto();
            }
            this.EnCola(e);
        } else {
            throw new NullPointerException();
        }
    }

    /**
     * Crea una cola con los elementos de un vector (con cabeza v[0])
     * @param v vector de elementos
     */
    public CA(E[] v) {
        this();
        int n = v.length;
        for (int i = 0; i < n; i++) {
            this.EnCola(v[i]);
        }
    }

    @Override
    public boolean EsVacia() {
        return libre == 0;
    }

    @Override
    public void EnCola(E x) {
        if (libre==tamano)
            elementos = Arrays.copyOf(elementos, tamano+=incremento);
            //Incrementa();
        elementos[libre] =x;
        libre++;
    }

    private void Incrementa()
    {
        tamano+=incremento;
        elementos = Arrays.copyOf(elementos, tamano);
//      o bien:
//		E copia[]=(E[]) new Object[tama�o];
//	 	System.arraycopy(elementos,0,copia,0,elementos.length);
//		elementos=copia;
    }

    @Override
    public E Cabeza() throws TADVacioException {
        if (libre==1) throw new TADVacioException();
        else return elementos[0];
    }

    @Override
    public Cola<E> Resto() throws TADVacioException {
        if (libre==0) throw new TADVacioException("Cola vac�a al obtener su resto");
        else
        {
            CA<E> l = new CA<E>();
            E[] copia = (E[]) new Object[tamano];
            System.arraycopy(elementos,1,copia,0,libre-1);
            l.elementos = copia;
            l.libre = libre-1;
            l.tamano = tamano;
            return l;
        }
    }

    @Override
    public int Longitud() {
        return libre;
    }

    @Override
    public Object clone() {
        CA<E> o=null;
        try
        {
            o=(CA<E>) super.clone();
            o.elementos=(E[])elementos.clone();

        }catch(CloneNotSupportedException e)
        {
            System.out.println("No se pudo clonar");
        }
        return  o;
    }

    @Override
    public boolean equals(Object o){
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String toString()
    {
        String s;
        int i;
        s=new String("(");
        for (i=0; i<libre; i++) {
            s+=elementos[i];
            if (i<libre-1) s+=", ";
        }
        s+=")";
        return s;
    }

} // Fin de la clase CA

