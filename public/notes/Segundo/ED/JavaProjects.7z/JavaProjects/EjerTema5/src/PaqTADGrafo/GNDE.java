package PaqTADGrafo;

import java.util.*;

import PaqTADLineales.PaqLista.LD;
import PaqTADLineales.PaqLista.Lista;
import PaqTADNodo.NodoGrafo;

public class GNDE<E> implements Grafo<E>, Cloneable {
   private int MAX_NODOS = 10;      // N�mero m�ximo inicial de nodos
   private int incremento = 5;     // Cantidad a incrementar vector y matriz si falta
   private int numnodos;            // N�mero actual de nodos
   private boolean Adyacencias[][]; // Matriz de adyacencia (sim�trica)
   private NodoGrafo<E> Nodos[];    // Nodos presentes
   
   /** Crea un grafo vac�o.*/
   public GNDE(){
     Adyacencias = new boolean[MAX_NODOS][MAX_NODOS];
     Nodos = new NodoGrafo[MAX_NODOS];
   }
   
   private int BuscaElemento(E e)
   {
      if (e==null) return -1;
      for (int i=0; i<MAX_NODOS; i++)
	      if(Nodos[i]!=null && e.equals(Nodos[i].Info)) return i;
      return -1;
   }
    
   private int BuscaPosicion()
   {
     for(int i=0;i<MAX_NODOS;i++)
	 	if (Nodos[i]==null) return i;
     return -1;
   }
   
   public boolean EstaContenido(E e){ 
     return (BuscaElemento(e)!=-1);
   }
   	
   public boolean EsVacio(){ 
	 return (numnodos == 0); 
   }			  
   
   public void InclNodo(E e) throws IllegalArgumentException
   {  
        if (e==null) throw new IllegalArgumentException("No se admiten nodos null");
        if (numnodos == MAX_NODOS) Incrementa();
        if (BuscaElemento(e)==-1)  {
          Nodos[BuscaPosicion()]=new NodoGrafo<E>(e,false);
	      numnodos++;
         }
        else throw new IllegalArgumentException("El nodo ya existe");
   }

  // Incrementa matriz de adyacencias y vector de nodos
    private void Incrementa()     {
        int i,j;
        boolean[][] ady = new boolean[MAX_NODOS+incremento][MAX_NODOS+incremento];
        NodoGrafo<E>[] nod = new NodoGrafo[MAX_NODOS+incremento];
        for(i=0;i<MAX_NODOS;i++)
            for(j=i;j<MAX_NODOS;j++)
                ady[i][j] = ady[j][i] = Adyacencias[i][j];
        for(i=0;i<MAX_NODOS;i++)
            nod[i] = Nodos[i];
        MAX_NODOS += incremento;
        Adyacencias = ady;
        Nodos = nod;

        /* otra forma, con Arrays.copyOf (un poco m�s eficiente):
        Nodos = Arrays.copyOf(Nodos, MAX_NODOS+incremento)
        for (int i = 0; i < MAX_NODOS; i++)
            Adyacencias[i] = Arrays.copyOf(Adyacencias[i], MAX_NODOS+incremento);
        Adyacencias = Arrays.copyOf(Adyacencias, MAX_NODOS+incremento);
        for (int i = MAX_NODOS; i <MAX_NODOS+incremento ; i++)
            Adyacencias[i] = new boolean[MAX_NODOS+incremento];
        MAX_NODOS += incremento;
        */
    }

    public void InclArco(E e1, E e2) throws IllegalArgumentException
   {
   	int pos1=BuscaElemento(e1),
	    pos2=BuscaElemento(e2);
        if (pos1==-1 || pos2==-1 ) throw new IllegalArgumentException("Alguno de los nodos no existe");
        else 
        { 
	       Adyacencias[pos1][pos2] = true;
	       Adyacencias[pos2][pos1] = true; // Es no dirigido.
        }
   }	 
   
   public boolean EsAdyacente(E e1, E e2) throws IllegalArgumentException{
     int pos1=BuscaElemento(e1),
	 pos2=BuscaElemento(e2);
     if (pos1==-1 || pos2==-1 ) 
         throw new IllegalArgumentException("Alguno de los nodos no existe");
     else 
         return Adyacencias[pos1][pos2];
   }
   
   public void BorraNodo(E e) throws IllegalArgumentException{
     int pos=BuscaElemento(e);
     if (pos==-1) throw new IllegalArgumentException("El nodo no existe");
     else
     { 
        Nodos[pos]=null;  //para que lo borre el recolector de basura.
        numnodos--;
        for (int j=0; j<MAX_NODOS; j++) 
           Adyacencias[pos][j] = Adyacencias[j][pos] = false;  
     }
   }
   
   public void BorraArco(E e1, E e2) throws IllegalArgumentException{
     int  pos1=BuscaElemento(e1),
          pos2=BuscaElemento(e2);
     if (pos1==-1 || pos2==-1 ) 
         throw new IllegalArgumentException("Alguno de los nodos no existe");
     else 
	   Adyacencias[pos1][pos2] = Adyacencias[pos2][pos1] = false; 
   }
   
   public Object clone() 
   {
     GNDE<E> gr=null;
     try
     {
	    gr=(GNDE<E>) super.clone();
     }catch (CloneNotSupportedException e)
	 {System.out.println(e);}
	 
     gr.Adyacencias=(boolean[][])Adyacencias.clone();
     for (int i=0;i<MAX_NODOS;i++)
         gr.Adyacencias[i]=(boolean[])Adyacencias[i].clone();
     gr.Nodos=(NodoGrafo<E>[]) Nodos.clone();
     for (int i=0;i<MAX_NODOS;i++)
	       if(Nodos[i]!=null)
	            gr.Nodos[i]=(NodoGrafo<E>) Nodos[i].clone();
     return gr;
   }
   
   public String toString()
   {
	 String resultado=new String();
	 for(int i=0; i<MAX_NODOS;i++) {
        if (Nodos[i]!=null)  {
	   	    for(int j=i;j<MAX_NODOS;j++)
		        if (Nodos[j]!=null)
		             if (EsAdyacente(Nodos[i].Info,Nodos[j].Info))
                     {
                        Nodos[i].Visitado=true;
                        Nodos[j].Visitado=true;
			            resultado+=Nodos[i].Info + " --- " + Nodos[j].Info+"\n";
                     }
                if (!Nodos[i].Visitado) resultado+=Nodos[i].Info+"\n";
        }
	 } 
     for(int i=0;i<MAX_NODOS;i++)
		   if (Nodos[i]!=null) Nodos[i].Visitado=false;
     return resultado;
    }
   
   public boolean equals(Object o)
   {
       if (!(o instanceof GNDE)) return false;
       GNDE<E> g = (GNDE<E>) o;
       boolean iguales = numnodos == g.numnodos;
       for (int i=0; i<MAX_NODOS && iguales; i++)
       {
           iguales = Nodos[i] != null && g.Nodos[i] != null
                  || Nodos[i] == null && g.Nodos[i] == null;
           if (Nodos[i] != null && g.Nodos[i] != null) 
               iguales = Nodos[i].Info.equals(g.Nodos[i].Info);
           for (int j=i; j<MAX_NODOS && iguales; j++)
               iguales = Adyacencias[i][j] == g.Adyacencias[i][j];
       }
       return iguales;
   }

    public Lista<E> Adyacentes(E x) {
       Lista<E> la = new LD<E>();
       int pos = this.BuscaElemento(x);
       if(pos != -1)
        for(int j=0;j<MAX_NODOS;j++){
            if(this.Adyacencias[pos][j]) la.Add(this.Nodos[j].Info);
        }
       return la;
    }

    public Lista<E> Nodos() {
        Lista<E> ln = new LD<E>();
        for(int i=0;i<MAX_NODOS;i++){
            if(this.Nodos[i]!=null) ln.Add(this.Nodos[i].Info);
        }
       return ln;
    }
   
}
 
