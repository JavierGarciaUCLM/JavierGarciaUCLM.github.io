package  PaqTADLineales.PaqLista;

import PaqTADVacioException.*;
import PaqTADNodo.*;
import java.util.Comparator;

// clase Lista_Dinamica<E>, por comodidad renombrada como LD<E>

public class LD<E> implements Lista<E>, Cloneable, Comparable<Lista<E>>{

   private int longitud; // Para almacenar en cada momento la longitud

   private Nodo<E> NodoCabeza; // Nodo en cabeza

    /**
     * Construye lista vac�a (contructora [] de la definici�n del TAD)
     *
     * */
   public LD() {
      longitud=0;
      NodoCabeza=null;
   }

    /**
     * Contruye una lista a partir de otra y un nuevo elemento
     * (constructora : en la definici�n del TAD)
     *
     * @param e nuevo elemento
     * @param c lista din�mica
     */
   public LD(E e, LD<E> c)
   {
       if (e!= null)
       {
         longitud = 1 + c.longitud;
         NodoCabeza=new Nodo<E>(e, c.NodoCabeza);       
       }
       else 
       {
         throw new NullPointerException();
       }
   }

    /**
     * constructor que generaliza el anterior, para una lista cualquiera
     * (podr�a prescindirse del anterior)
     * @param e nuevo elemento
     * @param c lista cualquiera
     */
    public LD(E e, Lista<E> c)
    {
        if (e!= null)
        {
            this.longitud = 1 + c.Longitud();
            LD<E> ld = new LD<E>();
            try {
                ld = new LD<E>(c.Cabeza(),c.Cola());
            } catch (TADVacioException ex) {}
            this.NodoCabeza= new Nodo(e,ld.NodoCabeza);
        }
        else
        {
            throw new NullPointerException();
        }
    }

    /**
     * Constructor que crea una lista con los elementos de un vector
     * (con cabeza v[0])
     * @param v vector de elementos
     */
    public LD(E[] v){
        int n = v.length;
        for (int i = n-1; i >= 0; i--) {
            this.Add(v[i]);
        }
    }

    public boolean EsVacia() {
      return (longitud == 0);
   }

   // mejorable (no void, ...), pero similar a add de List
   // en su lugar, puede usarse el contructor
   public void Add(E e) {
     Nodo<E> NuevaCabeza;
     if (e!= null){
       longitud++;
       NuevaCabeza=new Nodo<E>(e, NodoCabeza);
       NodoCabeza=NuevaCabeza;
     }
   }

  public E Cabeza() throws TADVacioException
   {
     if (longitud == 0) throw new TADVacioException();
     else return NodoCabeza.Info;
   }
   
 public Lista<E> Cola() throws TADVacioException {
    
     if (longitud == 0) throw new TADVacioException();
     else 
     {
        LD<E> l = new LD<E>();
        l.NodoCabeza=NodoCabeza.Siguiente;
        l.longitud=longitud-1;
        return l;
      }
   }

  public boolean EstaContenido(E e) {
    Nodo<E> actual;
    actual=NodoCabeza;
    while (actual != null) 
    {
      if (e.equals(actual.Info)) return true;
      else actual=actual.Siguiente;
     }
    return false;
  }

  public int Longitud() {
     return longitud;
  }

  // mejorable...(no void, lista cualquiera, ...)
  public void Concatena(Lista<E> l) {
    Nodo<E> actual;
    LD<E> l1;
    if (l==null || !(l instanceof LD)) throw new IllegalArgumentException("Requiere Lista Din�mica");
    l1=(LD<E>)l.clone(); //Para evitar problemas cuando se concatena con ella misma
    if (longitud==0) {
      NodoCabeza=l1.NodoCabeza;
      longitud=l1.longitud;
    }
    else {
      actual=NodoCabeza; // Se posiciona sobre el final de la actual
      while (actual.Siguiente != null)    
        actual=actual.Siguiente;
       // Enlaza la otra
      longitud += l1.longitud;
      actual.Siguiente=l1.NodoCabeza;
   }
  }
 
  public Object clone() {
    LD<E> l1=null;
    Nodo<E> aux1,aux2;
    try{
    l1=(LD<E>)super.clone();
    }catch(CloneNotSupportedException e){
      System.out.println(e);
    }
    if (longitud != 0) {
      l1.NodoCabeza=(Nodo<E>)NodoCabeza.clone();
      aux1=l1.NodoCabeza;
      aux2=NodoCabeza.Siguiente;
      while (aux2 != null) {
         aux1.Siguiente=(Nodo<E>) aux2.clone();
         aux2=aux2.Siguiente;
         aux1=aux1.Siguiente;
      }
     }
  return l1;
}

  public String toString() {
    String s;
    Nodo<E> actual;
    s=new String("(");
    actual=NodoCabeza;
    while (actual != null) {
      s=s.concat(actual.Info.toString());
      actual=actual.Siguiente;
      if (actual != null) s=s.concat(", ");
    }
    s=s.concat(")");
    return s;
  }

  public boolean equals(Object l) 
  {
        if (!(l instanceof Lista)) return false;
        Lista<E> cl = (Lista<E>) ((Lista<E>)l).clone();
        Nodo<E> aux = NodoCabeza;
        boolean iguales = true;
        while(aux!=null && !cl.EsVacia() && iguales)
        {
            try {
                iguales = aux.Info.equals(cl.Cabeza());
                cl=cl.Cola();
                aux = aux.Siguiente;
            } catch (TADVacioException ex) { ex.printStackTrace(); }
        }
        return (iguales && aux==null && cl.EsVacia());
  }

  // mejorable; mejor orden lexicogr�fico
  public int compareTo(Lista<E> l) {
        int l1 = this.Longitud(),
            l2 = l.Longitud();
        if (l1==l2) return 0;
        if (l1>l2) return 1;
        return -1;
        // tambi�n puede ser return l1-l2
  }

  // M�TODOS DE LA INTERFAZ A�N NO IMPLELEMTADOS:
  
  public void Add(E e, int n) {
       throw new UnsupportedOperationException("Not supported yet.");
  }

  public boolean Elimina(E e) {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public boolean EliminaAt(int n) {
        throw new UnsupportedOperationException("Not supported yet.");
  }

  public E elemAt(int n) throws TADVacioException {
       throw new UnsupportedOperationException("Not supported yet.");
  }

  public int Indice(E e) {
        throw new UnsupportedOperationException("Not supported yet.");
  }

  public Lista<E> Sublista(int i, int j) throws TADVacioException {
        throw new UnsupportedOperationException("Not supported yet.");
  }

  public void Ordenar(Comparator<E> c) {
        throw new UnsupportedOperationException("Not supported yet.");
  }

  public void Ordenar() throws IllegalArgumentException {
        throw new UnsupportedOperationException("Not supported yet.");
  }
     
    
// OTROS METODOS P�BLICOS (PROBLEMAS):

public int veces(E x){
     throw new UnsupportedOperationException("Not supported yet.");
}

// etc...
    
}    // Fin de la clase  LD<E>

