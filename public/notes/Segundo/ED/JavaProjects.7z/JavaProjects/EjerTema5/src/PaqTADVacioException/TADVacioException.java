package PaqTADVacioException;

/**  
*  La excepci�n TADVacioException se utiliza para manejar 
*  aquellas situaciones an�malas que se producen al intentar 
*  acceder (por consulta, borrado, etc..) a elementos b�sicos 
*  de una estructura de datos que est� vac�a. 
*/

public class TADVacioException extends RuntimeException
{
	public TADVacioException(){}

	public TADVacioException(String msg){
		super(msg); // guarda msg y lo muestra toString
	}

}