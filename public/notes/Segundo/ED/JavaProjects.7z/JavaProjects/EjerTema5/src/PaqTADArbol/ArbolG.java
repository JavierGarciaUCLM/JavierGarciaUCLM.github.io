package PaqTADArbol;

import PaqTADLineales.PaqLista.*;
import PaqTADVacioException.TADVacioException;

// Ejercicio:
// clase para implementar los �rboles generales, seg�n las definici�n del TAD.

public class ArbolG<E> implements Arbol<E>{

    private E raiz;
    private Lista<ArbolG<E>> subarboles;

    public ArbolG(){};

    public ArbolG(E raiz, Lista<ArbolG<E>> subarboles){
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean EsVacio() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public E Raiz() throws TADVacioException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Lista<ArbolG<E>> subarboles(){
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String toString(){
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Object clone() {
        return null; // provisional
    }
}
