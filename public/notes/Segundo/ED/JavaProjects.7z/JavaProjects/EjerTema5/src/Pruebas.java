import java.io.*;

import PaqTADGrafo.LibGrafos;
import PaqTADGrafo.GNDE;
import PaqTADGrafo.Grafo;
import PaqTADArbol.*;
import PaqTADLineales.*;
import PaqTADNodo.*;
import PaqTADVacioException.*;




class Pruebas
{

  public static int I = Integer.MAX_VALUE;

  public static void main(String arv[])throws IOException{
      
  /************* EJEMPLOS DE GRAFOS: ***********/

  /* FORMA 1: Con matriz de adyacencias:       */
  /*********************************************/
  /*
                       7    8        7    8
       0----1----2  0----1----2   0--->1--->2
       |\   |       |\   |        |\   ^ 
       | \  |      5| \9 |2      5| \9 |2  
       |  \ |       |  \ |        v  \ |
       3----4       3----4        3--->4  (0--4 = 0<-->4)
                      6             6
       ad1 y ad2         ad3           ad4
  */
  int ad1[][] = {
      {0, 1, 0, 1, 1},
      {1, 0, 1, 0, 1},
      {0, 1, 0, 0, 0},
      {1, 0, 0, 0, 1},
      {1, 1, 0, 1, 0}
    };
//  tambi�n se puede crear como:
//  int ad1[][] = creaAdy0("010304121434",5);

int ad2[][] = {
      {I, 1, I, 1, 1},
      {1, I, 1, I, 1},
      {I, 1, I, I, I},
      {1, I, I, I, 1},
      {1, 1, I, 1, I}
    };
//  tambi�n se puede crear como:
//  int ad1[][] = creaAdyI("010304121434",5);

int ad3[][] = {
      {I, 7, I, 5, 9},
      {7, I, 8, I, 2},
      {I, 8, I, I, I},
      {5, I, I, I, 6},
      {9, 2, I, 6, I}                        
    };
//  tambi�n se puede crear como:
//  int ad3[][] = creaAdyVND("017128035049142346",5);

int ad4[][] = {
      {I, 7, I, 5, 9},
      {I, I, 8, I, I},
      {I, I, I, I, I},
      {I, I, I, I, 6},
      {9, 2, I, I, I}                          
    };
//  tambi�n se puede crear como:
//  int ad4[][] = creaAdyVD( "017128035049409412346",5);

/*  otro ejemplo �til para hacer pruebas sobre caminos:

    gint:   0
           / \
          /   \
         1 --- 2     6 --- 7
         | \  /|      \   /
         |  \/ |       \ /
         |  /\ |        8
         | /  \|
         3 --- 4
          \   /
           \ /
            5

     gint1: primera componente conexa de gint

    */

      System.out.println();
      System.out.println("============ Ejemplos de grafos =================");
    
      int[][] gint = creaAdyI("01021213142324343545677886", 9);
      int[][] gint1 = creaAdyI("01021213142324343545", 6);

      System.out.println("\nMatriz de adyacencias ad1"); muestra(ad1);
      System.out.println("\nMatriz de adyacencias ad2"); muestra(ad2);
      System.out.println("\nMatriz de adyacencias ad3"); muestra(ad3);
      System.out.println("\nMatriz de adyacencias ad4"); muestra(ad4);
      System.out.println("\nMatriz de adyacencias gint"); muestra(gint);


  /* FORMA 2: Como objetos de la clase GE (no dirigidos y no valorados):
  /********************************************************************/
  /*
    gent: el mismo ad1 de arriba
  
    gcar:   a
           / \
          /   \
         b --- c     g --- h
         | \  /|      \   /
         |  \/ |       \ /
         |  /\ |        i
         | /  \|
         d --- e
          \   /
           \ /
            f
  */

  Grafo<Integer> gent = creaGEent("011203041434");
  System.out.println("\nGrafo GE<Integer> gent:\n" + gent);

  Grafo<Character> gcar = creaGEcar("abacbdcededcbefebcdfghhiig");
  System.out.println("\nGrafo GE<Character> gcar:\n" + gcar);

  /* PRUEBA DE EJERCICIOS */
  System.out.println();
  System.out.println("========= Prueba de ejercicios ================");
  System.out.println();

  }

}

		