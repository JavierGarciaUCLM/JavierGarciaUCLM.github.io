package PaqTADGrafo;

import PaqTADLineales.PaqLista.LD;
import PaqTADLineales.PaqLista.Lista;
import PaqTADVacioException.TADVacioException;

import java.util.List;

public class LibGrafos {

    /***************************************************/
    /* EJERCICIOS  */
    /***************************************************/


    /***************************************************/
    /* METODOS AUXILIARES PARA CREAR Y MOSTRAR GRAFOS  */
    /***************************************************/

    // infinito:
    public static int I = Integer.MAX_VALUE;

    // FORMA 1 (matriz de adyacencias)

    // Matriz de adyacencias de 0's y 1's a partir de string de arcos
    // (m�ximo 10 nodos, desde 0 hasta 9)
    public static int[][] creaAdy0(String s, int dimension) {
        int[][] m = new int[dimension][dimension];
        int longitud = s.length(), i, j;
        for (int k = 0; k < longitud; k += 2) {
            i = s.charAt(k) - '0';
            j = s.charAt(k + 1) - '0';
            m[i][j] = m[j][i] = 1;
        }
        return m;
    }

    // Idem de I's y 1's
    public static int[][] creaAdyI(String s, int dimension) {
        int[][] m = new int[dimension][dimension];
        int longitud = s.length(), i, j;
        for (int k = 0; k < longitud; k += 2) {
            i = s.charAt(k) - '0';
            j = s.charAt(k + 1) - '0';
            m[i][j] = m[j][i] = 1;
        }
        for (int ii = 0; ii < dimension; ii++)
            for (int jj = ii; jj < dimension; jj++)
                if (m[ii][jj] == 0) m[ii][jj] = m[jj][ii] = I;
        return m;
    }

    // Matriz de adyacencias para grafos valorados no dirigidos (VND)
    // a partir de un string de arcos y valores
    // (m�ximo 10 nodos y valores desde 0 hasta 9)
    public static int[][] creaAdyVND(String s, int dimension) {
        int[][] m = new int[dimension][dimension];
        int longitud = s.length(), i, j;
        for (int k = 0; k < longitud; k += 3) {
            i = s.charAt(k) - '0';
            j = s.charAt(k + 1) - '0';
            m[i][j] = m[j][i] = s.charAt(k + 2) - '0';
        }
        for (int ii = 0; ii < dimension; ii++)
            for (int jj = 0; jj < dimension; jj++)
                if (m[ii][jj] == 0) m[ii][jj] = I;
        return m;
    }

    // Idem dirigidos (VD)
    public static int[][] creaAdyVD(String s, int dimension) {
        int[][] m = new int[dimension][dimension];
        int longitud = s.length(), i, j;
        for (int k = 0; k < longitud; k += 3) {
            i = s.charAt(k) - '0';
            j = s.charAt(k + 1) - '0';
            m[i][j] = s.charAt(k + 2) - '0';
        }
        for (int ii = 0; ii < dimension; ii++)
            for (int jj = 0; jj < dimension; jj++)
                if (m[ii][jj] == 0) m[ii][jj] = I;
        return m;
    }

    // Muestra matriz de adyacencias
    public static void muestra(int[][] ady) {
        System.out.println();
        for (int i = 0; i < ady.length; i++) {
            for (int j = 0; j < ady.length; j++) {
                System.out.print("  " + (ady[i][j] == I ? "-" : ady[i][j]));
            }
            System.out.println();
        }
    }

    // FORMA 2 (objetos de la clase GE):

    // Grafo de enteros GE a partir de lista de arcos
    // con d�gitos en extremos (solo del 0 al 9)
    public static Grafo<Integer> creaGEent(String s) {
        Grafo<Integer> g = new GNDE<Integer>();
        int l = s.length(), x, y;
        for (int i = 0; i < l; i += 2) {
            x = (int) s.charAt(i) - '0';
            y = (int) s.charAt(i + 1) - '0';
            if (!g.EstaContenido(x)) g.InclNodo(x);
            if (!g.EstaContenido(y)) g.InclNodo(y);
            g.InclArco(x, y);
        }
        return g;
    }

    // Grafo de caracteres GE a partir de string de arcos
    public static Grafo<Character> creaGEcar(String s) {
        Grafo<Character> g = new GNDE<Character>();
        int l = s.length();
        for (int i = 0; i < l; i += 2) {
            if (!g.EstaContenido(s.charAt(i))) g.InclNodo(s.charAt(i));
            if (!g.EstaContenido(s.charAt(i + 1))) g.InclNodo(s.charAt(i + 1));
            g.InclArco(s.charAt(i), s.charAt(i + 1));
        }
        return g;
    }

    // PRACTICE 4
    public static Lista<Integer>[][] Floyd(int[][] adj) {
        Lista<Integer>[][] path = new LD[adj.length][adj.length];
        if (adj.length != 0) {
            for (int i = 0; i < path.length; i++) {
                for (int j = 0; j < path.length; j++) {
                    path[i][j] = new LD<Integer>();
                    if ((i != j) && (adj[i][j] != Integer.MAX_VALUE)) {
                        path[i][j].Add(j);
                        path[i][j].Add(i);
                    }
                }
            }
            for (int k = 0; k < path.length; k++) {
                for (int i = 0; i < path.length; i++) {
                    for (int j = 0; j < path.length; j++) {
                        //We check if a path containing an intermediate node would actually be faster
                        if ((adj[i][k] != Integer.MAX_VALUE) && (adj[k][j] != Integer.MAX_VALUE) && (adj[i][k] + adj[k][j] < adj[i][j])) {
                            try {
                                adj[i][j] = adj[i][k] + adj[k][j];
                                //We have to clone the list, otherwise we would be referencing the other list directly
                                path[i][j] = (LD<Integer>) path[i][k].clone();
                                path[i][j].Concatena(path[k][j].Cola());
                            } catch (TADVacioException ex) {
                                System.out.println(ex);
                                ;
                            }
                        }
                    }
                }
            }
        }
        return path;
    }


}
