package PaqTADNodo;

/** Clase Nodo para la implementaci�n del nodo de grafos */
 public class NodoGrafo<E> implements Cloneable
{
	public E Info;       // Informaci�n almacenada en el nodo
	public boolean Visitado;  // Nos indica si el nodo ya ha sido visitado.
    
	public NodoGrafo(E e, boolean v)
	{
    	  Info=e;
          Visitado=v;
        }

	public Object clone()
	{
		NodoGrafo<E> o=null;
		try
		{
			o=(NodoGrafo<E>) super.clone();
		}catch(CloneNotSupportedException e)
		{System.out.println(e);
		}
	
		return o;
	}
}