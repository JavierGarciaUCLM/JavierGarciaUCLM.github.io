// LA.java :  Versi�n de listas sobre arrays

package  PaqTADLineales.PaqLista;

import PaqTADVacioException.*;

import java.util.Arrays;
import java.util.Comparator;

/**
 * Clase LA para implementar la interface Lista<E> con arrays
 * 
 * @author Estructuras de Datos y de la Informaci�n 
 * @version Curso 2008-2009
*/

public class LA<E> implements Lista<E>,Cloneable,Comparable<Lista<E>> {
	
   private final int tamanoInicial =4;//Cantidad reservada inicialmente
   private final int incremento=4; //Cantidad a incrementar si falta
   private int tamano;    // Tama�o actual de la lista lista
   private E elementos[]; // Array con los elementos de la lista
   private int libre;     // Primera posici�n libre
	 
   public LA()
     { 
         // Devuelve una lista vac�a de tama�o tama�oInicial
            tamano = tamanoInicial;
            elementos =  (E[]) new Object[tamano];
            libre=0;
     }

    /**
     * Contruye una lista a partir de otra y un nuevo elemento
     * @param e nuevo elemento
     * @param c lista cualquiera
     */
    public LA(E e, Lista<E> c)
    {
        this();
        if (e!= null)
        {
            Lista<E> invc = new LA<E>(); // se invierte c
            while(!c.EsVacia()){
                invc.Add(c.Cabeza());
                c = c.Cola();
            }
            while(!invc.EsVacia()){
                this.Add(invc.Cabeza());
                invc=invc.Cola();
            }
            this.Add(e);
        }
        else
        {
            throw new NullPointerException();
        }
    }

    /**
     * Constructor que crea una lista con los elementos de un vector
     * (con cabeza v[0])
     * @param v vector de elementos
     */
    public LA(E[] v){
        this();
        int n = v.length;
        for (int i = n-1; i >= 0; i--) {
            this.Add(v[i]);
        }
    }

    public boolean EsVacia()
	 {
	 	return libre==0;
	 }
	 	 
    private void Incrementa()
	 {
	 	tamano +=incremento;
	 	elementos = Arrays.copyOf(elementos, tamano);
//      o bien:
//		E copia[]=(E[]) new Object[tama�o];
//	 	System.arraycopy(elementos,0,copia,0,elementos.length);
//		elementos=copia;
	 }	

     public void Add(E e)
     {
	     if (libre== tamano) Incrementa();
         elementos[libre] =e;
         libre++;
     }

	public E Cabeza()throws TADVacioException
	{
        if (libre==0) throw new TADVacioException();
        else return elementos[libre-1];
     }
	

      public Lista<E> Cola() throws TADVacioException
      {
         if (libre==0) throw new TADVacioException();
         else 
         {
           LA<E> l = new LA<E>();
           l.elementos = elementos;
           l.libre = libre-1;
           l.tamano = tamano;
           return l;
         }
      }
	

     public boolean EstaContenido(E e)
     {
	 for (int i=0; i<libre; i++)
             if (e.equals(elementos[i])) return true;
         return false;
     }		


     public int Longitud()
     {   
         return libre;
     }


    public void Concatena(Lista<E> l)
    {  // suponemos l lista con arrays --supos demasiado fuerte-
         E[] copia;
         LA<E> le=(LA<E>) l.clone();
		
        //Nos aseguramos de que quepa la concatenacion con cierta holgura
        if ((le.libre)>(tamano -libre))
           tamano =le.libre+libre+incremento;
        copia=(E[]) new Object[tamano];
        System.arraycopy(le.elementos,0,copia,0,le.libre);
        System.arraycopy(elementos,0,copia,le.libre,libre);
        elementos=copia;
        libre +=le.libre;         
    } 

     public Object clone() {
	  LA<E> o=null;
	  try
	  {
	    o=(LA<E>) super.clone();
            o.elementos=(E[])elementos.clone();

	  }catch(CloneNotSupportedException e)
	  {
	  	System.out.println("No se pudo clonar");
	  }
	  return  o;
     }

	
	public String toString()
{
        String s;
        int i;

        s=new String("(");
        for (i=libre-1; i>=0; i--) {
           s+=elementos[i];
           if (i>0) s+=", ";
        }
        s+=")";
        return s;
     }

   // M�TODOS AUN NO IMPLELENTADOS:
        
    public void Add(E e, int n) {
    }

    public boolean Elimina(E e) { return true;
    }

    public boolean EliminaAt(int n) { return true;
    }

    public E elemAt(int n) throws TADVacioException {return null;
    }

    public int Indice(E e) {return 0;
    }

    public Lista<E> Sublista(int i, int j) throws TADVacioException {return null;
    }
    
    public boolean equals(Lista<E> l) {return true;
    }

    public int compareTo(Lista<E> l) {return 0;
    }

    public void Ordenar(Comparator<E> c) {
    }

    public void Ordenar() throws IllegalArgumentException {
    }
}
