// CD.java

package PaqTADLineales.PaqCola;
//import PaqElemento.*;
import PaqTADLineales.PaqPila.PD;
import PaqTADLineales.PaqPila.Pila;
import PaqTADVacioException.*;
import PaqTADNodo.*;
import java.util.logging.Level;
import java.util.logging.Logger;

// clase Cola_Dinamica<E>, por comodidad renombrada como CD<E>

public class CD<E> implements Cola<E>,Cloneable,Comparable<Cola<E>>{

private Nodo<E>  NodoCabeza; // Nodo en cabeza de la Cola
private Nodo<E>  NodoFinal;  // Nodo en Cola

    /**
     * Construye cola vac�a (constructora CV de la definici�n del TAD
     */
    public CD()
    {
         NodoCabeza=null;
         NodoFinal=null;
    }

    /**
     * Contruye una cola partir de otra y un nuevo elemento
     * (constructora :. en la definici�n del TAD)
     * @param c cola cualquiera
     * @param e nuevo elemento, que queda al final (no en la cabeza)
     */
 public CD(Cola<E> c, E e)
 {
     if (e!= null)
     {
         CD<E> cd = new CD<E>();
         try {
             cd = new CD<E>(c.Resto(), e);
             cd.NodoCabeza = new Nodo(c.Cabeza(),cd.NodoCabeza);
         } catch (TADVacioException ex) {
             Nodo<E> nuevo = new Nodo(e,null);
             cd.NodoCabeza = nuevo;
             cd.NodoFinal = nuevo;
         }
         this.NodoCabeza = cd.NodoCabeza;
         this.NodoFinal  = cd.NodoFinal;
     }
     else
     {
         throw new NullPointerException();
     }
 }

    /**
     * Constructor que crea una cola con los elementos de un vector
     * (con cabeza v[0])
     * @param v vector de elementos
     */
    public CD(E[] v){
        int n = v.length;
        for (int i = 0; i < n; i++) {
            this.EnCola(v[i]);
        }
    }

 public boolean EsVacia()
{
   return (NodoCabeza == null);
}

// mejorable (no void, ...), pero puede usarse tambi�n el contructor
public void EnCola(E x)
{
    Nodo<E> Nuevo;
    if (x!=null)
    {
         Nuevo=new Nodo<E>(x, null);
         if (NodoCabeza==null) NodoCabeza=Nuevo;
         else  NodoFinal.Siguiente=Nuevo;
         NodoFinal=Nuevo;
    }
 }
	 
public E Cabeza()throws TADVacioException
{
    if (NodoCabeza == null) throw new TADVacioException();
    else return (E)NodoCabeza.Info;
}
	  
public Cola<E> Resto() throws TADVacioException
{
   CD<E> c;
   if (NodoCabeza == null) throw new TADVacioException();
   c = new CD<E>();
   c.NodoCabeza=NodoCabeza.Siguiente;
   if (c.NodoCabeza == null) 
       c.NodoFinal = null;
   else 
       c.NodoFinal =NodoFinal;
   return c;
}
	 
 public int Longitud() {
   Nodo<E> aux = NodoCabeza;
   int l=0;
   while (aux != null)
   {
       l++;
       aux = aux.Siguiente;
     }
   return l; 
 }	
 
public Object clone()
{
      CD<E> c1=null;
      Nodo<E> aux1, aux2;         
      try
      {
       c1=(CD<E>)super.clone();
      }catch (CloneNotSupportedException e)
		 {	//Esto no puede ocurrir al ser cloneable
		 }
      if (!EsVacia())
      {
        c1.NodoCabeza=(Nodo<E>)NodoCabeza.clone();
	if (NodoCabeza==NodoFinal)
		c1.NodoFinal=c1.NodoCabeza;
	else
	{
		c1.NodoFinal=(Nodo<E>)NodoFinal.clone();
		aux1=c1.NodoCabeza;
            	aux2=NodoCabeza.Siguiente;
            	while (aux2 != NodoFinal)
		{
            	  aux1.Siguiente=(Nodo<E>)aux2.clone();
		  aux2=aux2.Siguiente;
		  aux1=aux1.Siguiente;
		}
		aux1.Siguiente=c1.NodoFinal;
	}
         }	 
         return c1;
     }
	 	 
	 
 public String toString()
	 {
         String s=new String("[");
		 Nodo<E> actual=NodoCabeza;
		 while (actual != null)
		 {	
		 	s+=actual.Info.toString();
         	actual=actual.Siguiente;
         	if (actual != null) s+=", ";
         }
         s+="]"; 
         return s;
   }
	 
 
  
 public boolean equals(Object c) 
    {
        if (!(c instanceof Cola)) return false;
        Cola<E> cc = (Cola<E>) ((Cola<E>)c).clone();
        Nodo<E> aux = NodoCabeza;
        boolean iguales = true;
        while(aux!=null && !cc.EsVacia() && iguales)
        {
            try {
                iguales = aux.Info.equals(cc.Cabeza());
                cc=cc.Resto();
                aux = aux.Siguiente;
            } catch (TADVacioException ex) { ex.printStackTrace(); }
        }
        return (iguales && aux==null && cc.EsVacia());
    }


 // mejorable; mejor orden lexicogr�fico
 public int compareTo(Cola<E> c) {
        int l1 = this.Longitud(),
            l2 = c.Longitud();
        if (l1==l2) return 0;
        if (l1>l2) return 1;
        return -1;
    }
  
}