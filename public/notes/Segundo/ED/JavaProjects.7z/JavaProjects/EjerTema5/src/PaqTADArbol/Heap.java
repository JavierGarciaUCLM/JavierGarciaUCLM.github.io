

package PaqTADArbol;

import PaqTADVacioException.TADVacioException;

import java.util.Arrays;

/*  �rbol binario completo formando un mont�culo, implementado como un vector */
/*  Puede ser una implementaci�n de la interfaz ArbolBinario                  */

public class Heap<E extends Comparable<E>> implements Cloneable, ArbolBinario<E>
{
    private Object[] elem;        // Elementos del �rbol (la posici�n 0 guarda la cantidad)
    private int maxelem = 10,     // Cantidad m�xima de elementos (aumenta cuando es necesario)
                incrementos = 10; // Incrementos de maxelem cuando es necerario

    public Heap() {
        elem = new Object[maxelem + 1];
        elem[0] = 0;
    }

    public E Raiz() {
        if ((int) elem[0] == 0) throw new TADVacioException("�rbol vac�o");
        return (E) elem[1];
    }

    public boolean EsVacio() {
        return (int) elem[0] == 0;
    }

    public int Altura() {
        int cantidad = (int) elem[0], ultimonivel, elemhastanivel;
        if(cantidad==0) ultimonivel = 0;
        else {
            ultimonivel=1;
            elemhastanivel = 1;
            while (elemhastanivel*2 < cantidad) {
                elemhastanivel *= 2;
                ultimonivel++;
            }
        }
        return ultimonivel;
    }

    public Heap<E> SubArbolIzqdo(){
        if ((int) elem[0] == 0) throw new TADVacioException("�rbol vac�o");
        Heap<E> izdo = (Heap<E>) this.clone(); // puede ser m�s peque�o;
        izdo.elem[0] = 0;
        if((int)elem[0] >= 2) copia( this.elem, 2, izdo.elem, 1 );
        // eliminar incrementos sobrantes del final:
        // izdo.elem = Arrays.copyOf(izdo.elem,((int)izdo.elem[0]/incrementos) * incrementos + incrementos + 1);
        return izdo;
    }

    public Heap<E> SubArbolDcho() {
        if ((int) elem[0] == 0) throw new TADVacioException("�rbol vac�o");
        Heap<E> dcho = (Heap<E>) this.clone(); // podr�a ser m�s peque�o
        dcho.elem[0] = 0;
        if((int)elem[0] >= 3) copia( this.elem, 3, dcho.elem, 1 );
        // eliminar incrementos sobrantes del final:
        // dcho.elem = Arrays.copyOf(dcho.elem,((int)dcho.elem[0]/incrementos) * incrementos + incrementos + 1);
        return dcho;
    }

    /* Copia elementos de orig de la posici�n i y sus descencientes, a dest a partir de la j */
    private void copia(Object[] orig, int i, Object[] dest, int j){
        dest[j] = orig[i];
        dest[0] = (int)dest[0] + 1;
        if(2*i <= (int)orig[0])   copia( orig, 2*i, dest, 2*j );
        if(2*i+1 <= (int)orig[0]) copia( orig, 2*i+1, dest, 2*j+1 );
    }

    /* Cantidad de elementos */
    public int Size() {
        return (int) elem[0];
    }

    /* Inserta un nuevo elemento en la posici�n correcta */
    public void Insert(E x) {
        if ((int) elem[0] == maxelem) increment();
        int libre = (int) elem[0] + 1;
        elem[0] = libre;
        elem[libre] = x;
        int i = libre;
        Object y;
        // se intercambia v[i] por su padre mientras sea mayor
        while (i > 1 && ((Comparable) elem[i]).compareTo(elem[i / 2]) > 0) {
            y = elem[i / 2];
            elem[i / 2] = elem[i];
            elem[i] = y;
            i = i / 2;
        }
    }

    /* Elimina la ra�z y reconstruye el �rbol */
    public void Rebuild() {
        if ((int) elem[0] == 0) throw new IllegalArgumentException("Mont�culo vac�o");
        int ultima = (int) elem[0];
        elem[0] = ultima - 1;
        elem[1] = elem[ultima];
        int i = 1, j;
        Object m, y;
        boolean intercambio = true;
        // se intercambia elementos[i] por el mayor de sus hijos si es menor
        while (intercambio && 2 * i <= ultima - 1 && intercambio) {
            m = elem[2 * i];
            j = 2 * i;
            if (2 * i + 1 <= ultima - 1 && ((Comparable) elem[2 * i + 1]).compareTo(elem[2 * i]) > 0) {
                m = elem[2 * i + 1];
                j = 2 * i + 1;
            }
            if (((Comparable) elem[i]).compareTo(m) < 0) {
                y = elem[i];
                elem[i] = elem[j];
                elem[j] = y;
                i = j;
            } else {
                intercambio = false;
            }
        }
        // if((int)elem[0]<=maxelem-10) decrement();
    }

    // recorrido por niveles
    public String toString(){
        Object[] v = Arrays.copyOf(this.elem,(int)elem[0]+1);
        v[0] = "("+v[0]+" elems)";
        return Arrays.toString(v);
    }

    // iguales elemento a elemento si el par�metro es de la misma clase
    public boolean equals(Object o){
        Heap<E> copia = null;
        int cant = (int) this.elem[0];
        boolean iguales = o instanceof Heap;
        if(iguales) copia = (Heap<E>) o;
        for (int i = 0; iguales && i <= cant; i++)
               iguales = this.elem[i].equals(copia.elem[i]);
        return iguales;
    }

    public Object clone(){
        Heap<E> o=null;
        try
        {
            o=(Heap<E>) super.clone();
            o.elem = Arrays.copyOf(elem,maxelem+1);
        }catch(CloneNotSupportedException e)
        {
            System.out.println("No se pudo clonar");
        }
        return o;
    }

    private void increment()
    {
        maxelem+=incrementos;
        elem = Arrays.copyOf(elem, maxelem+1);
    }

    private void decrement()
    {
        maxelem-=incrementos;
        elem = Arrays.copyOf(elem, maxelem+1);
    }

}
