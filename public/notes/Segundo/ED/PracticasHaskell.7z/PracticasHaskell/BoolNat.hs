module BoolNat where

---------------------------------------------
-- Examples in Haskell:  Natural numbers
-- ------------------------------------------

data Nat = Cero | Suc Nat  deriving Show
                       

suma :: Nat -> Nat -> Nat 

suma Cero x       =  x
suma (Suc y) x    =  Suc (suma y x)

times :: Nat -> Nat -> Nat
times  Cero x = Cero
times  (Suc x)  y = suma ((times x y) y)
times y (Suc x) = suma ((times y x) (Suc x)) -- Comprobar si esto está bien en casa
-- 5 * 3 = 4 * 3 + 4 = 3 * 3 + 4 + 4 = ...
-- 3 * 5 = 
--
power :: Nat -> Nat -> Nat
--power Cero Cero = ... Asume this doesn't happen
power x y = x
--

resta :: Nat -> Nat -> Nat
resta Cero x          =  Cero
resta (Suc x) Cero    =  Suc x
resta (Suc x) (Suc y) =  resta x y

minimo :: Nat -> Nat -> Nat
minimo Cero x          =  Cero
minimo (Suc x) Cero    =  Cero
minimo (Suc x) (Suc y) =  Suc (minimo x y)

maximo :: Nat -> Nat -> Nat
maximo  Cero x          =  x
maximo (Suc x) Cero    =  Suc x
maximo (Suc x) (Suc y) =  Suc (maximo x y)

mod10 :: Nat -> Nat
mod10 (Suc(Suc(Suc(Suc(Suc(Suc(Suc(Suc(Suc(Suc(x))))))))))) = mod10 x
mod10 x = x

nueve :: Nat
nueve = Suc(Suc(Suc(Suc(Suc(Suc(Suc(Suc(Suc(Cero)))))))))

menor2 :: Nat -> Nat -> Bool
menor2 Cero Cero = False
menor2 Cero _ = True
menor2 (Suc x) Cero = False
menor2 (Suc x) (Suc y) = menor2 x y

modulo :: Nat -> Nat -> Nat
modulo x y = if (menor2 x y) then x
               else modulo (resta x y) y


-- For displaying  Natural numbers...

{- ....required if we don't use deriving

instance Show Nat where
   show Cero     = "0"
   show (Suc x)  = "S(" ++ show x ++ ")"

-}


---------------------------------------------
-- Example in Haskell:  Integers
-- ------------------------------------------


data Inte  = Z |  S Inte | P Inte deriving Show

nf_Inte, aux_nf_Inte :: Inte  -> Inte

nf_Inte Z      =   Z
nf_Inte (S x)  =   aux_nf_Inte (S (nf_Inte x))
nf_Inte (P x)  =   aux_nf_Inte (P (nf_Inte x))


aux_nf_Inte (S (P x)) = x
aux_nf_Inte (P (S x)) = x
aux_nf_Inte x = x

{- OLDER VERSION FOR nf_Inte:
nf_Inte Z      =   Z
nf_Inte (S x)  =   auxS (nf_Inte x)
nf_Inte (P x) =   auxP (nf_Inte x)

auxS :: Inte -> Inte
auxS (P x) = x
auxS  x    = (S x)

auxP :: Inte -> Inte
auxP (S x) = x
auxP  x    = (P x)
-}

example_2 :: Inte 
example_2 = P (S (S (P (S (P ( P (P Z)))))))

change :: Inte -> Inte
change Z = Z
change (S x) = P (change x)
change (P x) = S (change x)
-- Write expression for obtaining P(P Z)


sumI, aux_sumI:: Inte -> Inte -> Inte

-- STANDARD VERSION
sumI x y = aux_sumI (nf_Inte x) (nf_Inte y) 

aux_sumI  Z x = x
aux_sumI (S x) (P y) = aux_sumI x y
aux_sumI (S x) y = S (aux_sumI x y)
aux_sumI (P x) (S y) = aux_sumI x y
aux_sumI (P x) y = P (aux_sumI x y)

{-  ... or alternatively this DANGEROUS STRATEGY that can not be applied, in general, to other ADT's:
sumI x y = nf_Inte (aux_sumI x y)

aux_sumI  Z x = x
aux_sumI (S x) y = S (aux_sumI x y)
aux_sumI (P x) y = P (aux_sumI x y)
-}


data Bool10 = Verdad Nat deriving Show

not10 :: Bool10 -> Bool10
not10 (Verdad x) = Verdad (resta nueve x)

and10 :: Bool10 -> Bool10 -> Bool10
and10 (Verdad x) (Verdad y) = Verdad (minimo x y)

or10 :: Bool10 -> Bool10 -> Bool10
or10 (Verdad x) (Verdad y) = Verdad (maximo x y)


fnBool10 :: Bool10 -> Bool10
fnBool10 (Verdad x) = Verdad (mod10 x)




data Logico = Cierto | Falso  deriving Show

yy, oo :: Logico -> Logico -> Logico   

yy Cierto b = b           
yy Falso  b = Falso       

-- oo Cierto _ = Cierto
-- oo Falso  x = x

oo Falso Falso = Falso
oo _  _ = Cierto

no :: Logico -> Logico
no Cierto = Falso
no Falso  = Cierto




-- Examples in Haskell: Booleans with non free generators  ------------------------------------------

data Logico2 = Cierto2 | No2 Logico2 deriving Show

-- Instead of the equivalence axiom
--     No2 (No2 b) = b
-- we define an operation for computing normal forms

fn2 :: Logico2 -> Logico2
fn2 Cierto2 = Cierto2
fn2 (No2 Cierto2) = No2 Cierto2
fn2 (No2 (No2 b)) = fn2 b


yy2, oo2, aux_yy2, aux_oo2 :: Logico2 -> Logico2 -> Logico2

yy2 b c = aux_yy2 (fn2 b) (fn2 c)

aux_yy2 Cierto2 b = b
aux_yy2 (No2 b) c = No2 Cierto2


oo2 b c = aux_oo2 (fn2 b) (fn2 c)
aux_oo2 Cierto2 b = Cierto2
aux_oo2 (No2  b) c = c




-- Examples in Haskell: Bool3
------------------------------------------

{-   COMMENT !!!!!!!!
data Bool3 = T | M | F

not3 :: Bool3 -> Bool3

not3 T = F
not3 M = M
not3 F = T

and3 :: Bool3 ->  Bool3 -> Bool3

and3 T b = b
and3 M T = M
and3 M M = M
and3 M F = F
and3 F b = F


or3  :: Bool3 -> Bool3 -> Bool3

or3 T b = T
or3 M T = T
or3 M M = M
or3 M F = M
or3 F b = b



-- For displaying Bool3

instance Show Bool3 where
   show T     = "T"
   show F     = "F"
   show M     = "M"

   
----------------------


andor :: [Bool3] -> Bool3

andor [x] = x
andor [x,y] = and3 x y
andor (x:y:z:t) = andor ((or3 (and3 x y) z):t)

-}   -- END COMMENT



{-

--- Another version using an auxiliary  operation ......

andor [x] = x
andor (x:y:t) = orand ((and3 x y):t)

orand :: [Bool3] -> Bool3

orand [x] = x
orand (x:y:t) = andor ((or3 x y):t)


--- One more version with auxiliar operation  and extra parameter.....

andor l = aux3 T l

aux3 :: Bool3 -> [Bool3] -> Bool3
aux3 _ [x] = x
aux3 T (x:y:t)  = aux3 F ((and3 x y):t)
aux3 F (x:y:t)  = aux3 T ((or3 x y):t)


-------------------------------
-}




data BoolNOR = F | NOR BoolNOR BoolNOR deriving Show

nfNOR,notNOR,aux_notNOR:: BoolNOR -> BoolNOR
auxNOR,orNOR, aux_orNOR:: BoolNOR -> BoolNOR -> BoolNOR

nfNOR F = F
nfNOR (NOR x y) = auxNOR (nfNOR x) (nfNOR y)

auxNOR F F = NOR F F
auxNOR _ _ = F

notNOR x = aux_notNOR (nfNOR x)

aux_notNOR F = NOR F F
aux_notNOR (NOR F F) = F

orNOR x y = aux_orNOR (nfNOR x) (nfNOR y)

aux_orNOR F x = x
aux_orNOR _ _ = NOR F F

{-

EXAMPLE OF DERIVATION SEQUENCE

nfNOR (NOR F (NOR (NOR F F) F))   -> rule 2
auxNOR (nfNOR F) (nfNOR NOR (NOR F F) F)) -> rule 1 
auxNOR F (nfNOR NOR (NOR F F) F)) -> rule 2
auxNOR F (auxNOR (nfNOR (NOR F F)) (nfNOR F)) -> rule 2
auxNOR F (auxNOR (auxNOR (nfNOR F) (nfNOR F) (nfNOR F)) -> rule 1
auxNOR F (auxNOR (auxNOR F  (nfNOR F) (nfNOR F)) -> rule 1
auxNOR F (auxNOR (auxNOR F  F (nfNOR F)) -> rule 1
auxNOR F (auxNOR (auxNOR F  F) F)  ->  rule 3
auxNOR F (auxNOR (NOR F F)  F)  -> rule 4
auxNOR F F -> rule 3 
NOR F F



-}



-- examples in Haskell: sets
------------------------------------------



data Conjunto a = Vacio | CNV a (Conjunto a)


-- Suponemos que los conjuntos sobre los que operamos est�n
-- en forma normal (no hay elementos repetidos). Para esto
-- es necesario suponer que los elementos pueden compararse
-- con == (o no tendr�a sentido el concepto de "elemento repetido").
-- Los conjuntos devueltos tambi�n los dejaremos as�.


-- Para convertir a fn (quitar elementos repetidos):
fn :: (Eq a) => Conjunto a -> Conjunto a
fn Vacio = Vacio
fn (CNV i s) = if pertenece i s then fn s else CNV i (fn s)

interseccion :: (Eq a) => Conjunto a  -> Conjunto a -> Conjunto a
interseccion s Vacio = Vacio
interseccion s (CNV i t) = if pertenece i s
                               then CNV i (interseccion s t)
                               else interseccion s t

restaCon :: (Eq a) => Conjunto a   -> Conjunto a -> Conjunto a
restaCon s Vacio = s
restaCon s (CNV i t) = if pertenece i s
                        then extrae i (restaCon s t)
                        else restaCon s t

extrae :: (Eq a) => a -> Conjunto a -> Conjunto a
extrae i Vacio = Vacio
extrae i (CNV j s) = if i == j
                         then s  -- suponemos que no est� mas veces
                         else CNV j (extrae i s)

esVacio :: Conjunto a -> Bool
esVacio Vacio = True
esVacio (CNV i s) = False

pertenece :: (Eq a) => a -> Conjunto a -> Bool
pertenece i Vacio        =  False
pertenece i (CNV j s)   =  (i == j) || pertenece i s

union, union' :: (Eq a) => Conjunto a -> Conjunto a -> Conjunto a
union s1 s2 = fn (union' s1 s2)  -- quita elementos repetidos de la uni�n
union' s Vacio = s
union' s (CNV i t) = CNV i (union s t)

cardinal  :: (Eq a) => Conjunto a -> Int
cardinal Vacio = 0
cardinal (CNV i s) = 1 + cardinal s

sumaCon :: Conjunto Int -> Int
sumaCon Vacio = 0
sumaCon (CNV i s) = i + sumaCon s

iguales :: (Eq a) => Conjunto a -> Conjunto a -> Bool
iguales s t = (incluido s t) && (incluido t s)

incluido :: (Eq a) => Conjunto a -> Conjunto a -> Bool
incluido s t = esVacio (restaCon s t)


-- COMPLEMENTS:

-- For using '==' with sets:

instance (Eq a) => Eq (Conjunto a) where
   s == t  = (incluido s t) && (incluido t s)

-- PFor displaying sets like {...} (similar to  toString() in Java):
instance (Show a) => Show (Conjunto a) where
   show s     = "{"++ showelem s ++ "}"

-- auxiliar for show:
showelem :: (Show a)=> Conjunto a -> String
showelem Vacio = ""
showelem (CNV i Vacio) = show i
showelem (CNV i s) = show i ++ ", " ++ showelem s


ej1,ej2 :: Conjunto Int
ej1 = CNV 5 (CNV 4 (CNV 3 Vacio))
ej2 = CNV 4 (CNV 5 (CNV 3 (CNV 1 Vacio)))



{-   CLASS 23/10/2020

Insert the sequence of elements
 1, 2 and finally 3 on a list, an stack and a queue

LIFO: LAST INPUT FIRST OUTPUT

List           3 : 2 :  1 :  []    --  [3,2,1] 

Stack	       3 :/ 2 :/ 1 :/ ES

FIFO: FIRST INPUT FIRST OUTPUT

Queue		  EQu :. 1:. 2 :. 3

head list: 3,     top stack: 3,  but first queue: 1
tail list: [2,1]  pop stack: 2 :/ 1 :/ ES
           but the rest queue is EQu :. 2 :. 3
-}


infixr 5 :/
data Stack a = ES |  a :/ (Stack a) deriving Show

top:: Stack a -> a
top (x :/ _ ) = x

pop :: Stack a -> Stack a
pop (_ :/ t ) = t

infixl 5 :.
data Queue a = EQu |  (Queue a) :. a deriving Show

emptyQ :: Queue a -> Bool
emptyQ EQu = True
emptyQ _ = False

first :: Queue a -> a
first (EQu :. x) = x
first (c :. x) = first c
-- Example: first (EQ :. 3 :. 5 :. 2 :. 7) -----> 3

rest :: Queue a -> Queue a
rest (EQu :. x) = EQu
rest (c :. x) = (rest c) :. x
-- Example: rest (EQ :. 3 :. 5 :. 2 :. 7) -----> EQ :. 5 :. 2 : 7

concatQ:: Queue a -> Queue a -> Queue a
-- concat (EQu :. 1 :. 2)  (EQu :. 3 :. 4)  --> 
--                EQu :. 1 :. 2 :. 3 :. 4 
concatQ q EQu = q
--concatQ q1 (q2:.x)  = (concatQ q1 q2) :. x
concatQ q x  = concatQ (q :. (first x))  (rest x)   

-- Stack to queue: 
-- Example s2q (1 :/  2 :/ ES) --> (EQu :. 2) :. 1

s2q:: Stack a -> Queue a
s2q ES = EQu
s2q (x :/ s) = (s2q s) :. x

-- Now, insertions in the output queue are reversed 
-- with respect to the input stack 
-- Example: s2qrev (1 :/  2 :/ ES)  --> (EQu :. 1) :. 2

s2qrev:: Stack a -> Queue a
s2qrev s =  aux_s2qrev s EQu

aux_s2qrev:: Stack a -> Queue a -> Queue a
aux_s2qrev ES     q = q
aux_s2qrev (x:/s) q = aux_s2qrev s (q:.x)


-- PARTICIPATION MARKS!!!!!  23/10/2020
consqs ::  Stack a -> Queue a  -> Stack a
-- for instance, consqs (1 :/  2 :/ ES) (EQu :. 3 :. 4)  --> 
--                1 :/ 2 :/ 3 :/ 4 ES   
consqs s _ = s -- WRONG 

consqq ::  Stack a -> Queue a  -> Queue a
-- for instance, consqq (1 :/  2 :/ ES) (EQu :. 3 :. 4)  --> 
--                EQu :.1 :. 2 :. 3 :. 4 
consqq s EQu = s2qrev s
consqq s (q:.x) = (consqq s q) :. x

 
conqsq :: Queue a ->  Stack a -> Queue a  
-- for instance, conqsq (EQu :. 1 :.  2) (3 :/ 4 :/ ES)  --> 
--                EQu :.1 :. 2 :. 3 :. 4    
conqsq q ES = q
conqsq q (x:/s) = conqsq (q:.x)  s


conqss :: Queue a ->  Stack a -> Stack a  
-- for instance, conqss (EQu :. 1 :.  2) (3 :/ 4 :/ ES)  --> 
--                1 :/ 2 :/ 3 :/ 4 ES   

conqss _ s = s  -- WRONG 

{- Different shapes for Java methods implementing 
the Haskell generator :/ of stacks

public void APila(E e)
public void APila(Pila<E> s, E e)
public Pila<E> APila(E e)
public static Pila<E> APila(Pila<E> s, E e)

Or even as a generator in a concrete class

SIMPLE VERSION:
public Pila_Dinamica(E e, Pila_Dinamica<E> s)
{         NodoCabeza=new Nodo<E>(e, s.NodoCabeza); }

SAFER VERSION: 
public Pila_Dinamica(E e, Pila_Dinamica<E> s)
{	if (e!= null)
	  {  Pila_Dinamica aux=(Pila_Dinamica)(s.clone());
         NodoCabeza=new Nodo<E>(e, aux.NodoCabeza);       
      } 
    else 
       {
         throw new NullPointerException();
       }
}

MORE COMPLEX VERSION:
public Pila_Dinamica(E e, Pila_<E> s)
{  ..................   }

-}