infixr 5 :/
data Stack a = ES | a :/ (Stack a) deriving Show

infixl 5 :.
data Queue a = EQu | (Queue a) :. a deriving Show

-- Specification mejorada 2023

op22 :: Queue a -> Stack a -> Stack a
op22 EQu ES = ES
op22 EQu (x:/s) = s
op22 (q:.x) s = x:/(op22 q s)