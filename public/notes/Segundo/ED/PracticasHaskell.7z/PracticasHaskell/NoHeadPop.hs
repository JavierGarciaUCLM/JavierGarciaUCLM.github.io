infixr 5 :/
data Stack a = ES | a :/ (Stack a) deriving Show

infixl 5 :.
data Queue a = EQu | (Queue a) :. a deriving Show


op22 :: Queue a -> Stack a -> Stack a
op22 EQu s = s
op22 (q :. x) ES = x :/ ES
op22 (q :. x) s = x :/ (op22 q s)
