DROP DATABASE IF EXISTS dbpro24;
CREATE DATABASE dbpro24
    WITH 
    OWNER = postgres
    TEMPLATE = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'Spanish_Spain.1252'
    LC_CTYPE = 'Spanish_Spain.1252'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1;

\c dbpro24

DROP TABLE IF EXISTS TIENE, PERSONA, ORGANIZACION, AHORRO, CUENTA, CLIENTE, SUCURSAL, CASCADE;

CREATE TABLE IF NOT EXISTS CLIENTE(
    codigo VARCHAR(9) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    direccion VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS PERSONA(
    codigo VARCHAR(9) references CLIENTE(codigo) ON UPDATE CASCADE ON DELETE CASCADE PRIMARY KEY,
    genero VARCHAR(6) NOT NULL,
    fecha_nacimiento DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS ORGANIZACION(
    codigo VARCHAR(9) references CLIENTE(codigo) ON UPDATE CASCADE ON DELETE CASCADE PRIMARY KEY,
    representante VARCHAR(50) NOT NULL,
    tipo VARCHAR(20) NOT NULL,
    n_empleados INTEGER
);

CREATE TABLE IF NOT EXISTS SUCURSAL(
    su_id VARCHAR (4) PRIMARY KEY,
    direccion VARCHAR (50) NOT NULL,
    ciudad VARCHAR (50) NOT NULL,
    codigo_postal VARCHAR (5) NOT NULL,
    es_administrado VARCHAR (4) references SUCURSAL(su_id) ON UPDATE RESTRICT ON DELETE RESTRICT,
    CONSTRAINT localizacion UNIQUE (direccion, ciudad)
);

CREATE TABLE IF NOT EXISTS CUENTA(
    su_id VARCHAR (4) references SUCURSAL(su_id) ON UPDATE CASCADE ON DELETE CASCADE,
    ncuenta VARCHAR(10),
    codigo VARCHAR(9) NOT NULL references CLIENTE(codigo) ON UPDATE CASCADE ON DELETE CASCADE,
    saldo_actual NUMERIC(10, 2) NOT NULL,
    saldo_medio NUMERIC(10, 2) NOT NULL,
    PRIMARY KEY (su_id, ncuenta),
    UNIQUE (su_id, codigo)
);

CREATE TABLE IF NOT EXISTS AHORRO(
    su_id VARCHAR (4),
    ncuenta VARCHAR(10),
    tipo_amortizacion VARCHAR(15),
    FOREIGN KEY (su_id, ncuenta) REFERENCES CUENTA(su_id, ncuenta) ON UPDATE CASCADE ON DELETE CASCADE,
    PRIMARY KEY (su_id, ncuenta)
);

-- Inserting sample data
INSERT INTO CLIENTE VALUES
    ('c00001', 'cliente1', 'dir1'),
    ('c00002', 'cliente2', 'dir2'),
    ('c00003', 'cliente3', 'dir3'),
    ('c00004', 'cliente4', 'dir4'),
    ('c00005', 'cliente5', 'dir5'),
    ('c00006', 'cliente6', 'dir6');

INSERT INTO PERSONA VALUES
    ('c00001', 'hombre', '2001-01-01'),
    ('c00002', 'mujer', '2002-02-02'),
    ('c00003', 'mujer', '2003-03-03');

INSERT INTO ORGANIZACION VALUES
    ('c00004', 'repre4', 'PYME', 50),
    ('c00005', 'repre5', 'Gran empresa', 300),
    ('c00006', 'repre6', 'PYME', DEFAULT);

INSERT INTO SUCURSAL VALUES
    ('s001', 'Calle Sucursal1', 'ciudad1', '11111', NULL),
    ('s002', 'Calle Sucursal2', 'ciudad2', '22222', NULL),
    ('s003', 'Calle Sucursal1_2', 'ciudad1_2', '11222', 's001');

INSERT INTO CUENTA VALUES
    ('s001', 'cc00010001', 'c00001', 1000.25, 100),
    ('s001', 'cc00010002', 'c00002', 1200.25, 150),
    ('s002', 'cc00020001', 'c00001', 1700.75, 200),
    ('s002', 'cc00020002', 'c00002', 2000.75, 300),
    ('s002', 'cc00020003', 'c00003', 3000.75, 400),
    ('s003', 'cc00030001', 'c00004', 5000.75, 500),
    ('s003', 'cc00030002', 'c00005', 13200.75, 600);

INSERT INTO AHORRO VALUES
    ('s001', 'cc00010001', 'Lineal'),
    ('s001', 'cc00010002', 'Francés'),
    ('s002', 'cc00020002', 'Francés'),
    ('s002', 'cc00020003', 'Alemán'),
    ('s003', 'cc00030001', 'Americano');



------------------------A PARTIR DE AQUI VIENEN LOS SCRIPTS E INSERTS PARA QUE SE VEAN LOS EJEMPLOS-------------

CREATE OR REPLACE FUNCTION calcula_balance_cliente (codigo_cliente VARCHAR(9))
RETURNS NUMERIC AS $$
DECLARE
    total_balance NUMERIC := 0;
    rec RECORD;
BEGIN
    -- Mirar si cliente existe
    IF (SELECT COUNT(*) FROM CLIENTE WHERE codigo = codigo_cliente) = 0 THEN
        RAISE EXCEPTION 'El Cliente % no existe', codigo_cliente;
    END IF;

    -- Calcular el balance
    FOR rec IN (SELECT saldo_actual FROM CUENTA WHERE codigo = codigo_cliente) LOOP
        total_balance := total_balance + rec.saldo_actual;
    END LOOP;

    RAISE NOTICE 'Balance total para el cliente % es %', codigo_cliente, total_balance;
    RETURN total_balance;
EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Ha ocurrido algun error: %', SQLERRM;
        RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION genera_reporte(codigo_cliente VARCHAR(9))
RETURNS TABLE (
    numero_cuenta VARCHAR(10),
    id_sucursal VARCHAR(4),
    tipo_cuenta VARCHAR(15),
    saldo_actual NUMERIC,
    saldo_promedio NUMERIC,
    saldo_total NUMERIC
) AS $$
DECLARE
    cur CURSOR FOR SELECT cu.ncuenta, cu.su_id, cu.saldo_actual, cu.saldo_medio FROM CUENTA cu WHERE cu.codigo = codigo_cliente;
    cuenta VARCHAR(10);
    sucursal VARCHAR(4);
    tipo VARCHAR(15);
    saldo NUMERIC;
    promedio NUMERIC;
    total NUMERIC := 0;
BEGIN
    -- Miramos que el cliente exista
    IF (SELECT COUNT(*) FROM CLIENTE WHERE codigo = codigo_cliente) = 0 THEN
        RAISE EXCEPTION 'El Cliente % no existe', codigo_cliente;
    END IF;

    -- Calcula el balance total llamando a la función calcula_balance_cliente
    total := calcula_balance_cliente(codigo_cliente);

    OPEN cur;
    LOOP
        FETCH NEXT FROM cur INTO cuenta, sucursal, saldo, promedio;
        EXIT WHEN NOT FOUND;

       
        IF EXISTS (SELECT 1 FROM AHORRO WHERE su_id = sucursal AND ncuenta = cuenta) THEN  -- Sacamos el tipo de cuenta
            tipo := 'Ahorro';
        ELSE
            tipo := 'Corriente';
        END IF;

       
        numero_cuenta := cuenta;  -- Asignamos valores a los parámetros que salen
        id_sucursal := sucursal;
        tipo_cuenta := tipo;
        saldo_actual := saldo;
        saldo_promedio := promedio;
        saldo_total := total;
        
        RETURN NEXT;
    END LOOP;
    CLOSE cur;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION registrar_morosos_sucursal(id_sucursal VARCHAR(4))
RETURNS VOID AS $$
DECLARE
    rec RECORD;
    saldo_total NUMERIC;
BEGIN
    -- Crear la tabla de morosos
    CREATE TABLE IF NOT EXISTS MOROSOS (
        codigo_cliente VARCHAR(9) PRIMARY KEY,
        nombre_cliente VARCHAR(50) NOT NULL,
        id_sucursal VARCHAR(4) NOT NULL,
        saldo_total NUMERIC NOT NULL
    );

    -- Cursor para recorrer los clientes de la sucursal especificada
    FOR rec IN 
        SELECT c.codigo, c.nombre
        FROM CLIENTE c
        JOIN CUENTA cu ON c.codigo = cu.codigo
        WHERE cu.su_id = id_sucursal
    LOOP
        -- Calcular el balance total del cliente
        saldo_total := calcula_balance_cliente(rec.codigo);

        
        IF saldo_total <= 0 THEN -- Si el balance = 0 or (-), insertar en la tabla de morosos
            INSERT INTO MOROSOS (codigo_cliente, nombre_cliente, id_sucursal, saldo_total)
            VALUES (rec.codigo, rec.nombre, id_sucursal, saldo_total)
            ON CONFLICT (codigo_cliente) DO UPDATE 
            SET nombre_cliente = EXCLUDED.nombre_cliente,
                id_sucursal = EXCLUDED.id_sucursal,
                saldo_total = EXCLUDED.saldo_total;
        END IF;
    END LOOP;
EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error al registrar morosos en la sucursal %: %', id_sucursal, SQLERRM;
END;
$$ LANGUAGE plpgsql;


-- Inserts para tener morosos
INSERT INTO CLIENTE (codigo, nombre, direccion)
VALUES ('c00007', 'cliente7', 'dir7');
INSERT INTO CUENTA (su_id, ncuenta, codigo, saldo_actual, saldo_medio)
VALUES ('s002', 'cc00010006', 'c00007', -4000, -400);

--SELECT calcula_balance_cliente ('c00001');
--SELECT * FROM genera_reporte ('c00001');

--SELECT registrar_morosos_sucursal('s002');
--SELECT * FROM MOROSOS;