
----------Entrega vistas BBDD-------------
--Vista1--
CREATE OR REPLACE VIEW vista1 AS 
    WITH RECURSIVE SubSucursales AS (
	SELECT su_id, direccion, es_administrado FROM sucursal WHERE su_id = 's001'
	UNION ALL
	SELECT Sucursal.su_id, Sucursal.direccion, Sucursal.es_administrado FROM sucursal
	INNER JOIN SubSucursales ON SubSucursales.su_id = Sucursal.es_administrado )
SELECT * FROM SubSucursales;



--Vista2--
CREATE OR REPLACE VIEW vista2 AS
WITH SaldoMinimoEnSucursalConMasClientes AS (
    SELECT MIN(saldo_actual) AS saldo_minimo 
    FROM CUENTA 
    WHERE su_id = (
        SELECT su_id 
        FROM CUENTA 
        GROUP BY su_id
        ORDER BY COUNT(DISTINCT codigo) DESC
        LIMIT 1
    )
), SucursalesCalificadas AS (
    SELECT su_id 
    FROM CUENTA
    GROUP BY su_id
    HAVING AVG(saldo_medio) > (SELECT saldo_minimo FROM SaldoMinimoEnSucursalConMasClientes)
)
SELECT DISTINCT cl.codigo AS codigo_cliente, cl.nombre AS nombre_cliente
FROM CLIENTE cl
JOIN CUENTA ct ON cl.codigo = ct.codigo
WHERE ct.su_id IN (SELECT su_id FROM SucursalesCalificadas)
GROUP BY cl.codigo, cl.nombre
HAVING COUNT(DISTINCT ct.su_id) = (SELECT COUNT(*) FROM SucursalesCalificadas);

--Inserciones para que muestre resultados

INSERT INTO CLIENTE VALUES ('c00007', 'cliente7', 'dir7'), ('c00008', 'cliente8', 'dir8');
INSERT INTO SUCURSAL VALUES ('s004', 'Calle Sucursal4', 'ciudad4', '44444', 's001');
INSERT INTO CUENTA VALUES 
('s003', 'cc00010005', 'c00007', 3000.50, 2700),
('s004', 'cc00010001', 'c00008', 3500.75, 3300);
INSERT INTO AHORRO VALUES
('s003', 'cc00010005', 'Variable'),
('s004', 'cc00010001', 'Fijo');



--Vista3--
CREATE OR REPLACE VIEW vista3 AS
WITH media AS (
	SELECT AVG(saldo_medio) AS mediosaldo FROM CUENTA JOIN SUCURSAL ON CUENTA.su_id = SUCURSAL.su_id WHERE ciudad = 'ciudad2')
	SELECT DISTINCT c.ncuenta, codigo FROM CUENTA c
	JOIN (
		Select ncuenta FROM Ahorro where su_id IN (Select su_id FROM SUCURSAL WHERE ciudad = 'ciudad2')) as CUENTA2
	ON c.ncuenta = CUENTA2.ncuenta, media
	WHERE saldo_actual > media.mediosaldo;



--Vista4--
CREATE OR REPLACE VIEW vista4 AS
WITH RECURSIVE JerarquiaSucursal AS (
    SELECT su_id, direccion, ciudad, codigo_postal, es_administrado
    FROM SUCURSAL 
    WHERE su_id = 's002'
    UNION ALL 
    SELECT s.su_id, s.direccion, s.ciudad, s.codigo_postal, s.es_administrado
    FROM SUCURSAL s
    INNER JOIN JerarquiaSucursal sj ON s.es_administrado = sj.su_id
), TotalSaldo AS (
    SELECT sj.su_id, SUM(c.saldo_actual) AS SaldoTotal
    FROM JerarquiaSucursal sj
    JOIN CUENTA c ON sj.su_id = c.su_id
	WHERE c.saldo_actual>0
    GROUP BY sj.su_id
),
DIVIDIR AS (
    SELECT sj.su_id
    FROM JerarquiaSucursal sj
    EXCEPT
    SELECT ts.su_id
    FROM TotalSaldo ts
)
SELECT su_id
FROM SUCURSAL
WHERE su_id IN (SELECT su_id FROM DIVIDIR);

--Inserciones para que muestre resultados

INSERT INTO SUCURSAL VALUES ('S006','CALLE_BRANCH6', 'ciudad6', '11456', 's002');
INSERT INTO SUCURSAL VALUES ('S007','CALLE_BRANCH7', 'ciudad7', '11457', 's002');
INSERT INTO SUCURSAL VALUES ('S008','CALLE_BRANCH8', 'ciudad8', '11458', 's002');

INSERT INTO CUENTA VALUES ('S006', 'cc00010002', 'c00001',0, 100);
INSERT INTO CUENTA VALUES ('S007', 'cc00010001', 'c00001',0, 100);
INSERT INTO CUENTA VALUES ('S008', 'cc00010001', 'c00001',45345, 100);

