/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk;

import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;

/**
 *
 * @author usuario
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int contador = 0;
        Context c;
QueueConnectionFactory f;
QueueSession qs;
Queue q; // De jms, no de util!
QueueConnection cc;
QueueReceiver r;
Mensaje m;
ObjectMessage om;

try{
    c=new InitialContext();
f=(QueueConnectionFactory)c.lookup("factoriaConexiones");
q=(Queue)c.lookup("cola");
cc=f.createQueueConnection();
qs=cc.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
cc.start();
r=qs.createReceiver(q);

while (true){
om = (ObjectMessage) r.receive(0);
m = (Mensaje) om.getObject();
switch (m.getOp()) {
 case 1:
 // Suma
 contador += m.getValor();
 break;
 case 2:
 // Resta
 contador -= m.getValor();
 break;
 case 3:
 // Multiplicación
 contador *= m.getValor();
 break;
     default:
 System.out.println("Código de operación desconocido");
    continue;

}

 System.out.println("Valor del contador: " + contador);
  if (contador > 100) {
  System.out.println("El contador es mayor que 100. Terminando la ejecución...");
   break;
            }

}
cc.close();
}catch(Exception e){e.printStackTrace();} 

    }
    
}