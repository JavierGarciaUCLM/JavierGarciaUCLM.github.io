/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk;

import java.io.Serializable;

/**
 *
 * @author usuario
 */


public class Mensaje implements Serializable{
    
    int op;
    int valor;
    Mensaje(int op, int valor){
        this.op = op;
        this.valor = valor;
    }
    
    public int getOp() {
        return op;
    }

    public int getValor() {
        return valor;
    }

    public void setOp(int op) {
        this.op = op;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
}
    

