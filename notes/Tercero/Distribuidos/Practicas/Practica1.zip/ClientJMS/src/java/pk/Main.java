/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk;

import java.util.Scanner;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;

/**
 *
 * @author usuario
 */
public class Main {
    

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        // TODO code application logic here
        
    Context c;
    QueueConnectionFactory f;
    QueueSession qs;
    Queue q;
    QueueConnection cc;
    QueueSender s;
    Mensaje m;
    ObjectMessage om;
        try{
        c=new InitialContext();
        f=(QueueConnectionFactory)c.lookup("factoriaConexiones");
        q=(Queue)c.lookup("cola");
        cc=f.createQueueConnection();
        qs=cc.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
        cc.start();
        
        //Parte 4
        s=qs.createSender(q);
        
        Scanner scanner = new Scanner(System.in);
        int opcion;
        do {
        System.out.println("0 - Terminar \n 1 - Sumar \n 2 - Restar \n 3 - Multiplicar");
        opcion = scanner.nextInt();
    
        if (opcion < 0 || opcion > 3) {
        System.out.println("Código erróneo, prueba otra vez.");
        }
        } while (opcion < 0 || opcion > 3);
        
        System.out.println("Valor entero:");
        int valor = scanner.nextInt();
        
        m = new Mensaje(opcion, valor);
        
        om=qs.createObjectMessage(m);
        
        s.send(om);
        
        cc.close();
        
        }catch(Exception e){e.printStackTrace();};
    }
    
}
