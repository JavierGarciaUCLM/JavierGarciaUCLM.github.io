#!/usr/bin/env bash
# Corre ns-3 para prac 5 — ancho de banda y un delay

NS3="./ns3"                     # ejecutable
SCRIPT="scratch/tcp-P5.cc"      # programa que usamos

# ---------- 1) BANDA ANCHA FIJO 5ms de retraso ----------
echo "#bw,bytes" > resultados_bw.csv
for BW in 1Mbps 2Mbps 3.5Mbps 5Mbps 7Mbps 10Mbps; do
    BYTES=$($NS3 run "$SCRIPT --bw=$BW --delay=5ms" \
            | grep -oP 'Total Bytes Received: \K[0-9]+')
    echo "$BW,$BYTES" | tee -a resultados_bw.csv
done

# ---------- 2) RETARDO con bw fijo de 500Kbps ----------
echo "#delay,bytes" > resultados_delay.csv
for D in 5ms 250ms 500ms 1000ms; do
    BYTES=$($NS3 run "$SCRIPT --bw=500Kbps --delay=$D" \
            | grep -oP 'Total Bytes Received: \K[0-9]+')
    echo "$D,$BYTES" | tee -a resultados_delay.csv
done