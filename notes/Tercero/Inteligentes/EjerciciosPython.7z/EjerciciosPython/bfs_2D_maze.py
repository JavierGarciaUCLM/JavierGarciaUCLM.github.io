from collections import deque


# Laberint 2D, 1 = paredes ; 0 = libre
maze = [
    [0, 1, 0, 0, 0],
    [0, 1, 0, 1, 0],
    [0, 0, 0, 1, 0],
    [1, 1, 0, 1, 0],
    [0, 0, 0, 1, 0],
]

# Cooderdendas inicial / goal
start = (0, 0)
goal = (4, 4)


# Movimientos posibles

movements = [
    (-1, 0),  # arriba
    (1, 0),  # abajo
    (0, -1),  # izquierda
    (0, 1),  # derecha
]


def bfs(maze, start, goal):
    # Crear cola BFS y punto de partida
    queue = deque([start])

    # Crear conjunto para almacenar los nodos visitados
    visited = set()
    visited.add(start)

    # Diccionario para almacenar los cambios
    parent = {}
    parent[start] = None

    while queue:
        # Extraer nodo actual
        current = queue.popleft()
        print(f"Visitando nodo: {current}")

        # Si es el nodo objetivo, terminar busqueda
        if current == goal:
            print("Objetivo encontrado!")
            return reconstruct_path(parent, start, goal)

        # Explora vecinos para cada movimiento
        for move in movements:
            # Calcular vecino segun se mueve
            neighbor = (current[0] + move[0], current[1] + move[1])

            if 0 <= neighbor[0] < len(maze) and 0 <= neighbor[1] < len(maze[0]):

                if maze[neighbor[0]][neighbor[1]] == 0 and neighbor not in visited:
                    # Añadir vecino a la cola y marcarlo como visitado
                    queue.append(neighbor)
                    visited.add(neighbor)

                    # Registrar al padre del vecino para poder reconstruir
                    parent[neighbor] = current

                    print(f"Añadiendo vecino: {neighbor}")
    print("No se ha encontrado un camino")
    return None


def reconstruct_path(parent, start, goal):
    path = []
    current = goal
    while current is not None:
        path.append(current)
        current = parent[current]
    path.reverse()  # Porque hemos empezado a construirlo por el final (hay que darle al vuelta)

    print(f"Camino encontrado: {path}")
    return path


path = bfs(maze, start, goal)
