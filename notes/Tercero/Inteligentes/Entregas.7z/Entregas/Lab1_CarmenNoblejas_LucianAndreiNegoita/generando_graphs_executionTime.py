import matplotlib.pyplot as plt
import numpy as np

# This file for executionTime and the AggregatedNodes where created for the first assignment before knowing we could plot it directly when executing jupyther
# calle 1
algorithms = ["BFS", "DFS", "A*", "GBFS"]
execution_times_morcillo = [0.03, 0.02, 0.86, 0.61]

# la otra
execution_times_palmas = [0.03, 0.02, 0.86, 0.61]


x = np.arange(len(algorithms))
width = 0.35

# Plot chart
fig, ax = plt.subplots(figsize=(10, 6))
ax.bar(
    x - width / 2,
    execution_times_morcillo,
    width,
    label="Calle Agustina Aroca",
    color="#FFC0CB",
    alpha=0.8,
)
ax.bar(
    x + width / 2,
    execution_times_palmas,
    width,
    label="Calle Cardenal Tabera",
    color="#FF69B4",
    alpha=0.8,
)


ax.set_xlabel("Algorithm", fontsize=12)
ax.set_ylabel("Execution Time (ms)", fontsize=12)
ax.set_title("Execution Time Comparison", fontsize=14)
ax.set_xticks(x)
ax.set_xticklabels(algorithms, fontsize=10)
ax.legend(fontsize=10)
ax.grid(axis="y", linestyle="--", alpha=0.7)

# Display
plt.tight_layout()
plt.show()
