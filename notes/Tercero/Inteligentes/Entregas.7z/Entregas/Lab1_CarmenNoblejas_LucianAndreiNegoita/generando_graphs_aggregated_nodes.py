import matplotlib.pyplot as plt
import numpy as np

algorithms = ["BFS", "DFS", "A*", "GBFS"]

nodes_map1 = [
    1681 + 1612,
    3099 + 2892,
    1009 + 940,
    158 + 107,
]  # Aggregated nodes 1
nodes_map2 = [
    521 + 498,
    606 + 434,
    458 + 432,
    70 + 41,
]  # Aggregated nodes 2

x = np.arange(len(algorithms))


width = 0.35
fig, ax = plt.subplots(figsize=(10, 6))


bar1 = ax.bar(
    x - width / 2,
    nodes_map1,
    width,
    label="Calle Agustina Aroca",
    color="#FFC0CB",  # Light pink
    alpha=0.8,
)
bar2 = ax.bar(
    x + width / 2,
    nodes_map2,
    width,
    label="Calle Cardenal Tabera",
    color="#FF69B4",  # Dark pink
    alpha=0.8,
)


ax.set_xlabel("Algorithms", fontsize=12)
ax.set_ylabel("Aggregated Nodes (Generated + Expanded)", fontsize=12)
ax.set_title("Aggregated Nodes Comparison by Algorithm and Map", fontsize=14)
ax.set_xticks(x)
ax.set_xticklabels(algorithms, fontsize=10)
ax.legend(fontsize=10)
ax.grid(axis="y", linestyle="--", alpha=0.7)


for bar in bar1 + bar2:
    height = bar.get_height()
    ax.text(
        bar.get_x() + bar.get_width() / 2.0,
        height,
        f"{int(height)}",
        ha="center",
        va="bottom",
        fontsize=10,
    )

# Display
plt.tight_layout()
plt.show()
