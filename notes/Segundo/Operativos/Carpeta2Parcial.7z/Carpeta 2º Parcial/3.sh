#!/bin/bash

#Exercise 3 

#Show on-screen the contents of a file, numbering its lines as specified on each section.

#Showing all the lines of the file (empty and non-empty) with the following format: 4 characters for

#the line number, a whitespace, and the text line afterwards.

#For example, for the following file:

#line one

#line two

#line four

#line six

#you must obtain the following output (whitespaces indicated with ␣):

#␣␣␣1␣line␣one

#␣␣␣2␣line␣two

#␣␣␣3

#␣␣␣4␣line␣four

#␣␣␣5

#␣␣␣6␣line␣six



awk '{printf "%4d %s\n", NR, $0}' $1



#Showing just the non-empty text lines and respecting the original line number. For the same example

#file, the output would be:

#␣␣␣1␣line␣one

#␣␣␣2␣line␣two

#␣␣␣4␣line␣four

#␣␣␣6␣line␣six

echo -e "\n\n\n"

awk '{if($0 != "") printf "%4d %s\n", NR, $0}' $1

echo -e "\n\n\n"

#Numbering separately and consecutively the empty and non-empty lines. After showing the file, you

#must print the number of empty and non-empty lines:

#For the same example file, the output would be:

#␣␣␣1␣line␣one

#␣␣␣2␣line␣two

#␣␣␣1

#␣␣␣3␣line␣four

#␣␣␣2

#␣␣␣4␣line␣six

#Empty␣lines:2.␣Non-empty␣lines:4



awk 'BEGIN {empty=0;nonempty=0} 

	$0!=""{ nonempty++; printf "%4d %s\n", nonempty, $0}

	$0==""{ empty++; printf "%4d\n", empty}

	 END {

	print "Empty lines:" empty " Non-empty lines:" nonempty}' $1



