#!/bin/bash



#Ejercicio a)



if [ ! $# -ge 1 ]

then

echo -e "\nWrong Number of Params."

exit 1

fi







#Coger establecimientos con mas de 10 actividades diarias)



case $1 in

	1) awk -F, 'BEGIN{num=0}

		    $5>10{num++;print $1,$2}

		    END{if (num==0) print "No establishments with more than 10 daily activites"; if (num>0) print "The number of establishments with more than 10 daily activites are:",num}' datos.txt;;



#Ordenar en función de precio mas caro y que no sea "Sevilla" la ciudad)



	2) cat datos.txt | sed 's/\$//'  | sort -rnt"," -k4 | awk -F, '

	$3!="Sevilla"{

	if(NR==1) mayor=$4;print $3} END {

	printf "%d\n", mayor}';;



#Cuenta las veces que aparecen las ciudades y muestra por ese orden)



	3) awk -F, '{array[$3]++}

		   END{for (i in array) printf "%+5s %s\n",array[i],i}' datos.txt;;



#Saca media actividades en las otras localidades que no sean el input $2)



	4) awk -F, -v 	localidad=$2 'BEGIN{cont=0;suma=0}

				     $3!=localidad {suma=suma+$5;cont++}

				     END{print suma/cont}' datos.txt;; # hacer la media

#Busca los que se fundaron 19__ y que los socios sean mas que $2)



	5) awk -F, -v socios=$2 '$7+0 > socios {print $0}' datos.txt | grep "19" ;; 

	

#Ejercicio g)



	6)  media=$(awk -F, 'BEGIN {

	cont=0;sum=0} {

	sum+=$5;cont++} END {

	printf "%i", suma/cont}

	' datos.txt) cat datos.txt | sort -n -t"," -k2 | awk -F, -v media=$media 'BEGIN {

	mayor=0} 

	$5>media && mayor==0 {

	mayor++;print "La media de socios es ",media,"\n", $1,$2,$4}

	';;

esac

