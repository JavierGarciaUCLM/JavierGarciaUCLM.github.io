#!/bin/bash



#Exercise 5 

#Write a script that accepts 2 parameters: a filename and a subject name. The file format is

#student:subject:mark. 







#The script must do the following:

#

#1. If a number of parameters different than 2 were given, show this message and finish: “Wrong number

#of parameters”.



if [ $# -ne 2 ]; then

	echo "Wrong number of parameters"

	exit 1

fi







#2. If the first parameter is not a regular file, show this message and finish: “XXXX is not a regular file”.





if [ ! -f $1 ]; then

	echo ""$1" Not a regular file"

	exit 1

fi 

#3. Use awk to obtain the following lists (sorted decreasingly by mark):

	

	#2 best marks of the subject indicated as second parameter.

echo "2 best marks of the subject"

awk -F: -v subject=$2 '$2==subject {print $0}' $1 | sort -nrt: -k3 | head -n2



echo -e "\n\n"

	

	#3 worst marks of that same subject.

echo "3 worst marks of that same subject"

awk -F: -v subject=$2 '$2==subject {print $0}' $1 | sort -nt: -k3 | head -n3

echo -e "\n\n"



	#5 best marks of any other subjects that are not the one indicated.

echo "5 best marks of any other subjects that are not the one indicated"	

awk -F: '{print $0}' $1 | sort -nrt: -k3 | head -n5

echo -e "\n\n"

