#!/bin/bash



if [ $# -ne 1 ]; then

	echo "Wrong number params"

	exit 1

fi



prefix=$1



echo "Two biggest files/directories and their total size:"



ls -l | awk '{print $5, $9}' | sort -nr | head -n 2 | awk -v prefix="$prefix" 'BEGIN {

										total_size=0} {

										print $2,  $1;

										total_size+=$1} END {

										print "Total size:", total_size

										}'



echo -e "\nFiles/Directories matching prefix '$prefix':"



ls -l | awk -v prefix="$prefix" '

	$9 ~ "^" prefix  {

	print $9;

	count++;

	} END {

	print "Matching files/directories:", count;

	}'



echo -e "\nDirectories matching prefix '$prefix':"



ls -l | awk -v prefix="$prefix" 'BEGIN {countdir=0}

	/^d/ && $9 ~ "^" prefix {

	print $9;

	countdir++;} END {

	print "Number of matching directories:", countdir}'



	

	

	