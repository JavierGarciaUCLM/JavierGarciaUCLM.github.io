#!/bin/bash



#Exercise 2 

#Create a shell-script which accepts a user name (xxxx) as a parameter, and shows the following

#information :



#For each active process of the user: User xxxx has a process with PID xxxx.

#If the user has no active processes: User xxxx has no active processes.



if [ $# -ne 1 ]; then

	echo "Wrong params"

	exit 1

fi



ps -ef > procesos.txt



awk -v user=$1 'BEGIN {

		count=0; sum=0} 

		$1==user && $2!="" {

		count++;sum+=$2;print "User "user" has a process with PID "$2""} END {

		if(count==0) print "User "user" has no active processes"; 

		if (count!=0) print "Count:"count,"Sum:"sum, "Mean:"sum/count }' procesos.txt

		

# A este ejercicio he añadido además un contador y una variable sum, al final muestro la media con sum/count

