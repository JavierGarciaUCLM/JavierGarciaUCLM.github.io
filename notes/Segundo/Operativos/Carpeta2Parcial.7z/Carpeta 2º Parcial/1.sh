#!/bin/bash



#Exercise 1 Create a command that performs the following actions:



#From the list of active processes, only show the proprietary user (UID), the process identifier (PID),

#and the executed command (CMD).

# $1, $2, $8

ps -ef | awk '{print $1, $2, $8}'



#Modify the previous command so as to only show the processes belonging to users whose account

#name begins with “r”.



echo -e "\n\nStarting with "r""

ps -ef | awk '/^r/{print $1, $2, $8}'



#Tip: use this command: ps -ef









