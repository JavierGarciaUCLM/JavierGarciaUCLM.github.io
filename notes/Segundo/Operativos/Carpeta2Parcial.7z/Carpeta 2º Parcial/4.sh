#!/bin/bash



#Exercise 4 

#Join the three options of the previous exercise in a single file. To do so, create a shell-script

#which accepts as parameters a filename and an option (from 1 to 3).

#You must check that the number of parameters is correct, the file exists, and the option is between 1

#and 3. Show the corresponding messages otherwise.



if [ $# -eq 0 ]; then

	echo "Wrong params"

	exit 1

fi





case $2 in

	1) awk '{printf "%4d %s\n", NR, $0}' $1;;

	

	2) awk '{if($0 != "") printf "%4d %s\n", NR, $0}' $1;;

	

	3) awk 'BEGIN {empty=0;nonempty=0} 

		$0!=""{ nonempty++; printf "%4d %s\n", nonempty, $0}

		$0==""{ empty++; printf "%4d\n", empty}

		 END {

		print "Empty lines:" empty " Non-empty lines:" nonempty}' $1;;

	*) echo "No es valido";;

esac

