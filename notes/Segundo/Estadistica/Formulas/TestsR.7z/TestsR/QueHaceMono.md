
#===============================================================================
# DATABASE DESCRIPTION 
#===============================================================================

# 1. Small description of the database
# 2. summary(DATA)
# 3. Describe each variable independently
#
#     3.1: If numeric:
#       3.1.1: summary(DATA$var1)  # Basic descriptive statistics
#       3.1.2: shapiro.test(DATA$var1)  # Normality test
#           3.1.2.1: If normal:
#                     mean(DATA$var1, na.rm = T)  # Mean for normally distributed data
#                     sd(DATA$var1, na.rm = T)    # Standard deviation
#           3.1.2.2: If not normal:
#                     median(DATA$var1, na.rm = T)  # Median for non-normal data
#                     IQR(DATA$var1, na.rm = T)     # Interquartile range
#
#     3.2: If categorical:
#       3.2.1: summary(DATA$var1)  # Summarize categories
#       3.2.2: table(DATA$var1)    # Frequency table
#       3.2.3: prop.table(table(DATA$var1))*100  # Proportions as percentages

#===============================================================================
# DATA VISUALIZATION 
#===============================================================================

# Visualizing data to understand distributions and potential outliers.
# Example: Plotting histograms and boxplots for numeric variables.
# ggplot2 is utilized for making these plots more informative.

# library(ggplot2)
# Histogram
# ggplot(DATA, aes(x=var1)) + geom_histogram(binwidth = 1) + ggtitle("Histogram of var1")

# Boxplot
# ggplot(DATA, aes(y=var1)) + geom_boxplot() + ggtitle("Boxplot of var1")

#===============================================================================
# AUTOMATION WITH FUNCTIONS
#===============================================================================

# Custom functions to streamline repetitive tasks such as testing for normality across multiple variables.

# test_normality <- function(data) {
#  results <- lapply(data, function(x) {
#    if (shapiro.test(x)$p.value > 0.05) {
#      c("Mean"=mean(x, na.rm = T), "SD"=sd(x, na.rm = T))
#    } else {
#      c("Median"=median(x, na.rm = T), "IQR"=IQR(x, na.rm = T))
#    }
#  })
#  return(results)
#}


#===============================================================================
# ERROR HANDLING IN R
#===============================================================================

# Implementing error handling to manage missing values and unexpected data types.

#safe_summary <- function(x) {
#  if (is.numeric(x) & !any(is.na(x))) {
#    summary(x)
#  } else {
#    cat("Variable is not numeric or contains NA\n")
#  }
#}


#===============================================================================
# NUMERIC vs CATEGORICAL 
#===============================================================================

# 1 - Describe both variables separately
# 2 - Describe one vs the other
# 3 - Check for normality within the groups
#         shapiro.test(DATA$var1[group1])
#         shapiro.test(DATA$var1[group2])
#
#   3.1 - BOTH are normal:
#     3.1.1 - Check for homogeneity of variances using Bartlett's test
#               bartlett.test(DATA$var1 ~ DATA$var2) # if p.value > alpha, they have equal variances
#
#       3.1.1.1 - Variances equal -> Student t-test
#               t.test(DATA$var1 ~ DATA$var2, var.equal = TRUE) # if p.value > alpha, accept null hypothesis (no difference)
#       3.1.1.2 - Variances not equal -> Welch test
#               t.test(DATA$var1 ~ DATA$var2, var.equal = FALSE) # Welch t-test for unequal variances

#   3.2 - Any or both are NOT normal:
#     3.2.1 - Use Wilcoxon-Mann-Whitney test for non-parametric data
#           wilcox.test(DATA$var1 ~ DATA$var2)

#===============================================================================
# CATEGORICAL vs CATEGORICAL SNIPPET:
#===============================================================================

# 1 - Describe both variables independently
# 2 - Describe one vs the other
#         table(DATA$var1, DATA$var2)
#         prop.table(table

# (DATA$var1, DATA$var2), margin = 1)*100

# 3 - Chi-squared test for association
#         chisq.test(DATA$var1, DATA$var2)

#===============================================================================
# NUMERIC vs NUMERIC SNIPPET:
#===============================================================================

# - Describe both variables independently
# - Test for correlation
#             - Pearson or Spearman based on distribution
#                   cor(DATA$var1, DATA$var2)  # Correlation coefficient
#                   cor.test(DATA$var1, DATA$var2)  # Test for significance

# - Paired tests if variables are related or dependent
#       t.test(DATA$var1, DATA$var2, paired = T)  # Paired t-test if normal
#       wilcox.test(DATA$var1, DATA$var2, paired = T)  # Wilcoxon test if not normal
