#===============================================================================
# DATABASE DESCRIPTION 
#===============================================================================

# 1. Small description of the database
# 2. summary(DATA)
# 3. Describe each variable independently
#
#     3.1: If numeric:
#       3.1.1: summary(DATA$var1)
#       3.1.2: shapiro.test(DATA$var1)
#           3.1.2.1: If normal:
#                     mean(DATA$var1, na.rm = T)
#                     sd(DATA$var1, na.rm = T)
#           3.1.2.2: If not normal:
#                     median(DATA$var1, na.rm = T)
#                     IQR(DATA$var1, na.rm = T)
#
#     3.2: If categorical:
#       3.2.1: summary(DATA$var1)
#       3.2.2: table(DATA$var1) (frequency)
#       3.2.3: prop.table(table(DATA$var1))*100


#===============================================================================
# NUMERIC vs CATEGORICAL 
#===============================================================================

# 1 - Describe both variables separately
# 2 - Describe one vs the other
# 3 - Check for normality within the groups
#         shapiro.test(DATA$var1[DATA$var2 == group1])
#         shapiro.test(DATA$var1[DATA$var2 == group2])
#
#   3.1 - BOTH are normal
#     3.1.1 - Check for homocedasticity
#               bartlett.test(DATA$var1 ~ DATA$var2) 
#               # o 
#               car::leveneTest(DATA$var1 ~ DATA$var2) 
#               # if p.value > alpha, they have equal variances
#
#       3.1.1.1 - Var equal -> student t test
#               t.test(DATA$var1 ~ DATA$var2, var.equal = TRUE) 
#               # if p.value > alpha, accept null hypothesis (e.g., means are the same in both groups)
#       3.1.1.2 - Var NOT equal -> welch test
#               t.test(DATA$var1 ~ DATA$var2, var.equal = FALSE) 
#               # if p.value > alpha, means are the same
#
#   3.2 - Any or both are NOT normal
#     3.2.1 - Wilcoxon-Mann-Whitney
#           wilcox.test(DATA$var1 ~ DATA$var2)


#===============================================================================
# CATEGORICAL vs CATEGORICAL SNIPPET:
#===============================================================================

# 1 - Describe both variables independently
# 2 - Describe one vs the other
#         table(DATA$var1, DATA$var2)
#         prop.table(table(DATA$var1, DATA$var2), margin = 1)*100
#
# 3 - test --> we need the EXPECTED VALUES
#   how many of them are under 5?
#         sum(chisq.test(DATA$var1, DATA$var2)$expected < 5) 
#
#   IF there are NONE (0)
#     3.1 - Pearson's chisq.test
#         chisq.test(DATA$var1, DATA$var2)
#   ELSE
#     3.2 - Fisher
#         fisher.test(DATA$var1, DATA$var2)


#===============================================================================
# NUMERIC vs NUMERIC SNIPPET:
#===============================================================================

# - Describe both variables independently
# - Are they independent?
#
#   - Yes -> correlation
#             - If both normal:
#                   cor(DATA$var1, DATA$var2, method = "pearson", use = "complete.obs") #coefficient
#                   cor.test(DATA$var1, DATA$var2, method = "pearson", use = "complete.obs") #p.value 
#            # correlation coefficient goes from -1 (inverse) to 1 (direct) (0 means they do not correlate), consider independent between -0.4 and 0.4
#            - If not normal:
#                   cor(DATA$var1, DATA$var2, method = "spearman") #coefficient
#                   cor.test(DATA$var1, DATA$var2, method = "spearman") #p.value
#
#   - No -> paired test
#             - If both normal:
#                   t.test(DATA$var1, DATA$var2, paired = TRUE)
#             - If not normal:
#                   wilcox.test(DATA$var1, DATA$var2, paired = TRUE)
#
# - To check if there's difference between groups:
#       t.test(DATA$var1[group1], DATA$var2[group1], paired = TRUE)
#       t.test(DATA$var1[group2], DATA$var2[group2], paired = TRUE)
