package packClasses;

public class Dispenser {
    public Medicine[][] dispenser = new Medicine[21][15]; // Creamos en base a la estructura "Medicine" nuevas medicinas
    //de tamaño 22 x 16 (22 para 20 medicamentos, nombre y array)

    public Dispenser() {
        //Inicializamos los dispensadores
        for(int i = 0; i < 21; ++i) {
            for(int j = 0; j < 15; ++j) {
                this.dispenser[i][j] = new Medicine();
            }
        }

    }

    public int findMedicine(String name) {
        //Solo con nombre, sin empresa
        //Busca la medicina en base al String que se le pasa en la primera opción de nuestra GUI siempre y cuando las unidades
        //sean más que 0 (1)
        //establece que recorrerá la fila 20 de la matriz ya que ahí se encuentran los nombres
        for(int i = 0; i < 15; ++i) {
            if (this.dispenser[20][i].getNameMedicine().equals(name) && this.dispenser[20][i].units > 0) {
                return i;
            }
        }

        return -1;
    }

    public int findMedicine(String name, String manufacturer) {
        //Con nombre y empresa
        //Busca la medicina en base al String que se le pasa en la primera opción de nuestra GUI siempre y cuando las unidades
        //sean más que 0 (1)
        //establece que recorrerá la fila 20 de la matriz ya que ahí se encuentran los nombres
        for(int i = 0; i < 15; ++i) {
            if (this.dispenser[20][i].getNameMedicine().equals(name) && this.dispenser[20][i].units > 0 && this.dispenser[20][i].getManufacturer().equals(manufacturer)) {
                return i;
            }
        }

        return -1;
    }

    public int takeMedicine(String name, int x) {
        //Sin empresa
        //Método para sacar medicinas
        int numberMedicine = 0;
        //Si le pedimos cero, devolveremos 0 (numberMedicine)
        if (x == 0) {
            return numberMedicine;
        } else {
            //Comprueba si existe el nombre de la medicina, en caso de que no, recibe un -1 y no entra en el if
            //si entra, recibe el segundo argumento de la matriz
            int column = this.findMedicine(name);
            if (column > -1) {
                //Si no hay suficiente (al restar da negativo), añade el número restante de esa columna a lo que se devolverá
                //y se pone a 0 el resto de la columna
                if (this.dispenser[20][column].units - x < 0) {
                    numberMedicine += this.dispenser[20][column].units;
                    this.dispenser[20][column].units = 0;
                    return numberMedicine;
                }
                //Si hay suficiente se mete el número que pide y lo resta de la columna
                numberMedicine += x;
                this.dispenser[20][column].units -= x;
            }

            return numberMedicine;
        }
    }

    public int takeMedicine(String name, int x, String manufacturer) {
        //Con nombre y empresa
        //Método para sacar medicinas
        int numberMedicine = 0;
        //Si le pedimos cero, devolveremos 0 (numberMedicine)
        if (x == 0) {
            return numberMedicine;
        } else {
            //Comprueba si existe el nombre de la medicina, en caso de que no, recibe un -1 y no entra en el if
            //si entra, recibe el segundo argumento de la matriz
            int column = this.findMedicine(name, manufacturer);
            if (column > -1) {
                //Si no hay suficiente (al restar da negativo), añade el número restante de esa columna a lo que se devolverá
                //y se pone a 0 el resto de la columna
                if (this.dispenser[20][column].units - x < 0) {
                    numberMedicine += this.dispenser[20][column].units;
                    this.dispenser[20][column].units = 0;
                    return numberMedicine;
                }
                //Si hay suficiente se mete el número que pide y lo resta de la columna
                numberMedicine += x;
                this.dispenser[20][column].units -= x;
            }

            return numberMedicine;
        }
    }

    public void refillStockAll() {
        //Rellena todas las columnas
        for(int i = 0; i < 15; ++i) {
            this.dispenser[20][i].units = 20;
        }

    }
}
