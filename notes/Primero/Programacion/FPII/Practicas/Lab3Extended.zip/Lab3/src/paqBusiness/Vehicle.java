package paqBusiness;

public class Vehicle {
    public String brand;
    public String licencePlate;
    Vehicle(String brand, String licencePlate){
    this.brand = brand;
    this.licencePlate = licencePlate;
    }

    public String getBrand() {
        return brand;
    }

    public String getLicencePlate() {
        return licencePlate;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setLicencePlate(String licencePlate) {
        this.licencePlate = licencePlate;
    }

    @Override
    public String toString() {
        return "Vehicle => Brand: " + brand + ", Licence plate: " + licencePlate;
    }
}
