package paqBusiness;

public class Main {
    public static void main(String[] args) {

        Restaurant r1 = new Restaurant("Restaurant One", "123 Main St", "555-1000", 1);
        Restaurant r2 = new Restaurant("Restaurant Two", "456 Elm St", "555-2000", 2);
        Dealer d1 = new Dealer("Dealer One", "789 Oak St", "555-3000", 3);
        Dealer d2 = new Dealer("Dealer Two", "321 Pine St", "555-4000", 4);


        r1.addEmployee(new Employee("John Doe", "001", "Chef", 50000, 1));
        r1.addEmployee(new Employee("Jane Smith", "002", "Manager", 60000, 1));

        d1.addEmployee(new Employee("Mike Brown", "003", "Sales", 55000, 3));
        d1.addEmployee(new Employee("Sarah Davis", "004", "Maintenance", 45000, 3));
        d1.addEmployee(new Employee("Emily Johnson", "005", "Finance", 65000, 3));

        BCLM bclm = new BCLM();
        bclm.addBusiness(r1);
        bclm.addBusiness(r2);
        bclm.addBusiness(d1);
        bclm.addBusiness(d2);


        System.out.println("Dealer Employees:");
        bclm.displayDealerEmployees();


        BCLM bclmCopy = bclm.copy();

       //replacement
        Dealer newDealer = new Dealer("New Dealer", "654 Spruce St", "555-5000", 5);
        newDealer.addEmployee(new Employee("Luke Evans", "006", "CEO", 70000, 5));
        bclm.replaceRestaurantWithDealer(r1, newDealer);

    }
}
