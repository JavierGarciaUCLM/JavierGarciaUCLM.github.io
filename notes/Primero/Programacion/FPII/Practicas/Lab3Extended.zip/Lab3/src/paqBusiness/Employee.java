package paqBusiness;

public class Employee {
    private String name;
    private String id;
    private String position;
    private double salary;
    private int businessID;
    public Employee(String name, String id, String position, double salary, int businessID) {
        this.name = name;
        this.id = id;
        this.position = position;
        this.salary = salary;
        this.businessID = businessID;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public String getPosition() {
        return position;
    }

    public double getSalary() {
        return salary;
    }

    public int getBusinessID() {
        return businessID;
    }

    @Override
    public String toString() {
         return "Employee{" +
                "Name: '" + name + '\'' +
                ", Id='" + id + '\'' +
                ", Position='" + position + '\'' +
                ", Salary=" + salary +
                ", BusinessID=" + businessID +
                '}';
    }
}
