package paqBusiness;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Arrays;

public class Dealer extends Business{

     ArrayList<VehicleToSell> vehiclesToSell;
     ArrayList<VehicleToRepair> vehiclesToRepair;

    public Dealer(String nameOfBusiness, String addressOfBusiness, String phoneOfBusiness, int businessID){
        super(nameOfBusiness, addressOfBusiness, phoneOfBusiness, businessID);
        this.vehiclesToSell = new ArrayList<>();
        this.vehiclesToRepair = new ArrayList<>();
    }
    public void addRepair(VehicleToRepair vehicle){
        vehiclesToRepair.add(vehicle);
    }

    public boolean repairVehicle(int index){
        if (index >= 0 && index < vehiclesToRepair.size()){
        vehiclesToRepair.get(index).setFixed(true);
        return true;
        }
        return false;
    }

    public String updateVehicle(String licencePlate){
        for (int i = 0; i < vehiclesToRepair.size(); i++){
            if (vehiclesToRepair.get(i).getLicencePlate().equals(licencePlate) && vehiclesToRepair.get(i).isFixed()){
                vehiclesToRepair.remove(i);
                return "Vehicle repaired";
            }
        }
        return "Vehicle not found / not repaired yet";
    }
public void addSale(VehicleToSell vehicle){
        vehiclesToSell.add(vehicle);
}

public boolean sellVehicle(int index){
        if (index >= 0 && index < vehiclesToSell.size()){
            vehiclesToSell.remove(index);
            return true;
        }
        return false;
}

    @Override
    public String toString() {
        return super.toString() +
                "VehiclesForSale:" + vehiclesToSell +
                "\n VehiclesForRepair:" + vehiclesToRepair;
    }

   public void deepCopy(Dealer j){
        this.vehiclesToSell = j.vehiclesToSell;
        this.vehiclesToRepair = j.vehiclesToRepair;
   }

    @Override
    public int compare(Business other) {
        if (this == other) return 1;
        if (!(other instanceof Dealer)) return 0;
        Dealer dealer = (Dealer) other;
        return (Arrays.equals(new ArrayList[]{this.vehiclesToSell}, new ArrayList[]{dealer.vehiclesToSell}) ||
                Arrays.equals(new ArrayList[]{this.vehiclesToRepair}, new ArrayList[]{dealer.vehiclesToRepair})) ? 1 : 0;
    }

}
