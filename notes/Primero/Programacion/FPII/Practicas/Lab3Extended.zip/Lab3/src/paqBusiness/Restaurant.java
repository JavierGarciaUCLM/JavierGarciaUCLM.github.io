package paqBusiness;
import java.util.Arrays;

public class Restaurant extends Business {
    private String[] dailyMenu;
    private int numberOfTables;
    public Restaurant(String nameOfBusiness, String addressOfBusiness, String phoneOfBusiness, int businessID) {
        super(nameOfBusiness, addressOfBusiness, phoneOfBusiness, businessID);
        this.dailyMenu = new String[7];
        this.numberOfTables = 0;
    }
    public Restaurant(String nameOfBusiness, String addressOfBusiness, String phoneOfBusiness, int businessID, int numberOfTables) {
        this(nameOfBusiness, addressOfBusiness, phoneOfBusiness, businessID);
        this.numberOfTables = numberOfTables;
    }
    public void fixDailyMenu(String menu, int dayOfWeek) {
        if (dayOfWeek >= 0 && dayOfWeek < 7) {
            dailyMenu[dayOfWeek] = menu;
        } else {
            System.out.println("Invalid day of the week.");
        }
    }

    public String reviewDailyMenu(int dayOfWeek) {
        if (dayOfWeek >= 0 && dayOfWeek < 7) {
            return dailyMenu[dayOfWeek];
        }
        return "Invalid day of the week.";
    }

    public String[] getDailyMenu() {
        return dailyMenu;
    }
    public int compare(Business other) {
        if (this == other) return 1; // Memory address comparison
        if (!(other instanceof Restaurant)) return 0;
        Restaurant restaurant = (Restaurant) other;
        return Arrays.equals(this.dailyMenu, restaurant.dailyMenu) ? 1 : 0;
    }
}
