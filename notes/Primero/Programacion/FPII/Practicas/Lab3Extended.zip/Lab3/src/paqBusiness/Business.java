package paqBusiness;

public abstract class Business {
    public abstract int compare(Business other);
   String nameOfBusiness;
    int businessID;
     String addressOfBusiness;
     String phoneOfBusiness;
     int [] stock;
    double[][] dailySales;
    Employee[] employees;


    Business(String nameOfBusiness, String addressOfBusiness, String phoneOfBusiness, int businessID){
        this.nameOfBusiness = nameOfBusiness;
        this.addressOfBusiness = addressOfBusiness;
        this.phoneOfBusiness = phoneOfBusiness;
        this.businessID = businessID;
        this.dailySales = new double[12][];
        this.stock = new int[0];
        this.employees = new Employee[0];
    }

    String getNameOfBusiness(){
        return nameOfBusiness;
    }
    int getBusinessID(){
        return  businessID;
    }
    String getAddressOfBusiness(){
        return addressOfBusiness;
    }
    String getPhoneOfBusiness(){
        return phoneOfBusiness;
    }
    int[] getStock(){
        return stock;
    }

    public double[][] getDailySales() {
        return dailySales;
    }

    Employee[] getEmployees(){
        return employees;
    }

    public void setAddressOfBusiness(String addressOfBusiness) {
        this.addressOfBusiness = addressOfBusiness;
    }

    public void setBusinessID(int businessID) {
        this.businessID = businessID;
    }

    public void setNameOfBusiness(String nameOfBusiness) {
        this.nameOfBusiness = nameOfBusiness;
    }

    public void setDailySales(double[][] dailySales) {
        this.dailySales = dailySales;
    }

    public void setPhoneOfBusiness(String phoneOfBusiness) {
        this.phoneOfBusiness = phoneOfBusiness;
    }

    public void setEmployees(Employee[] employees) {
        this.employees = employees;
    }

    public void setStock(int[] stock) {
        this.stock = stock;
    }


    double calculateTotalSales(double[][] dailySales){
        double total = 0;
        for (double[] monthSale : dailySales){
            for (double sale : monthSale){
                total = total + sale;
            }
        }
        return total;
    }

    double calculateSalesMonth(int month){
        double maxSales = 0;
        int monthIndex = 0;
        for (int i = 0; i < dailySales.length; i++) {
            double total = calculateSalesMonth(i + 1);
            if (total > maxSales) {
                maxSales = total;
                monthIndex = i;
            }
        }
        return monthIndex + 1;
    }

    public void updateSales(int day, int month, double amount) {
        dailySales[month - 1][day - 1] += amount;
    }

    @Override
    public Business clone() {
        try {
            return (Business) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
    void addEmployee(Employee employee){
        Employee[] newEmployee = new Employee[employees.length + 1];
        System.arraycopy(employees, 0, newEmployee, 0, employees.length);
        newEmployee[employees.length] = employee;
        employees = newEmployee;
    }
    @Override
    public String toString() {
        return "Business{" +
                "nameOfBusiness='" + nameOfBusiness + '\'' +
                ", businessID=" + businessID +
                ", addressOfBusiness='" + addressOfBusiness + '\'' +
                ", phoneOfBusiness='" + phoneOfBusiness + '\'' +
                '}';
    }

}