package paqBusiness;

public class VehicleToSell extends Vehicle {
    double price;
    int discount;
    VehicleToSell(String brand, String licencePlate, double price, int discount){
        super(brand, licencePlate);
        this.price = price;
        this.discount = discount;
    }

    @Override
    public void setBrand(String brand) {
        super.setBrand(brand);
    }

    @Override
    public void setLicencePlate(String licencePlate) {
        super.setLicencePlate(licencePlate);
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String getBrand() {
        return super.getBrand();
    }
    public String getLicencePlate(){
        return super.getLicencePlate();
    }
    public String toString(){
        return super.toString();
    }
}

