package paqBusiness;

public class BCLM {
    private Business[] businesses;
    private int currentSize;

    public BCLM() {
        this.businesses = new Business[20];
        this.currentSize = 0;
    }

    public BCLM(int size) {
        this.businesses = new Business[size];
        this.currentSize = 0;
    }

    public void addBusiness(Business business) {
        if (currentSize >= businesses.length) return;
        for (int i = 0; i < currentSize; i++) {
            if (businesses[i].compare(business) == 1) return;
        }
        businesses[currentSize++] = business;
    }

    public void replaceRestaurantWithDealer(Restaurant restaurant, Dealer dealer) {
        for (int i = 0; i < currentSize; i++) {
            if (businesses[i] instanceof Restaurant && businesses[i].compare(restaurant) == 1) {
                businesses[i] = dealer;
                return;
            }
        }
    }

    public BCLM copy() {
        BCLM newBCLM = new BCLM(this.businesses.length);
        System.arraycopy(this.businesses, 0, newBCLM.businesses, 0, this.currentSize);
        newBCLM.currentSize = this.currentSize;
        return newBCLM;
    }

    public void displayDealerEmployees() {
        for (Business b : businesses) {
            if (b instanceof Dealer) {
                Dealer dealer = (Dealer) b;
            }
        }
    }
}

