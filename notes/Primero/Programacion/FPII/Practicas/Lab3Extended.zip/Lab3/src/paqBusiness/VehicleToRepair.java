package paqBusiness;
//extends Vehicle
public class VehicleToRepair extends Vehicle  {
    String description;
    int priority;
    boolean isFixed;

    VehicleToRepair(String brand, String licencePlate, String description, int priority){
        super(brand, licencePlate);
        this.description = description;
        this.priority = priority;
        isFixed = false;
        
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public void setFixed(boolean fixed) {
        isFixed = fixed;
    }

    boolean isFixed(){
        return isFixed;
    }
   String getDescription(){
       return description;
   }

    public int getPriority() {
        return priority;
    }
}
