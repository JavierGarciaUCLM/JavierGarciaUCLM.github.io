export default async function Signup() {
  return (
    <div className="text-center text-gray-500">
      Sign-up functionality will be implemented in Practice 4.
    </div>
  );
}
