export default function Signin() {
  return (
    <div className="text-center text-gray-500">
      Sign-in functionality will be implemented in Practice 4.
    </div>
  );
}
